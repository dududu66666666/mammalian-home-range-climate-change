# AppEEARS Point Sample Extraction Readme  

## Table of Contents  

1. Request Parameters  
2. Request File Listing  
3. Point Sample Extraction Process  
4. Data Quality  
    4.1. Moderate Resolution Imaging Spectroradiometer (MODIS)  
    4.2. NASA MEaSUREs Shuttle Radar Topography Mission (SRTM) Version 3 (v3)  
    4.3. Gridded Population of the World (GPW) Version 4 Revision 11 (v4.11)  
    4.4. NASA Visible Infrared Imaging Radiometer Suite (VIIRS)  
    4.5. Soil Moisture Active Passive (SMAP)  
    4.6. Daymet (v4R1)
    4.7.1. Ecosystem Spaceborne Thermal Radiometer Experiment on Space Station (ECOSTRESS) Swath V1 and V2  
    4.7.2. Ecosystem Spaceborne Thermal Radiometer Experiment on Space Station (ECOSTRESS) Tiled V2
    4.8. Advanced Spaceborne Thermal Emission and Reflection Radiometer (ASTER) Global Digital Elevation Model (GDEM) Version 3 (v3) and Global Water Bodies Database (WBD) Version 1 (v1)  
    4.9. NASA MEaSUREs NASA Digital Elevation Model (DEM) Version 1 (v1)  
    4.10. Harmonized Landsat Sentinel-2 (HLS) Version 2.0
    4.11. Landsat Collection 2 (C2) U.S. Analysis Ready Data (ARD)  
    4.12. US National Park Service (NPS) Historical Water Balance for the Continental United States (CONUS)
    4.13. Earth surface Mineral dust source InvesTigation (EMIT) L1B Radiance and L2A Reflectance Collections
    4.14. Earth surface Mineral dust source InvesTigation (EMIT) L2B Estimated Mineral Identification, Band Depth and Uncertainty Collection
5. Data Caveats  
6. Documentation  
7. Sample Request Retention  
8. Data Product Citations  
9. Software Citation  
10. Feedback  

## 1. Request Parameters  

    Name: mamal_full_point_2  

    Date Completed:** 2025-12-22T04:01:35.966809  

    ID: 90f60499-cac4-413c-8816-fa755a03e443  

    Details:  

        Start Date: 01-01-2001  

        End Date: 12-31-2022
    
        Layers:  

            Npp_500m (MOD17A3HGF.061)  
    
        Coordinates:  

            pt01000, 33.985, -83.383  
            pt01001, 37.05, -90.08  
            pt01002, 29.728, -92.819  
            pt01003, 53.166, 9.919  
            pt01004, 27.573, 84.49  
            pt01005, 54.467, 9.267  
            pt01006, 54.367, 10.283  
            pt01007, 50.879, 5.688  
            pt01008, -40.333, 175.267  
            pt01009, -45.6, 170  
            pt01010, 50.917, -1.917  
            pt01011, 32.633, 107.783  
            pt01012, 63, -148  
            pt01013, 47.8, -112.8  
            pt01014, 69, -146  
            pt01015, 57.6, -153  
            pt01016, 68.817, -138.75  
            pt01017, 51.3, -117  
            pt01018, 68.917, -152.083  
            pt01019, 64, -147  
            pt01020, -32.35, 19.15  
            pt01021, 27.183, -81.35  
            pt01022, 42.4, -85.383  
            pt01023, 36.11, -97.23  
            pt01024, -28.533, -57.167  
            pt01025, -28.3, 31.75  
            pt01026, -20.167, 31  
            pt01027, 44.594, -116.487  
            pt01028, -19.298, 14.384  
            pt01029, -18.735, 12.943  
            pt01030, 61.5, -117  
            pt01031, 23.5, -104.3  
            pt01032, 46, -70.417  
            pt01033, 46.551, -119.489  
            pt01034, 33.285, -81.727  
            pt01035, 43.5, -112  
            pt01036, -14.817, 125.717  
            pt01037, 34, -119.75  
            pt01038, -28.1, 32.06  
            pt01039, 64.5, 11.75  
            pt01040, -27.9, 32.2  
            pt01041, -19, 15.5  
            pt01042, -25, 30.35  
            pt01043, 51.775, -1.312  
            pt01044, 46.129, -0.368  
            pt01045, 48.578, 5.783  
            pt01046, 38.75, -92.2  
            pt01047, -26.63202443, 152.9319008  
            pt01048, -18.60724394, 22.11773034  
            pt01049, 0.225492687, 37.44081951  
            pt01050, 0.74, 36.65  
            pt01051, 0.033, 36.917  
            pt01052, -4.006105123, 35.96919595  
            pt01053, 16.08335391, 101.3333226  
            pt01054, -26.96662843, 21.81663451  
            pt01055, -43.65581171, 172.7057282  
            pt01056, 29, 102.25  
            pt01057, 31, 121.85  
            pt01058, -19, 22.66  
            pt01059, 39.673, -31.117  
            pt01060, 34.07, 73.41  
            pt01061, 2.03, 16.08  
            pt01062, -2.217, -65.695  
            pt01063, -22.53, -52.3  
            pt01064, -22.92, -53.66  
            pt01065, -25.657, -54.479  
            pt01066, -18.5, -46.5  
            pt01067, -17.72, -57.39  
            pt01068, 46.07, -0.26  
            pt01069, 45.781848, 4.832684  
            pt01070, -20.567277, 130.931517  
            pt01071, -23.5, 24.5  
            pt01072, 45.836023, -78.37764  
            pt01073, 44.932135, -78.579043  
            pt01074, 50.129731, -86.695213  
            pt01075, 45.4, -79.46666667  
            pt01076, 40.13333333, -7.5  
            pt01077, 19.76, -155.5536111  
            pt01078, 16.41666667, 101.5833333  
            pt01079, 35.95, 138.4666667  
            pt01080, 48.531, -53.928  
            pt01081, 39.637, -81.389  
            pt01082, 39.2, -82.4  
            pt01083, 22, -16.75  
            pt01084, -34.2, 18.4  
            pt01085, 6.88, 39.75  
            pt01086, -18.3, 23.9  
            pt01087, -19.5, 22.6  
            pt01088, 30.119, -102.237  
            pt01089, 45.021, 136.349  
            pt01090, 13, 107.25  
            pt01091, 47.8, 14.3  
            pt01092, 49.3, 18.4  
            pt01093, 47.35, 128.1  
            pt01094, 48.355, -53.987  
            pt01095, 30.46, -84.52  
            pt01096, -19.955, -56.304  
            pt01097, 14.5, 101.92  
            pt01098, 63.75, -149.4  
            pt01099, 22.9, 121.15  
            pt01100, 29.265, -103.29  
            pt01101, 30.75, -104.08  
            pt01102, -22.52888473, -52.35778234  
            pt01103, -22.52567297, -52.3529978  
            pt01104, -22.52831081, -52.36430426  
            pt01105, -22.54813384, -52.35106883  
            pt01106, -22.62189408, -52.17086849  
            pt01107, -22.61663555, -52.17245517  
            pt01108, -22.39991202, -52.36865723  
            pt01109, -22.59782759, -52.24621217  
            pt01110, -22.58463468, -52.21806685  
            pt01111, -22.5657209, -52.27573818  
            pt01112, -22.59890681, -52.25184155  
            pt01113, -21.5814432, -53.87687129  
            pt01114, -21.58785887, -53.88041792  
            pt01115, -21.57515668, -53.87614332  
            pt01116, -21.60442791, -53.87903884  
            pt01117, -21.59157794, -53.94634456  
            pt01118, -21.56381245, -53.87263019  
            pt01119, -21.63544451, -53.70832907  
            pt01120, -21.63230201, -53.70908036  
            pt01121, -21.62158422, -53.7059222  
            pt01122, -21.617, -53.667  
            pt01123, -21.536079, -53.733736  
            pt01124, -21.64772692, -53.72046543  
            pt01125, -21.6872575, -53.527507  
            pt01126, -21.6383725, -53.7215215  
            pt01127, -21.58107462, -53.74186556  
            pt01128, -21.6403925, -53.7098485  
            pt01129, -21.67587, -53.569747  
            pt01130, -21.69442, -53.507215  
            pt01131, -19.30515598, -55.7586706  
            pt01132, -19.31457168, -55.76286118  
            pt01133, -19.31140069, -55.75920478  
            pt01134, -19.28160803, -55.82256419  
            pt01135, -19.32158516, -55.7544773  
            pt01136, -19.30452433, -55.74920126  
            pt01137, -19.31686874, -55.75507812  
            pt01138, -19.31527394, -55.75895325  
            pt01139, -19.31441972, -55.75025183  
            pt01140, -19.30104086, -55.7544309  
            pt01141, -19.31610972, -55.75339348  
            pt01142, -19.29156689, -55.77011352  
            pt01143, -19.29419916, -55.83824624  
            pt01144, -19.31706144, -55.76145009  
            pt01145, -19.29620214, -55.83033076  
            pt01146, -19.27560682, -55.80113611  
            pt01147, -19.26060042, -55.80354644  
            pt01148, -19.30890162, -55.77081647  
            pt01149, -19.3115757, -55.77200993  
            pt01150, -19.30567644, -55.81495073  
            pt01151, -19.29992819, -55.75445977  
            pt01152, -19.28183076, -55.81416306  
            pt01153, -19.29842914, -55.80846866  
            pt01154, -19.25880453, -55.8049667  
            pt01155, -19.30704344, -55.76702704  
            pt01156, -19.30059858, -55.81070268  
            pt01157, -19.27578472, -55.79910578  
            pt01158, -19.323774, -55.7534245  
            pt01159, -19.3119013, -55.75101883  
            pt01160, -19.2793056, -55.77579463  
            pt01161, -19.32796, -55.76285198  
            pt01162, -19.30343, -55.74403  
            pt01163, -19.282, -55.83369  
            pt01164, -19.31623, -55.73743  
            pt01165, -19.320715, -55.74403  
            pt01166, -19.30595, -55.75959  
            pt01167, -19.30589, -55.81738  
            pt01168, -19.30714, -55.74894  
            pt01169, -19.29463, -55.76778  
            pt01170, -19.32325, -55.75129  
            pt01171, -19.28942, -55.768225  
            pt01172, -19.28268, -55.80435  
            pt01173, -19.327455, -55.76288  
            pt01174, -19.37377, -55.76546  
            pt01175, -19.31374, -55.7614  
            pt01176, -19.29419, -55.76612  
            pt01177, 46.15, 17.5  
            pt01178, 46.75, 17.8  
            pt01179, 44.722, 20.287  
            pt01180, 36.407, 138.521  
            pt01181, 41.42, -71.52  
            pt01182, 9.157, -79.847  
            pt01183, 37.167, -122.05  
            pt01184, -24.135, -55.413  
            pt01185, -8.692, -42.557  
            pt01186, 10.768, -85.658  
            pt01187, -17.885, -53.089  
            pt01188, -20.357, -60.503  
            pt01189, -23.341, -58.095  
            pt01190, 6.3, -71.6  
            pt01191, -17.315, -56.72  
            pt01192, 16.731, -91.061  
            pt01193, -3.054, -64.854  
            pt01194, 29.69, -109.223  
            pt01195, 29.726, -109.252  
            pt01196, -13, -69.35  
            pt01197, 21.356, -87.578  
            pt01198, 63, -151  
            pt01199, 47.6, -113.7  
            pt01200, 70, 22.5  
            pt01201, 40.3, 31.5  
            pt01202, 51.417, -0.917  
            pt01203, 64.25, 29.3  
            pt01204, 65.4, 30.3  
            pt01205, 65.1, 30.3  
            pt01206, 18.221, -89.504  
            pt01207, 18.4035, -88.999  
            pt01208, 18.633, -89.094  
            pt01209, 35.3, 127.6  
            pt01210, -26.77, 153.12  
            pt01211, 6.9, 79.87  
            pt01212, 41.931, -106.225  
            pt01213, 45.5, -87.4  
            pt01214, 46.4, -88.2  
            pt01215, 46.6, -88.8  
            pt01216, -33.15, 141.06  
            pt01217, -0.561651486, -78.4334722  
            pt01218, 36.63336772, 138.7833226  
            pt01219, 39.98041337, -93.28350527  
            pt01220, -41.8807, 147.5177  
            pt01221, -41.8447, 147.169138  
            pt01222, -42.2946, 147.4382  
            pt01223, -41.9788, 147.4678  
            pt01224, 33.26642724, -113.8582398  
            pt01225, 34.13628492, -118.2934761  
            pt01226, 34.2094949, -118.2691254  
            pt01227, 42.50000789, -8.100032188  
            pt01228, 58.75528231, -106.6327082  
            pt01229, 43.26669934, 0.866694029  
            pt01230, 43.63335657, 2.966666697  
            pt01231, -18.29746943, -57.50973293  
            pt01232, -16.17021596, -58.18668816  
            pt01233, 40.96450938, -76.8834867  
            pt01234, 45.46520688, 135.8184141  
            pt01235, 55.35001828, 165.966656  
            pt01236, -28.49999055, 28.60001073  
            pt01237, 39.812584, 9.456521  
            pt01238, 39.855852, 9.387882  
            pt01239, 40.172065, 9.528568  
            pt01240, 40.185772, 9.545929  
            pt01241, 41.31693, -122.47926  
            pt01242, 43.644917, 132.503425  
            pt01243, 49.002142, 133.018537  
            pt01244, 48.216447, 131.440357  
            pt01245, 49.646028, 129.53229  
            pt01246, -20.830308, -54.071269  
            pt01247, -20.47735, -54.189408  
            pt01248, -21.556598, -50.351085  
            pt01249, 18.33222222, -91.73222222  
            pt01250, -19.3025, -55.78444444  
            pt01251, -22.81638889, -49.23666667  
            pt01252, 53.212922, -115.037044  
            pt01253, 27.102, 87.982  
            pt01254, 5.3, 117.9333333  
            pt01255, 36.042001, -81.696287  
            pt01256, 40.46, 23.12  
            pt01257, 17.899698, -76.951308  
            pt01258, 20.75, -87.25  
            pt01259, 40.88, 16.31  
            pt01260, 54.52545, 8.910249  
            pt01261, 53.743062, 8.555828  
            pt01262, 53.902446, 9.016729  
            pt01263, 54.881468, 8.321079  
            pt01264, 43.04, -89.44  
            pt01265, 42.92, -89.22  
            pt01266, 26.59, -97.64  
            pt01267, 51.48, -2.63  
            pt01268, 36.6, -76.46  
            pt01269, 6.02, 35.69  
            pt01270, 41.99, -113.52  
            pt01271, 43.33, 11.33  
            pt01272, 43.17, 11.5  
            pt01273, 42.65, 11.08  
            pt01274, 27.78, 89.73  
            pt01275, -34.02, 18.41  
            pt01276, 66, 16  
            pt01277, 22.427549, 89.592177  
            pt01278, 37.8725, -122.279  
            pt01279, -36.33333, -56.83333  
            pt01280, -35.13564, 150.70348  
            pt01281, 28.1, -97.4  
            pt01282, -28.333, 31.833  
            pt01283, 48.5, 7  
            pt01284, 55.75, 30.3333  
            pt01285, 46.7625, 5.6729  
            pt01286, 47.916667, -122.56667  
            pt01287, 61, -137.5  
            pt01288, -22.02, 29.02  
            pt01289, 19.515, 74.015  
            pt01290, 12.4, 77  
            pt01291, 36.56, 59.41  
            pt01292, 0.29, 36.9  
            pt01293, -22.81, 16.005  
            pt01294, 17.12, 54.56  
            pt01295, -27.33, 32.06  
            pt01296, -27.78, 32.35  
            pt01297, 79.16667, 12  
            pt01298, 46.7167, -60.6597  
            pt01299, 53.2156, 23.2505  
            pt01300, 26.155, -97.532  
            pt01301, -18.995, 16.383  
            pt01302, -18.856, 20.614  
            pt01303, -19.593, 22.318  
            pt01304, 35.6, -83.8  
            pt01305, 39.813, -5.937  
            pt01306, 43, -5.1  
            pt01307, 33.8, -106.6  
            pt01308, 42.84, -110.09  
            pt01309, 14.365, 101.794  
            pt01310, 46.43737, 17.43248  
            pt01311, 46.43453, 17.45608  
            pt01312, 46.45911, 17.47414  
            pt01313, 32.502, -115.1964  
            pt01314, 31.911, -116.272  
            pt01315, 35.25, -116.7  
            pt01316, 10.861, 38.792  
            pt01317, 10.341, 39.763  
            pt01318, 42.478, 12.93073  
            pt01319, 18.2, 74.25  
            pt01320, 17.96, -66.25  
            pt01321, 55, -75  
            pt01322, 35.39, 138.73  
            pt01323, 36.9, 28.3  
            pt01324, 44.2, 10.5  
            pt01325, 34.96, 127.51  
            pt01326, -17.783, -48.7  
            pt01327, -18.99531, 15.86766  
            pt01328, -19.03707, 16.34033  
            pt01329, -18.96295, 16.48613  
            pt01330, -18.99723, 16.5561  
            pt01331, -19.14636, 15.87786  
            pt01332, -19.023, 16.29341  
            pt01333, -19.3128, 15.94567  
            pt01334, -19.09407, 15.8424  
            pt01335, -19.23878, 16.1321  
            pt01336, -19.22058, 16.05575  
            pt01337, -17.89233, 24.82077  
            pt01338, -18.12365, 24.08931  
            pt01339, -18.17632, 24.02594  
            pt01340, -19.68675, 23.38801  
            pt01341, -18.12362, 24.08924  
            pt01342, -19.53536, 23.19195  
            pt01343, -17.84311, 25.08465  
            pt01344, -17.83438, 24.97582  
            pt01345, -18.98804, 16.55228  
            pt01346, -18.99288, 16.3175  
            pt01347, -19.17648, 15.93752  
            pt01348, -19.02821, 16.27732  
            pt01349, -19.20653, 16.19185  
            pt01350, -19.23362, 15.92371  
            pt01351, -19.023, 16.23112  
            pt01352, -19.02407, 15.86585  
            pt01353, -18.21099, 23.99007  
            pt01354, -17.85976, 24.88423  
            pt01355, -17.88519, 25.06556  
            pt01356, -18.07101, 24.16996  
            pt01357, -17.8712, 25.00854  
            pt01358, -21.633, 121.246  
            pt01359, -27.04, 32.44  
            pt01360, -21.25, 30.533  
            pt01361, 5.7, 101.6  
            pt01362, 5.3, 117.4  
            pt01363, 58.15, 8  
            pt01364, 23, -15  
            pt01365, 39.4, -4.493  
            pt01366, 41.65, 0.75  
            pt01367, 42.641, 11.086  
            pt01368, 42.8, 12.8  
            pt01369, 33.102, 9.061  
            pt01370, -22.28, 17.04  
            pt01371, 3.9, 29.5  
            pt01372, 10.93178, 20.04187  
            pt01373, 0.6, 36.8  
            pt01374, -20.23, 32.22  
            pt01375, -17.89, 24.78  
            pt01376, 2.23, 31.79  
            pt01377, -24.9, 31.5  
            pt01378, -24.15, 30.7  
            pt01379, -24.08, 31  
            pt01380, -19.17647, 15.27183  
            pt01381, -2.74, 37.38  
            pt01382, 7.76, 33.38  
            pt01383, -19.2, 15.9  
            pt01384, -20.4, 15  
            pt01385, 2.371893, 31.7014  
            pt01386, -19.41, 22.56  
            pt01387, 3.77, 33.73  
            pt01388, -19.355, 13.167  
            pt01389, -3.72, 35.97  
            pt01390, -2.2, 34.8  
            pt01391, 1.66, 34.53  
            pt01392, -21.69, 29.94  
            pt01393, -20.6, 14.57  
            pt01394, 13.2, 2.8  
            pt01395, -20.55, 14.59  
            pt01396, 5.28, 102.44  
            pt01397, 5.22, 102.6  
            pt01398, 4.7, 102.7  
            pt01399, 3.67, 101.37  
            pt01400, 4.3, 101.7  
            pt01401, 53.356, 13.801  
            pt01402, -19.2, 15.8  
            pt01403, -20, 14.5  
            pt01404, -18.7, 20.8  
            pt01405, -18, 22.7  
            pt01406, -24.6, 31.7  
            pt01407, 49.53, 18.8  
            pt01408, 32.9, -117  
            pt01409, 11.42, 107.42  
            pt01410, 19.05, 104.86  
            pt01411, 9.6, 105.1  
            pt01412, -18.9875, -56.6175  
            pt01413, 12.7028, 77.6251  
            pt01414, 44, -73.18  
            pt01415, 40.33, -78.48  
            pt01416, 38.08, -1.2  
            pt01417, 59.282, -129.817  
            pt01418, -32.4014, 19.3249  
            pt01419, -22.7233, 16.9544  
            pt01420, -24.38, 31.12  
            pt01421, -18.8, 22.7  
            pt01422, -21.1, 31.9  
            pt01423, 21.2, 71  
            pt01424, -18.4, 26  
            pt01425, 22.3, 71.15  
            pt01426, -16.94322, -57.37078  
            pt01427, -19.1, -39.92  
            pt01428, -27.85, 32.3  
            pt01429, 20.567, 76.378  
            pt01430, 27.476, 84.794  
            pt01431, 28.365, 81.56  
            pt01432, 47.81, 91  
            pt01433, 47.58, 92.58  
            pt01434, 50.29, 91.17  
            pt01435, 46.49, 93.46  
            pt01436, -38.54, 143.47  
            pt01437, 20.545, -86.89  
            pt01438, 26, -81.25  
            pt01439, 51.7311888, -118.7554523  
            pt01440, 50.52391, -117.1231  
            pt01441, 51.6215009, -119.0018817  
            pt01442, 51.2948431, -118.7966308  
            pt01443, 50.5473, -117.463415  
            pt01444, 50.54739, -117.05676  
            pt01445, 50.46574, -117.644325  
            pt01446, 52.2211144, -118.5711532  
            pt01447, 51.8634921, -118.240828  
            pt01448, 52.22928555, -118.5310364  
            pt01449, 51.2959149, -118.7868818  
            pt01450, 51.5787845, -118.7266798  
            pt01451, 51.3012776, -118.7832296  
            pt01452, 51.4764536, -118.9505382  
            pt01453, 53.44871645, -121.1858388  
            pt01454, 54.01387425, -121.4740533  
            pt01455, 54.8833626, -122.0230323  
            pt01456, 53.31085105, -120.9973201  
            pt01457, 53.989121, -121.4275406  
            pt01458, 53.4376651, -121.1887742  
            pt01459, 54.9498938, -122.0993164  
            pt01460, 54.9605881, -122.3547999  
            pt01461, 53.77273415, -121.5593885  
            pt01462, 53.8530558, -121.621926  
            pt01463, 53.4442859, -121.3267391  
            pt01464, 54.65632825, -121.3168186  
            pt01465, 54.9612247, -122.3509534  
            pt01466, 53.73972885, -120.647575  
            pt01467, 53.4359568, -121.3363472  
            pt01468, 53.99259215, -121.5683553  
            pt01469, 54.729427, -121.6398906  
            pt01470, 54.2044839, -121.5887465  
            pt01471, 51.6668359, -118.7833877  
            pt01472, 54.6852558, -121.6250078  
            pt01473, 51.6158857, -118.9886071  
            pt01474, 53.9761493, -121.4199054  
            pt01475, 54.1937872, -121.25448  
            pt01476, 51.61315015, -118.988194  
            pt01477, 54.7781003, -121.5113263  
            pt01478, 54.73685085, -121.9425133  
            pt01479, 50.52656, -117.44944  
            pt01480, 50.49907, -117.16941  
            pt01481, 51.5047091, -118.9753998  
            pt01482, 51.4095087, -118.8038547  
            pt01483, 51.7633889, -118.7309651  
            pt01484, 51.5696744, -118.6903415  
            pt01485, 51.5187501, -119.0104689  
            pt01486, 51.66878955, -118.8653851  
            pt01487, 51.5743826, -118.6911708  
            pt01488, 51.6616557, -118.7895642  
            pt01489, 51.29561975, -118.7964933  
            pt01490, 54.61526, -121.57107  
            pt01491, 54.16155, -121.43368  
            pt01492, 54.19268, -121.2434  
            pt01493, 50.35964, -117.70224  
            pt01494, 50.52668, -117.45009  
            pt01495, 50.58477, -117.19048  
            pt01496, 50.372095, -117.782965  
            pt01497, 50.3597, -117.70372  
            pt01498, 53.3000706, -120.8740003  
            pt01499, 53.4341883, -121.2269616  
            pt01500, 54.7751625, -121.784556  
            pt01501, 53.9675978, -121.4318041  
            pt01502, 54.86089935, -122.2160764  
            pt01503, 53.4414606, -120.9802765  
            pt01504, 53.96073585, -121.4279531  
            pt01505, 53.43831705, -121.206604  
            pt01506, 54.85687965, -122.0923399  
            pt01507, 54.8471767, -122.0709379  
            pt01508, 53.8116599, -121.5807813  
            pt01509, 53.75277595, -121.5268559  
            pt01510, 53.43382475, -121.296504  
            pt01511, 54.45846315, -121.5679717  
            pt01512, 54.8618219, -122.0729219  
            pt01513, 53.7818239, -120.518572  
            pt01514, 53.43228215, -121.2995864  
            pt01515, 54.972953, -122.3760056  
            pt01516, 53.9844595, -121.4383414  
            pt01517, 54.7158137, -121.5943232  
            pt01518, 53.9955723, -121.269551  
            pt01519, 54.1575075, -121.4586016  
            pt01520, 54.7451457, -121.9298305  
            pt01521, 54.7510373, -121.5979538  
            pt01522, 53.7724667, -120.6329958  
            pt01523, 53.9057583, -121.3151181  
            pt01524, 54.8479003, -122.0774681  
            pt01525, 53.30113, -120.8757711  
            pt01526, 54.2193231, -121.5738033  
            pt01527, 53.9997579, -121.4397241  
            pt01528, 54.1924365, -121.2398897  
            pt01529, 53.4747271, -121.4084413  
            pt01530, 53.7526428, -120.6385808  
            pt01531, 54.1374114, -121.487407  
            pt01532, 54.64603905, -121.5106196  
            pt01533, 53.7365217, -120.6960806  
            pt01534, 54.6406081, -121.82991  
            pt01535, 53.4640736, -121.4298924  
            pt01536, 54.705259, -122.0540174  
            pt01537, 54.8001292, -121.5589275  
            pt01538, 54.710211, -122.0402927  
            pt01539, 54.67209945, -121.7924723  
            pt01540, 50.45958, -117.16661  
            pt01541, 50.489675, -117.36235  
            pt01542, 50.330715, -117.77582  
            pt01543, 50.461455, -117.160035  
            pt01544, 51.6773912, -118.7292361  
            pt01545, 51.44669065, -118.7917483  
            pt01546, 51.5110468, -118.9821942  
            pt01547, 51.5561037, -118.7120252  
            pt01548, 51.67758875, -118.7274965  
            pt01549, 51.5098219, -118.9810031  
            pt01550, 51.6763575, -118.7256229  
            pt01551, 51.5108818, -118.9816622  
            pt01552, 51.7011083, -118.7943332  
            pt01553, 51.5090261, -118.9799776  
            pt01554, 51.6116596, -118.7974495  
            pt01555, 51.6034941, -118.7979688  
            pt01556, 54.641315, -121.872265  
            pt01557, 54.588855, -121.97887  
            pt01558, 53.73186, -120.70777  
            pt01559, 54.11887, -121.50016  
            pt01560, 54.18796, -121.24824  
            pt01561, 50.35465, -117.70873  
            pt01562, 50.488, -117.36108  
            pt01563, 50.47677, -117.11505  
            pt01564, 50.476725, -117.114925  
            pt01565, 50.354435, -117.705465  
            pt01566, 50.35463, -117.705215  
            pt01567, 53.8477842, -121.0991306  
            pt01568, 53.7855847, -121.6129858  
            pt01569, 54.6379444, -121.8735611  
            pt01570, 54.8373556, -122.3076914  
            pt01571, 53.6040717, -121.2988827  
            pt01572, 54.129681, -121.4992582  
            pt01573, 54.46766095, -121.9042464  
            pt01574, 53.9462694, -121.3861114  
            pt01575, 54.94327835, -122.3546781  
            pt01576, 54.1218425, -121.4997461  
            pt01577, 53.4333972, -121.3121744  
            pt01578, 53.7852775, -121.6104167  
            pt01579, 53.43347415, -121.323535  
            pt01580, 53.7311957, -120.705612  
            pt01581, 54.44034485, -121.8452096  
            pt01582, 53.9790844, -121.6372653  
            pt01583, 54.1610433, -121.5448856  
            pt01584, 53.96290195, -121.4713723  
            pt01585, 53.4854599, -121.7851103  
            pt01586, 54.03299445, -121.5600756  
            pt01587, 54.0443008, -121.485615  
            pt01588, 54.18949585, -121.2434106  
            pt01589, 53.84322, -121.63754  
            pt01590, 54.5212629, -121.5607378  
            pt01591, 53.8105579, -121.5775033  
            pt01592, 53.73277195, -120.7082204  
            pt01593, 54.43542805, -121.9369524  
            pt01594, 54.80115445, -121.5203463  
            pt01595, 53.7310728, -120.7022964  
            pt01596, 54.0756156, -121.001135  
            pt01597, 54.0433711, -121.5593664  
            pt01598, 54.8140568, -121.7371446  
            pt01599, 54.7924869, -121.5497436  
            pt01600, 54.7919964, -121.4829544  
            pt01601, 54.7908278, -121.4822458  
            pt01602, 50.485005, -117.096765  
            pt01603, 50.5246, -117.4327  
            pt01604, 50.37079, -117.76725  
            pt01605, 50.486535, -117.098655  
            pt01606, 50.36539, -117.75274  
            pt01607, 50.3744, -117.73048  
            pt01608, 51.7590685, -118.7376834  
            pt01609, 51.44312905, -118.790981  
            pt01610, 51.7607442, -118.7298419  
            pt01611, 51.6625534, -118.8155357  
            pt01612, 51.7593688, -118.7361531  
            pt01613, 51.60692385, -118.9663394  
            pt01614, 51.75863145, -118.7289972  
            pt01615, 51.6776441, -118.7219852  
            pt01616, 51.6076735, -118.9702797  
            pt01617, 51.67771705, -118.7221406  
            pt01618, 51.6650089, -118.8233019  
            pt01619, 51.610359, -118.7777904  
            pt01620, 54.216585, -121.54319  
            pt01621, 53.9394933, -121.4278628  
            pt01622, 53.7566261, -121.5184656  
            pt01623, 53.9562243, -121.3236938  
            pt01624, 53.96066, -121.4367096  
            pt01625, 54.6684628, -121.6274278  
            pt01626, 53.5204719, -121.1399233  
            pt01627, 53.52626775, -121.1900111  
            pt01628, 54.45965515, -121.901801  
            pt01629, 54.72424, -122.0428994  
            pt01630, 53.9601564, -121.451295  
            pt01631, 54.3214236, -121.8400897  
            pt01632, 54.6087828, -121.4788038  
            pt01633, 53.9569744, -121.43928  
            pt01634, 54.4596208, -121.5814111  
            pt01635, 53.9282732, -121.3872546  
            pt01636, 54.9450583, -122.3639586  
            pt01637, 54.1941814, -121.2393025  
            pt01638, 53.9604833, -121.4515672  
            pt01639, 53.4393272, -121.3145826  
            pt01640, 53.8224108, -121.5827764  
            pt01641, 53.7560639, -121.5145529  
            pt01642, 53.2615847, -121.0697592  
            pt01643, 54.13763725, -121.5059206  
            pt01644, 53.97553345, -121.1654798  
            pt01645, 53.84275835, -121.1096427  
            pt01646, 53.9593111, -121.5047297  
            pt01647, 53.4533, -121.7333125  
            pt01648, 54.0667967, -121.0594803  
            pt01649, 54.1939489, -121.2440161  
            pt01650, 54.02018615, -121.5517642  
            pt01651, 53.9714494, -121.4295114  
            pt01652, 53.4501928, -121.7400594  
            pt01653, 54.1899989, -121.2468147  
            pt01654, 55.0957818, -122.1433265  
            pt01655, 54.13752985, -121.5051179  
            pt01656, 54.19002, -121.2441139  
            pt01657, 54.7221853, -122.0436593  
            pt01658, 53.9766236, -121.4695757  
            pt01659, 53.51988165, -121.1412567  
            pt01660, 61.5, 9.1  
            pt01661, 14.137, 106.32  
            pt01662, 45.456, 7.174  
            pt01663, 27.876, -80.988  
            pt01664, 35.52, 137.04  
            pt01665, 60.7, 28  
            pt01666, 60.6, 26.75  
            pt01667, -25.2, 148.75  
            pt01668, -26.5, 150.1  
            pt01669, -9.767, 142.64  
            pt01670, -35.42, 149.58  
            pt01671, 33.3, -81.7  
            pt01672, -14.52, -57.77  
            pt01673, -14.32, -57.72  
            pt01674, -14.52, -57.26  
            pt01675, -11.94, -58.27  
            pt01676, -11.08, -56.87  
            pt01677, -18.279982, -52.900918  
            pt01678, -18.95, 34.4  
            pt01679, -18.97, 34.35  
            pt01680, 73.2, -79  
            pt01681, 57.903, -92.772  
            pt01682, 34.4775658, 76.5016822  
            pt01683, 34.4659425, 76.5041533  
            pt01684, 34.4791436, 76.5006619  
            pt01685, 34.4739642, 76.5028919  
            pt01686, 34.4613158, 76.5164081  
            pt01687, 34.4790322, 76.5006214  
            pt01688, 8.833, -68.15  
            pt01689, 39.95, -105.05  
            pt01690, 55.65, 8.2  
            pt01691, 50.083, 17.233  
            pt01692, 47.66, 16.5  
            pt01693, 48.81, 7.33  
            pt01694, 49.683, 11.767  
            pt01695, 54.117, 9.883  
            pt01696, 51.15, 9  
            pt01697, 42.71, 24.76  
            pt01698, 43, 26.8  
            pt01699, 43.4, 26.3  
            pt01700, 41.6, 24.6  
            pt01701, 49.51, 20.83  
            pt01702, 49.58, 21.3  
            pt01703, 35.47, 139.16  
            pt01704, 35.1, 139.92  
            pt01705, 35.933, 138.133  
            pt01706, -25, 31.867  
            pt01707, -19.5, 23  
            pt01708, -3.17, 35.58  
            pt01709, -17.8, 23.3  
            pt01710, 15.2, 98.75  
            pt01711, 12.8, 99.45  
            pt01712, 45.283, 96.25  
            pt01713, -11.76, 130.64  
            pt01714, 18.31, -103.433  
            pt01715, -11.762, 130.632  
            pt01716, 0.452, 34.137  
            pt01717, 0.558, 34.265  
            pt01718, 0.305, 34.204  
            pt01719, 0.449, 34.109  
            pt01720, 0.285, 34.115  
            pt01721, 0.636, 34.273  
            pt01722, 0.125, 34.054  
            pt01723, 0.448, 34.253  
            pt01724, -54.935, -67.608  
            pt01725, 36.639, -81.605  
            pt01726, 47.1, 13.2  
            pt01727, 46.666, 10.2  
            pt01728, 37.26, 126.6  
            pt01729, 37.8, 127.76  
            pt01730, -24.567, 31.55  
            pt01731, 37, -116.15  
            pt01732, 11.573, 76.756  
            pt01733, 60.7, -150.4  
            pt01734, -12.55, -70.092  
            pt01735, -19.527, -62.31  
            pt01736, -17.092, -61.789  
            pt01737, 15.53, 99.3  
            pt01738, 22.04, 72.03  
            pt01739, 17.827, 75.869  
            pt01740, 18.233, -90.625  
            pt01741, 50.65, -99.967  
            pt01742, 32.4, -91.3  
    
    Version: This request was processed by AppEEARS version 3.103  

## 2. Request File Listing  

- Comma-separated values file with data extracted for a specific product
  - mamal-full-point-2-MOD17A3HGF-061-results.csv
- Text file with data pool URLs for all source granules used in the extraction
  - mamal-full-point-2-granule-list.txt
- JSON request file which can be used in AppEEARS to create a new request
  - mamal-full-point-2-request.json
- xml file
  - mamal-full-point-2-MOD17A3HGF-061-metadata.xml  

## 3. Point Sample Extraction Process  

Datasets available in AppEEARS are served via OPeNDAP (Open-source Project for a Network Data Access Protocol) services. OPeNDAP services allow users to concisely pull pixel values from datasets via HTTPS requests. A middleware layer has been developed to interact with the OPeNDAP services. The middleware make it possible to extract scaled data values, with associated information, for pixels corresponding to a given coordinate and date range.

**NOTE:**  

- Requested date ranges may not match the reference date for multi-day products. AppEEARS takes an inclusive approach when extracting data for sample requests, often returning data that extends beyond the requested date range. This approach ensures that the returned data includes records for the entire requested date range.  
- For multi-day (8-day, 16-day, Monthly, Yearly) MODIS and Suomi NPP VIIRS datasets, the date field in the data tables reflects the first day of the composite period.  
- If selected, the SRTM v3, ASTER GDEM v3 and Global Water Bodies Database v1, and NASADEM v1 product will be extracted regardless of the time period specified in AppEEARS because it is a static dataset. The date field in the data tables reflects the nominal SRTM date of February 11, 2000.  
- If the visualizations indicate that there are no data to display, proceed to downloading the .csv output file. Data products that have both categorical and continuous data values (e.g. MOD15A2H) are not able to be displayed within the visualizations within AppEEARS.  

## 4. Data Quality  

When available, AppEEARS extracts and returns quality assurance (QA) data for each data file returned regardless of whether the user requests it. This is done to ensure that the user possesses the information needed to determine the usability and usefulness of the data they get from AppEEARS. Most data products available through AppEEARS have an associated QA data layer. Some products have more than one QA data layer to consult. See below for more information regarding data collections/products and their associated QA data layers.  

### 4.1. MODIS (Terra, Aqua, & Combined)

All MODIS land products, as well as the MODIS Snow Cover Daily product, include quality assurance (QA) information designed to help users understand and make best use of the data that comprise each product. Results downloaded from AppEEARS and/or data directly requested via middleware services contain not only the requested pixel/data values but also the decoded QA information associated with each pixel/data value extracted.  

- See the MODIS Land Products QA Tutorials: <https://lpdaac.usgs.gov/resources/e-learning/> for more QA information regarding each MODIS land product suite.  
- See the MODIS Snow Cover Daily product user guide for information regarding QA utilization and interpretation.  

### 4.2. NASA MEaSUREs SRTM v3 (30m & 90m)  

SRTM v3 products are accompanied by an ancillary "NUM" file in place of the QA/QC files. The "NUM" files indicate the source of each SRTM pixel, as well as the number of input data scenes used to generate the SRTM v3 data for that pixel.  

- See the user guide: <https://lpdaac.usgs.gov/documents/179/SRTM_User_Guide_V3.pdf> for additional information regarding the SRTM "NUM" file.  

### 4.3. GPW v4.11

The GPW `Population Count`, `Population Density`, and `Basic Demographic Characteristics` data layers are accompanied by `Data Quality Indicators` datasets. The `Data Quality Indicators` were created to provide context for the population count and density grids, and to provide explicit information on the spatial precision of the input boundary data. The data context grid (data-context1) explains pixels with "0" population estimate in the population count and density grids, based on information included in the census documents. The mean administrative unit area grid (mean-admin-area2) measures the mean input unit size in square kilometers. It provides a quantitative surface that indicates the size of the input unit(s) from which the population count and density grids were created.  

### 4.4. NASA VIIRS (Suomi National Polar-orbiting Partnership (Suomi NPP) & NOAA-20)  

All NASA VIIRS land products include quality information designed to help users understand and make best use of the data that comprise each product. For product-specific information, see the link to the NASA VIIRS products table provided in section 5.  

**NOTE:**  

- The version 2 Suomi NPP NASA VIIRS Surface Reflectance data products VNP09A1 and VNP09H1 contain two quality layers: `SurfReflect_State` and `SurfReflect_QC`. 

### 4.5. SMAP  

SMAP products provide multiple means to assess quality. Each data product contains bit flags, uncertainty measures, and file-level metadata that provide quality information. Results downloaded from AppEEARS and/or data directly requested via middleware services contain not only the requested pixel/data values, but also the decoded bit flag information associated with each pixel/data value extracted. For additional information regarding the specific bit flags, uncertainty measures, and file-level metadata contained in this product, refer to the Quality Assessment section of the user guide for the specific SMAP data product in your request: <https://nsidc.org/data/smap/smap-data.html>  

### 4.6. Daymet v4R1

Daymet station-level daily weather observation data and the corresponding Daymet model predicted data for three Daymet model parameters: minimum temperature (tmin), maximum temperature (tmax), and daily total precipitation (prcp) are available. These data provide information into the regional accuracy of the Daymet model for the three station-level input parameters. Corresponding comma separated value (.csv) files that contain metadata for every surface weather station for the variable-year combinations are also available. <https://doi.org/10.3334/ORNLDAAC/2129>

### 4.7 ECOSTRESS

#### 4.7.1. ECOSTRESS Swath V1 and V2  

V1: Quality information varies by product for the ECOSTRESS product suite. Quality information for ECO2LSTE.001, including the bit definition index for the quality layer, is provided in section 2.4 of the Version 1 User Guide: <https://lpdaac.usgs.gov/documents/423/ECO2_User_Guide_V1.pdf>. Results downloaded from AppEEARS contain the requested pixel/data values and also the decoded QA information associated with each pixel/data value extracted. No quality flags are produced for the ECO3ETPTJPL.001, ECO4WUE.001, or ECO4ESIPTJPL.001 products. Instead, the quality flags of the source data are available in the ECO3ANCQA.001 data product and a cloud mask is available in the ECO2CLD.001 product. The `ETinst` layer in the ECO3ETPTJPL.001 product does include an associated uncertainty layer that is provided with each request for ‘ETinst’ in AppEEARS. Each radiance layer in the ECO1BMAPRAD.001 product has a linked quality layer (Data Quality Indicators). ECO2CLD.001 and ECO3ANCQA.001 are separate quality products that are also available for download in AppEEARS.

V2: Quality information varies by product for the ECOSTRESS product suite. Quality Assurance (QA) information for ECO_L2_LSTE.002, including the bit definition index for the quality layer, is provided in section 2.4 of the User Guide: <https://lpdaac.usgs.gov/documents/1574/ECOL2_User_Guide_V2.pdf>. For Land Surface Temperature and Emissivity (LSTE) product, the quality flags of the source data are available in the ECO_L2_LSTE.002 data product. Please note that unlike V1, the V2 LSTE product does not incorporate cloud cover into the Pixel Produced QA bit flag. This flag now relates to other variables only (See Table 6 in User Guide). Users should apply the cloud mask separately to account for pixels with cloud when using ECO_L2_LSTE.002 data product.  Cloud mask derived from ECO_L2_CLOUD.002 is and Water mask derived from the Shuttle Radar Topography Mission (SRTM) Digital Elevation Model are available as separate science dataset (SDS) layers in the ECO_L2_LSTE.002 data product. Additionally, cloud and cloud confidence layers are available in the ECO_L2_CLOUD.002 product. Results downloaded from AppEEARS contain requested pixel/data values,` decoded Quality Assurance (QA), and cloud information associated with each pixel/data value extracted.

#### 4.7.2. ECOSTRESS Tiled V2  

Quality information varies by product for the ECOSTRESS product suite. Quality information for ECO_L2T_LSTE.002, including the bit definition index for the quality layer, is provided in section 2.4 of the User Guide: <https://lpdaac.usgs.gov/documents/1574/ECOL2_User_Guide_V2.pdf>. Results downloaded from AppEEARS contain requested pixel/data values and decoded QA information associated with each pixel/data value extracted. For Land Surface Temperature and Emissivity (LSTE) product, the quality flags of the source data are available as a separate SDS layer in the ECO_L2T_LSTE.002 collection, however this Pixel Produced QA bit flags do not account for cloud cover. Users should apply the cloud mask separately to account for pixels with cloud when using ECO_L2T_LSTE.002 collection. In addition to decoded quality information, AppEEARS returns the cloud mask information for requests including layers from ECO_L2T_LSTE.002.

For high-level products, Cloud mask derived from ECO_L2_CLOUD.002 and Water mask derived from the Shuttle Radar Topography Mission (SRTM) Digital Elevation Model are available as separate science dataset (SDS) layers in the ECO_L2T_LSTE.002 data product.

### 4.8. ASTER GDEM v3 and Global Water Bodies Database v1  

ASTER GDEM v3 data are accompanied by an ancillary "NUM" file in place of the QA/QC files. The "NUM" files refer to the count of ASTER Level-1A scenes that were processed for each pixel or the source of reference data used to replace anomalies. The ASTER Global Water Bodies Database v1 products do not contain QA/QC files.  

- See Section 7 of the ASTER GDEM user guide: <https://lpdaac.usgs.gov/documents/434/ASTGTM_User_Guide_V3.pdf> for additional information regarding the GDEM "NUM" file.  
- See Section 7 of the ASTER Global Water Bodies Database user guide: <https://lpdaac.usgs.gov/documents/436/ASTWBD_User_Guide_V1.pdf> for a comparison with the SRTM Water Body Dataset.  

### 4.9. NASA MEaSUREs NASADEM v1 (30m)  

NASADEM v1 products are accompanied by an ancillary "NUM" file in place of the QA/QC files. The "NUM" files indicate the source of each NASADEM pixel, as well as the number of input data scenes used to generate the NASADEM v1 data for that pixel.  

- See the NASADEM user guide: <https://lpdaac.usgs.gov/documents/592/NASADEM_User_Guide_V1.pdf> for additional information regarding the NASADEM "NUM" file.  

### 4.10. HLS v2.0  

HLS v2.0 Operational Land Imager (OLI) Surface Reflectance and TOA Brightness Daily Global 30m (HLSL30 v002) and Sentinel-2 Multi-spectral Instrument (MSI) Surface Reflectance Daily Global 30m (HLSS30 v002) products have a quality assessment layer enabling per-pixel masking of cloud, cloud shadow, snow, water, and aerosol optical thickness levels. Quality information for HLSL30 v002 and HLSS30 v002 products, including bit definitions for the quality layer can be found in section 6.4 of the User Guide: <https://lpdaac.usgs.gov/documents/1326/HLS_User_Guide_V2.pdf>.  

### 4.11. Landsat Collection 2 ARD

Landsat C2 U.S. Analysis Ready Data (ARD) products are available for conterminous United States (CONUS)(1982-Present), Alaska (1984-present), and Hawaii (1989-1993, 1999-present). These data are products of Landsat 8/9 Operational Land Imager 2 (OLI-2) / Thermal Infrared Sensor 2 (TIRS-2), Landsat 7 Enhanced Thematic Mapper Plus (ETM+) and Landsat 4-5 Thematic Mapper (TM). The ARD significantly reduces the magnitude of data processing for application scientists. These data contain a quality assessment derived from Fmask version 3.3.1, Aerosol and Cloud QA derived from atmospheric compensation algorithms, and radiometric saturation QA derived from detector's input signal level. More details can be found in the Landsat Collection 2 U.S. ARD DFCB: <https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/media/files/LSDS-1435%20Landsat%20C2%20US%20ARD%20Data%20Format%20Control%20Book-v3.pdf>

### 4.12. US NPS Water Balance

The US NPS Historical Water Balance products do not have associated QA files or layers.

### 4.13. EMIT L1B Radiance and L2A Reflectance

The functionality of AppEEARS surrounding EMIT data is somewhat unique. There are currently no visualizations included within the AppEEARS UI, these will be added at a later date. Point requests return a comma separated variable (.csv) file organized in long format, rather than wide format to improve readability, resulting in some duplicate data for non-wavelength associated dimensions.  EMIT L1B At-Sensor Calibrated Radiance and Geolocation Data 60m (EMITL1BRAD) collection does not include quality information. EMIT L2A Estimated Surface Reflectance and Uncertainty and Masks 60m (EMITL2ARFL) collection does not have a direct quality assessment, but has a `good_wavelengths` flag associated with atmospheric water absorption features indicating where reflectance was not calculated. Additionally, the Reflectance Uncertainty product (EMIT_L2A_RFLUNCERT) contains uncertainty estimates about the reflectance captured as per-pixel, per-band posterior standard deviations, and the EMIT L2A Mask (EMIT_L2A_Mask) contains atmospheric state estimates and binary flags that can be used for quality filtering. By default the `good_wavelengths` layer is included with all requests that include the L2A Reflectance Product. More details about the EMIT_L2A_Mask can be found in the EMITL2ARFL User Guide: <https://lpdaac.usgs.gov/documents/1569/EMITL2ARFL_User_Guide_v1.pdf>

### 4.14. EMIT L2B Estimated Mineral Identification, Band Depth and Uncertainty

Similarly to the EMIT L1B Radiance and L2A Reflectance products, AppEEARS functionality for the EMIT L2B Mineralogy is also unique. The EMIT L2B Estimated Mineral Identification, Band Depth and Uncertainty 60m ([EMITL2BMIN](https://doi.org/10.5067/EMIT/EMITL2BMIN.001)) collection is generated using the [Tetracorder system](https://www.usgs.gov/publications/tetracorder-user-guide-version-44?_gl=1*1eoj33d*_ga*MTU3MTA3ODgxNS4xNjQ5MTg1MDgx*_ga_0YWDZEJ295*MTY4NjkyNTg0Mi40NC4xLjE2ODY5MjU4NzMuMC4wLjA.) ([code](https://github.com/PSI-edu/spectroscopy-tetracorder)). Point requests return a comma separated variable (.csv) file organized in long format, rather than wide format to improve readability, resulting in some duplicate data for non-group associated dimensions. These outputs also include quality data from the EMITL2BMINUNCERT product by default. This quality data includes the band depth uncertainty estimates and a fit score for the mineral identification. Band depth uncertainties are presented as standard deviations and the fit score is provided as the coefficient of determination (r^2) of the match between the continuum normalized library reference and the continuum normalized observed spectrum. There are currently no visualizations included within the AppEEARS UI, these will be added at a later date. More info can be found on the [EMITL2BMIN collection page](https://doi.org/10.5067/EMIT/EMITL2BMIN.001).

## 5. Data Caveats  

### 5.1.1. ECOSTRESS Swath V1 and V2

- ECOSTRESS Swath data products are natively stored in swath format. To fulfill AppEEARS requests for ECOSTRESS Swath products, the data are first resampled from the native swath format to a georeferenced output. This requires the use of the requested ECOSTRESS product files and the corresponding ECO1BGEO: <https://doi.org/10.5067/ECOSTRESS/ECO1BGEO.001> files for all ECOSTRESS Swath products. To do this conversion, an index array and distance array are created, then the nearest area pixel is located. Next, the Euclidean distance to that area pixel plus all surrounding pixels is measured within a 210 meter search radius (+/- a 3 pixels). This results in 49 pixels measured for every swath pixel. If the distance measured is less than what's currently present in any distance array, then the new distance as well as the swath index value are recorded into the index array used to convert to an area output.

### 5.1.2. ECOSTRESS Tiled V2

- It is not uncommon for many .csv cells returned to contain NaN values. If any layer requested or the QC layer contains valid data, the remaining requested layers will be returned even if only NaN values are present.

### 5.2. Suomi NPP VIIRS Land Surface Phenology Product (VNP22Q2)

- A subset of the science datasets/variables for VNP22Q2 are returned in their raw, unscaled form. That is, these variables are returned without having their scale factor and offset applied. AppEEARS visualizations and output summary files are derived using the raw data value, and consequently do not characterize the intended information ("day of year") for the impacted variables. The variables returned in this state include:  

    1. Date_Mid_Greenup_Phase (Cycle 1 and Cycle 2)  
    2. Date_Mid_Senescence_Phase (Cycle 1 and Cycle 2)  
    3. Onset_Greenness_Increase (Cycle 1 and Cycle 2)  
    4. Onset_Greenness_Decrease (Cycle 1 and Cycle 2)  
    5. Onset_Greenness_Maximum (Cycle 1 and Cycle 2)  
    6. Onset_Greenness_Minimum (Cycle 1 and Cycle 2)  

- To convert the raw data to "day of year" (doy) for the above variables, use the following equation:  

      doy = Raw_Data_Value * 1 – (Given_Year - 2000) * 366

### 5.3 SMAP

#### 5.3.1. SMAP Enhanced L3 Radiometer Global and Polar Grid Daily 9 km EASE-Grid Soil Moisture (SPL3SMP_E)

- The SPL3SMP_E includes additional layers for AM and PM north-polar grid soil moisture retrievals. These additional layers are not supported in AppEEARS.

#### 5.3.2. SMAP L4 Global 3-hourly 9 km EASE-Grid Surface and Root Zone Soil Moisture Geophysical Data (SPL4SMGP)

- The SPL4SMGP provides 3-hourly data within a single day. AppEEARS specify the observation date and time in the output CSV file.

### 5.4. HLS v2.0

- When requesting HLS timeseries, note that Sentinel-2 launched after Landsat was already active. Landsat OLI (HLSL30 v002) products are available from 2013-04-11 to present, while Sentinel-2 MSI products (HLSS30 v002) are available from  2015-11-30 to present.
- Point requests are returned in geographic coordinates.  
- Extra granules may appear in the granule list output file if the target point is close to an area where MGRS tiles overlap.
- Historical processing of the HLS Vegetation Indices (VI) products (HLSS30_VI v002 and HLSL30_VI v002) has not started as of May 9, 2025. Data currently available in AppEEARS is from February 6, 2025 to present.

### 5.5. GPW v4.11

- AppEEARS only provides access to GPW v4.11 Basic Demographic Characteristics estimates of population counts by age and sex for the year 2010. Estimates of population density by age and sex are not returned.  

### 5.6. GEOLST4KHR v002

- The NASA Making Earth System Data Records for Use in Research Environments (MEaSUREs) GEOLST4KHR version 2 data product are natively stored in swath format. Similar to ECOSTRESS Swath data, GEOLST4KHR data are first resampled from the native swath format to a georectified output. This nearest-neighbor resampling process will result in accuracy lost. To do this conversion, an index array and distance array are created, then the nearest area pixel is located. Next, the spherical distance to that area pixel plus all surrounding pixels is measured within a 12 kilometer search radius (+/- 3 to 21 pixels). The pixel search radius is dynamic based on current swath observation latitude. If the distance measured is less than what's currently present in any distance array, then the new distance as well as the swath index value are recorded into the index array used to convert to an area output.

- GEOLST4KHR version 2 data product does not have any associated quality layer.

### 5.7. MOD44B V6.1

- Value zero in the Cloud and Quality layers from MOD44B Version 6.1 Vegetation Continuous Fields (VCF) yearly product is assigned to Fill Value in the source file while value zero is meaningful for those layers. If comparing Cloud and Quality layers outputs with source files, users may notice that within the source files zero is assigned to fill value, however zero is within the valid range. Thus, AppEEARS outputs Use -999 as a fill value for those layers.

### 5.8. EMIT L1B Radiance and L2A Reflectance

- Elevation data is always included in requests. For API users there is an additional 'elev' layer listed, but that layer cannot be requested. This has to be present due to some constraints of AppEEARS' backend.
- For L1B Radiance and L2A reflectance products, the default included quality layer is 'good bands' which denotes where radiance/reflectance data were not estimated due to atmospheric water absorption features. This is included with all requests.
- The EMIT mission is focused on collecting data from land arid dust source regions, meaning that coverage is limited to those regions based upon a mask. You can explore coverage and forecasted coverage using Jet Propulsion Laboratory's [Visions: EMIT Open Data Portal](https://earth.jpl.nasa.gov/emit/data/data-portal/coverage-and-forecasts/)

### 5.9. EMIT L2B Estimated Mineral Identification, Band Depth and Uncertainty

- The EMIT_L2B_MIN product is generated to support the EMIT mission objectives of constraining the sign of dust-related radiative forcing. Ten mineral types are the core focus of this work: Calcite, Chlorite, Dolomite, Goethite, Gypsum, Hematite, Illite+Muscovite, Kaolinite, Montmorillonite, and Vermiculite. Additional minerals are included in this product for transparency but were not the focus of this product. Further validation is required to use these additional mineral maps, particularly in the case of resource exploration. Similarly, the separation of minerals with similar spectral features, such as a fine-grained goethite and hematite, is an active research area. The results presented here are an initial offering, but the precise categorization is likely to evolve, and the limits of what can and cannot be separated on a global scale are still being explored. The user is encouraged to read the Algorithm Theoretical Basis Document ([ATBD](https://lpdaac.usgs.gov/documents/1659/EMITL2B_ATBD_v1.pdf)) for more details.  
- "no_match" was added to the mineral library constituents for cases where no match was found via the tetracorder system (this has a value of 0 in the original data, but there is not an entry with an index of 0 in the "mineral_metadata" group).
- Elevation data is always included in requests. For API users there is an additional 'elev' layer listed, but that layer cannot be requested. This has to be present due to some constraints of AppEEARS' backend.

## 6. Documentation  

Documentation for data products available through AppEEARS are listed below.  

### 6.1. MODIS Land Products(Terra, Aqua, & Combined)  

- <https://lpdaac.usgs.gov/product_search/?collections=Combined+MODIS&collections=Terra+MODIS&collections=Aqua+MODIS&view=list>  

### 6.2. MODIS Snow Products (Terra and Aqua)  

- <https://nsidc.org/data/modis/data_summaries>  

### 6.3. NASA MEaSUREs SRTM v3  

- <https://doi.org/10.5067/MEASURES/SRTM/SRTMGL1.003>  
- <https://doi.org/10.5067/MEASURES/SRTM/SRTMGL1N.003>  
- <https://doi.org/10.5067/MEaSUREs/SRTM/SRTMGL3.003>  
- <https://doi.org/10.5067/MEASURES/SRTM/SRTMGL3N.003>  

### 6.4. NASA VIIRS Land Products  

- <https://www.earthdata.nasa.gov/data/catalog?keyword=VIIRS%20LP%20DAAC>  

### 6.5. SMAP Products  

- <http://nsidc.org/data/smap/smap-data.html>  

### 6.6. Daymet v4R1

- <https://doi.org/10.3334/ORNLDAAC/2129>
- <https://daymet.ornl.gov/>

### 6.7. ECOSTRESS  

- <https://www.earthdata.nasa.gov/data/catalog?keyword=ECOSTRESS&page_num=4>  

### 6.8. ASTER GDEM v3 and Global Water Bodies Database v1  

- <https://doi.org/10.5067/ASTER/ASTGTM.003>  
- <https://doi.org/10.5067/ASTER/ASTWBD.001>  

### 6.9. NASADEM  

- <https://doi.org/10.5067/MEaSUREs/NASADEM/NASADEM_NC.001>  
- <https://doi.org/10.5067/MEaSUREs/NASADEM/NASADEM_NUMNC.001> 

### 6.10. HLS v2.0  
 
- <https://doi.org/10.5067/HLS/HLSL30.002>  
- <https://doi.org/10.5067/HLS/HLSS30.002>  

### 6.11. GEOLST4KHR v002

- <https://doi.org/10.5067/MEaSUREs/LSTE/GEOLST4KHR.002>

### 6.12. Landsat ARD

- <https://doi.org/10.5066/P960F8OC>

### 6.13. US NPS Water Balance  

- [User Guide](https://screenedcleanedsummaries.s3.us-west-2.amazonaws.com/Gridded_Water_Balance_Model_April_2021.pdf)  

### 6.14. EMIT L1B Radiance and L2A Reflectance

- <https://doi.org/10.5067/EMIT/EMITL1BRAD.001>
- <https://doi.org/10.5067/EMIT/EMITL2ARFL.001>

### 6.15. EMIT L2B Estimated Mineral Identification, Band Depth and Uncertainty

- <https://doi.org/10.5067/EMIT/EMITL2BMIN.001>

### 6.16.  NASA VIIRS Snow Products (Includes Suomi NPP & NOAA-20)

- <https://doi.org/10.5067/45VDCKJBXWEE>

## 7. Sample Request Retention  

AppEEARS sample request outputs are available to download for a limited amount of time after completion. Please visit <https://appeears.earthdatacloud.nasa.gov/help?section=sample-retention> for details.  

## 8. Data Product Citations  

- Sun, S., Xiang, W., Ouyang, S., Hu, Y., & Peng, C. (2024). Balancing water yield and water use efficiency between planted and natural forests: A global analysis (Version 6). Dryad. https://doi.org/10.5061/DRYAD.2V6WWPZXM

Kida, M., & Wagai, R. (2025). Global database of Andisols and associated meta-data from literature. PANGAEA. https://doi.org/10.1594/PANGAEA.977631

Running, S., & Zhao, M. (2021). MODIS/Terra Net Primary Production Gap-Filled Yearly L4 Global 500m SIN Grid V061. NASA Land Processes Distributed Active Archive Center. https://doi.org/10.5067/MODIS/MOD17A3HGF.061

Kern, S. (2024). MODIS Collection 6.1 Sinusoidal Tiles Yearly gap-filled Gross and Net Primary Production (Version 2024_fv0.01). Universität Hamburg. https://doi.org/10.25592/UHHFDM.14632

Kern, S. (2024). MODIS Collection 6.1 Sinusoidal Tiles Yearly gap-filled Gross and Net Primary Production (Version 2024_fv0.01). Universität Hamburg. https://doi.org/10.25592/UHHFDM.14633

Kern, S. (2024). MODIS Collection 6.1 global yearly gap-filled Gross and Net Primary Production (Version 2024_fv0.01). Universität Hamburg. https://doi.org/10.25592/UHHFDM.14634

Kern, S. (2024). MODIS Collection 6.1 global yearly gap-filled Gross and Net Primary Production (Version 2024_fv0.01). Universität Hamburg. https://doi.org/10.25592/UHHFDM.14635. Accessed December 22, 2025.

## 9. Software Citation  

AppEEARS Team. (2025). Application for Extracting and Exploring Analysis Ready Samples (AppEEARS). Ver. 3.103. NASA EOSDIS Land Processes Distributed Active Archive Center (LP DAAC), USGS/Earth Resources Observation and Science (EROS) Center, Sioux Falls, South Dakota, USA. Accessed December 22, 2025. https://appeears.earthdatacloud.nasa.gov

## 10. Feedback  

We value your opinion. Please help us identify what works, what doesn't, and anything we can do to make AppEEARS better by submitting your feedback at https://appeears.earthdatacloud.nasa.gov/feedback or to LP DAAC User Services at <https://lpdaac.usgs.gov/lpdaac-contact-us/>
