# Original tables and environmental point inputs

Extract Source_Data_and_Environmental_Inputs.zip beside the `code` and `analysis_data` directories. This package supplies the original HomeRange database, trait tables, complete phylogeny, annual NPP point export, and derived current/future environmental point inputs. The default reconstruction uses these tables without downloading global rasters.

`source_input_verification.csv` records the six archived source-table filenames, sizes and SHA256 checksums. `current_environment_points_provenance.json` describes the supplied current-environment point table. `manifest_sha256.csv` covers all package files. Dataset citations and preprocessing details are in `DATA_SOURCES.md` and `../code/RAW_RECONSTRUCTION_NOTES.md`.

## Package contents

| Path | Input |
|---|---|
| `raw/HomeRangeData.csv` | Original HomeRange database snapshot |
| `external/PanTHERIA.txt` | PanTHERIA 1.0 species traits |
| `external/EltonTraits_mammals.txt` | EltonTraits 1.0 mammal traits |
| `external/mammal_tree_upham2019.nex` | Complete single-tree Upham input |
| `external/npp/npp_data.csv` | MOD17A3HGF.061 annual AppEEARS point export, 2001-2022 |
| `external/current_environment_points.csv` | 1,165 coordinate pairs with BIO1, BIO12, HFP, BIO4 and BIO15 values |
| `external/ssp/ssp_climate_points.csv` | Extracted BIO1/BIO12 and changes for four SSPs and four periods |
| `provenance/npp_appeears/` | Request parameters, metadata, granule list and service README |
| `external_raster_sources.csv` | Official sources and original SHA256 checksums for optional raster extraction |
| `external_raster_metadata.csv` | Dimensions, resolution, CRS and layers of the original rasters |

The global climate and HFP rasters are external downloads, rather than files in this package. The annual NPP export is the starting input for NPP aggregation; global MODIS image tiles are not required by the supplied workflow.

## Run reconstruction

Open R in the extracted `code` directory, install packages as described in its README, and run:

```r
Sys.setenv(ARTICLE3_DATA_ROOT = normalizePath("../raw_data"),
           ARTICLE3_CHECK_MODE = "raw",
           ARTICLE3_SEM_MODE = "refit",
           ARTICLE3_ENV_INPUT = "auto",
           ARTICLE3_SSP_INPUT = "auto")
source("scripts/00_preflight.R")
source("scripts/00_run_all.R")
source("scripts/00_verify_results.R")
```

With the supplied files, both `auto` settings select point inputs. Preflight checks seven required tables. The workflow rebuilds filtered records, traits, phylogeny and NPP, joins current environmental points by exact numeric coordinates, computes scenario inputs and refits the analyses. Use a fresh code extraction when changing input modes.

To compare the rebuilt preparation with the supplied analysis-data reference:

```r
Sys.setenv(ARTICLE3_ARCHIVE_ROOT = normalizePath("../analysis_data"))
source("validation/validate_raw_preparation.R")
```

The reference is used only by this comparison. Independent validation of the point-input workflow passed 111 preparation checks and 15 scientific result checks; details are in `../analysis_data/verification/light_validation_summary.txt`.

## Optional extraction from official rasters

`external_raster_sources.csv` lists each expected filename, placement path, official download location, version, resolution, period and original SHA256. Download manually, extract archives where needed, and preserve the listed filenames.

1. Download the [WorldClim 2.1 bioclimatic ZIP at 30 arc-seconds](https://geodata.ucdavis.edu/climate/worldclim/2_1/base/wc2.1_30s_bio.zip), using the [official baseline catalog](https://www.worldclim.org/data/worldclim21.html). Extract BIO1 and BIO12 to `external/current_climate/`. BIO4 and BIO15 may also be placed there to reconstruct the auxiliary seasonal columns. The main models use BIO1, BIO12 and HFP.
2. Open the [official Human Footprint dataset](https://datadryad.org/dataset/doi:10.5061/dryad.052q5) and select the **17 November 2016 version**, file **HumanFootprintv2.7z**. Extract it manually with 7-Zip or a compatible tool. Copy `Dryadv3/Maps/HFP2009.tif` to `external/hfp/HFP2009.tif`. Use the continuous floating-point file; the separate `HFP2009_int.tif` has different values. The archive member was verified against the original analysis raster; the record is in `provenance/hfp_archive_member_verification.json`.
3. Use the [official WorldClim CMIP6 2.5-minute catalog](https://www.worldclim.org/data/cmip6/cmip6_clim2.5m.html), selecting **BCC-CSM2-MR**, **bc** (bioclimatic), SSP126/245/370/585 and each of 2021-2040, 2041-2060, 2061-2080 and 2081-2100. Download all 16 listed TIFFs into `external/ssp/`; each contains 19 bioclimatic bands. The CSV provides direct official URLs for these files.
4. Compare the extracted/downloaded TIFF SHA256 values with the CSV. Then use a fresh code directory and run:

```r
Sys.setenv(ARTICLE3_DATA_ROOT = normalizePath("../raw_data"),
           ARTICLE3_CHECK_MODE = "raw",
           ARTICLE3_SEM_MODE = "refit",
           ARTICLE3_ENV_INPUT = "rasters",
           ARTICLE3_SSP_INPUT = "rasters")
source("scripts/00_preflight.R")
source("scripts/00_run_all.R")
source("scripts/00_verify_results.R")
```

Current and future extraction can be selected independently. `ARTICLE3_ENV_INPUT="rasters"` requires BIO1, BIO12 and HFP; BIO4/BIO15 are optional. `ARTICLE3_SSP_INPUT="rasters"` requires all 16 future files. `points` requires the corresponding supplied point table; `auto` uses it when present and otherwise searches for the corresponding raster inputs.

## Preparation details

NPP is the coordinate mean of valid annual values over 2001-2022, with a coordinate-level sample SD. Its join uses coordinates rounded to five decimals. Current-environment point joins use exact, unrounded coordinates. Future changes use BIO1 and BIO12 relative to the current baseline values.

The supplied phylogeny is the complete single `TREE1` input. Preparation prunes matching species, extends terminal branches to the maximum root-to-tip depth, and writes the adjusted tree at 10 significant digits. The unadjusted tree and adjustment log are also exported.

The AppEEARS request account identifier was removed from public metadata. The scientific point export and extraction parameters are preserved.
