# Input sources and versions

Paths below are relative to `raw_data`. `source_input_verification.csv` identifies the archived original tables by filename, size and SHA256. `manifest_sha256.csv` covers the supplied package files. `external_raster_sources.csv` identifies separately downloaded rasters and their original analysis checksums. The current and future point inputs are supplied derived extraction tables; global rasters are not bundled.

## HomeRange

Input: `raw/HomeRangeData.csv` (29,561,202 bytes).

Broekman, M., Hoeks, S., Freriks, R. et al. *HomeRange: A global database of mammalian home ranges*. [Dryad dataset](https://doi.org/10.5061/dryad.d2547d85x). Related publication: Broekman et al. (2023), *Global Ecology and Biogeography*, [doi:10.1111/geb.13625](https://doi.org/10.1111/geb.13625).

The archived CSV SHA256 is `d8ba9ac3012dfb45d3427a4e79a2ecba8ce3b004f67f7d5209656e40917f44fe`. An exact dated upstream release label has not been established; this checksum identifies the input snapshot. Encoding repair is applied to in-memory columns used for preparation.

## Species traits

`external/PanTHERIA.txt` is PanTHERIA 1.0 WR05 (upstream `PanTHERIA_1-0_WR05_Aug2008.txt`). Jones, K. E. et al. (2009), *PanTHERIA*, *Ecology* 90, 2648. [Article and dataset](https://doi.org/10.1890/08-1494.1); [official archived table](https://esapubs.org/archive/ecol/E090/184/PanTHERIA_1-0_WR05_Aug2008.txt).

`external/EltonTraits_mammals.txt` is the mammalian EltonTraits 1.0 table (upstream `MamFuncDat.txt`). Wilman, H. et al. (2014), *EltonTraits 1.0*, *Ecology* 95, 2027. [Article](https://doi.org/10.1890/13-1917.1); [versioned dataset collection](https://doi.org/10.6084/m9.figshare.c.3306933.v1); [official archived table](https://esapubs.org/archive/ecol/E095/178/MamFuncDat.txt).

Trait integration uses the documented EltonTraits-first priority, with measured HomeRange mass taking precedence where available.

## Mammalian phylogeny

`external/mammal_tree_upham2019.nex` (4,430,334 bytes) is the complete single `TREE1` input, with 5,912 tips including an outgroup. It is byte-identical to the original input named `mammal_tree_upham20191.tre` and was renamed to reflect its NEXUS format.

Upham, N. S., Esselstyn, J. A. & Jetz, W. (2019), *Inferring the mammal tree*, *PLOS Biology* 17, e3000494. [Article](https://doi.org/10.1371/journal.pbio.3000494); [Dryad source](https://doi.org/10.5061/dryad.tb03d03); [original tree download](https://data.vertlife.org/mammaltree/Completed_5911sp_topoCons_NDexp/MamPhy_BDvr_Completed_5911sp_topoCons_NDexp_v2_tree0000.tre).

Script 02 records pruning, terminal-edge extension and output precision in `phylogeny_preprocessing.csv`.

## Current environment

Supplied derived input: `external/current_environment_points.csv`, with 1,165 distinct coordinate pairs. It preserves the original extracted BIO1, BIO12, HFP, BIO4 and BIO15 values. Coordinates are joined exactly without rounding. BIO4/BIO15 are auxiliary columns; BIO1/BIO12/HFP are the main-model environmental predictors. Provenance is in `current_environment_points_provenance.json`.

Climate sources are WorldClim 2.1, 1970-2000 baseline, 30 arc-seconds, WGS84. The original single-band files have 21,600 rows and 43,200 columns. Optional retrieval uses the [official WorldClim catalog](https://www.worldclim.org/data/worldclim21.html) and [30-arc-second bioclimatic ZIP](https://geodata.ucdavis.edu/climate/worldclim/2_1/base/wc2.1_30s_bio.zip). Fick, S. E. & Hijmans, R. J. (2017), *WorldClim 2*, [doi:10.1002/joc.5086](https://doi.org/10.1002/joc.5086).

Human Footprint uses the 2009 continuous floating-point raster, Mollweide projection, 1,000-m cells. Obtain the [official Dryad dataset](https://datadryad.org/dataset/doi:10.5061/dryad.052q5), **17 November 2016** version, **HumanFootprintv2.7z**, and extract `Dryadv3/Maps/HFP2009.tif`. That archive member's SHA256 matches the original analysis raster; the verification record is in `provenance/hfp_archive_member_verification.json`. Venter, O. et al. (2016), [Human Footprint data description](https://doi.org/10.1038/sdata.2016.67), [related analysis](https://doi.org/10.1038/ncomms12558), [data DOI](https://doi.org/10.5061/dryad.052q5).

Original raster filenames, target placement paths, sizes, SHA256 values and official sources are in `external_raster_sources.csv`; grid details are in `external_raster_metadata.csv`.

## Net primary productivity

`external/npp/npp_data.csv` is the original annual AppEEARS point export: 38,324 rows, 1,742 point IDs, 2001-2022. The product/layer is **MOD17A3HGF.061 / Npp_500m**. The request completed on 22 December 2025 using AppEEARS 3.103. Request parameters, product metadata and the granule list are in `provenance/npp_appeears/`.

Running, S. & Zhao, M. (2021), *MODIS/Terra Net Primary Production Gap-Filled Yearly L4 Global 500m SIN Grid V061*. [NASA product DOI](https://doi.org/10.5067/MODIS/MOD17A3HGF.061). Extraction service: [AppEEARS](https://appeears.earthdatacloud.nasa.gov), accessed 22 December 2025.

Script 03 filters invalid values, computes the coordinate mean and sample SD across available annual values, and joins coordinates rounded to five decimals. The scientific export is unchanged; the public request metadata omits the account identifier.

## Future climate

Supplied derived input: `external/ssp/ssp_climate_points.csv`. It contains the original BIO1/BIO12 point extractions and scenario changes for all 16 combinations of four SSPs and four periods.

External raster source: WorldClim v2.1 downscaled CMIP6 **BCC-CSM2-MR**, at **2.5 arc-minutes**, SSP1-2.6/SSP2-4.5/SSP3-7.0/SSP5-8.5, periods 2021-2040/2041-2060/2061-2080/2081-2100. Each WGS84 TIFF has 4,320 rows, 8,640 columns and 19 bioclimatic bands. Script 03 uses bands 1 and 12.

The [official 2.5-minute download catalog](https://www.worldclim.org/data/cmip6/cmip6_clim2.5m.html) lists the corresponding BCC-CSM2-MR bioclimatic files; [CMIP6 overview](https://www.worldclim.org/data/cmip6/cmip6climate.html). Exact direct download URLs and original analysis SHA256 values are in `external_raster_sources.csv`. Selecting `ARTICLE3_SSP_INPUT="rasters"` recomputes point inputs after those 16 files are downloaded and placed in `external/ssp/`.
