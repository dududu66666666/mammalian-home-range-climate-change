# Run from the code repository root after scripts 01-03.
# This compares reconstructed model inputs with the separate archived data package.
source(file.path("R", "project_setup.R"))
check_required_packages(c("data.table", "ape"))
archive_root <- Sys.getenv("ARTICLE3_ARCHIVE_ROOT", unset = file.path(dirname(repo_root), "analysis_data"))
archived_file <- function(name) {
  paths <- file.path(archive_root, c("processed_data", "processed", "data/processed", ""), name)
  existing <- paths[file.exists(paths)]
  if (!length(existing)) stop(sprintf("Missing archived comparison input: %s", name))
  existing[1]
}
read_rebuilt <- function(name) data.table::fread(project_path("data", "processed", name))
read_archived <- function(name) data.table::fread(archived_file(name))
results <- list()
compare_column <- function(x, y, file, column, tolerance = 1e-10) {
  if (length(x) != length(y)) stop(sprintf("Length differs for %s: %s", file, column))
  different_na <- sum(is.na(x) != is.na(y))
  available <- !is.na(x) & !is.na(y)
  numeric_column <- is.numeric(x) && is.numeric(y)
  if (numeric_column) {
    delta <- abs(x[available] - y[available])
    changed <- sum(delta > tolerance)
    max_delta <- if (length(delta)) max(delta) else 0
  } else {
    changed <- sum(as.character(x[available]) != as.character(y[available]))
    max_delta <- NA_real_
  }
  data.frame(file = file, column = column, compared_rows = length(x),
             na_mismatches = different_na, value_mismatches = changed,
             max_absolute_difference = max_delta, tolerance = if (numeric_column) tolerance else NA_real_,
             pass = different_na == 0 && changed == 0)
}
record_name <- "hr_records_with_npp.csv"
records <- read_rebuilt(record_name)
archive_records <- read_archived(record_name)
require_columns(records, "source_row_id", record_name)
if (nrow(records) != nrow(archive_records) || anyDuplicated(records$source_row_id)) {
  stop("Rebuilt and archived record sets must have equal row counts and unique source row IDs.")
}
# Archived rows retain source order. Confirm immutable identity fields before attaching IDs.
data.table::setorder(records, source_row_id)
identity_fields <- c("study_id", "species", "ind_id", "home_range_km2", "latitude", "longitude", "year_mid")
for (column in identity_fields) {
  check <- compare_column(archive_records[[column]], records[[column]], record_name, column)
  if (!check$pass) stop(sprintf("Archived source order/identity differs at %s", column))
}
archive_records[, source_row_id := records$source_row_id]
data.table::setorder(archive_records, source_row_id)
record_fields <- c(identity_fields, "log_hr", "bio1_temp", "bio12_prec", "human_footprint",
                   "npp_mean", "npp_sd", "npp_final", "log_npp", "log_mass_final", "trophic_level", "hr_method_cat")
require_columns(records, record_fields, record_name)
require_columns(archive_records, record_fields, record_name)
for (column in record_fields) {
  results[[length(results) + 1L]] <- compare_column(archive_records[[column]], records[[column]], record_name, column)
}
species_name <- "hr_species_complete.csv"
species <- read_rebuilt(species_name)
archive_species <- read_archived(species_name)
if (anyDuplicated(species$species_tree) || !setequal(species$species_tree, archive_species$species_tree)) {
  stop("Rebuilt and archived species identifiers differ.")
}
data.table::setorder(species, species_tree)
data.table::setorder(archive_species, species_tree)
species_fields <- c("species_tree", "log_hr_mean", "log_mass_final", "trophic_level",
                    "bio1_temp_mean", "bio12_prec_mean", "hfp_mean", "n_records")
require_columns(species, species_fields, species_name)
require_columns(archive_species, species_fields, species_name)
for (column in species_fields) {
  results[[length(results) + 1L]] <- compare_column(archive_species[[column]], species[[column]], species_name, column)
}
ssp_name <- "ssp_climate_points.csv"
ssp <- read_rebuilt(ssp_name)
archive_ssp <- read_archived(ssp_name)
if (nrow(ssp) != nrow(archive_ssp)) stop("SSP point counts differ.")
require_columns(ssp, names(archive_ssp), ssp_name)
data.table::setorder(ssp, longitude, latitude)
data.table::setorder(archive_ssp, longitude, latitude)
for (column in names(archive_ssp)) {
  results[[length(results) + 1L]] <- compare_column(archive_ssp[[column]], ssp[[column]], ssp_name, column)
}
tree <- ape::read.tree(project_path("data", "processed", "mammal_tree_pruned.tre"))
archive_tree <- ape::read.tree(archived_file("mammal_tree_pruned.tre"))
if (!isTRUE(ape::all.equal.phylo(tree, archive_tree, use.edge.length = FALSE))) stop("Tree topology differs.")
vcv <- ape::vcv.phylo(tree)
archive_vcv <- ape::vcv.phylo(archive_tree)[rownames(vcv), colnames(vcv)]
results[[length(results) + 1L]] <- compare_column(as.vector(archive_vcv), as.vector(vcv),
                                                "mammal_tree_pruned.tre", "phylogenetic_covariance", tolerance = 1e-8)
table <- data.table::rbindlist(results)
write_csv(table, project_path("logs", "raw_preparation_validation.csv"))
if (any(!table$pass)) stop("Raw-preparation validation failed; see logs/raw_preparation_validation.csv")
message(sprintf("PASS: %d model/SSP input fields; %d records/%d species; %d phylogeny-matched species; %d SSP points.",
                nrow(table), nrow(records), length(unique(records$species)), nrow(species), nrow(ssp)))
