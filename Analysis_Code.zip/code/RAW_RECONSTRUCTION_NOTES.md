# Reconstruction from original tables and point inputs

Run preparation from the `code` directory with `ARTICLE3_DATA_ROOT` set to the extracted `raw_data` directory. Input searches use the code directory and the explicitly selected data root.

The default `ARTICLE3_ENV_INPUT="auto"` and `ARTICLE3_SSP_INPUT="auto"` select the supplied current and future environmental point tables. Filtering, trait integration, tree preparation and annual NPP aggregation are rebuilt from original tables, and the analyses are refitted. The global rasters are external downloads; optional retrieval and placement instructions are in `../raw_data/README.md`.

## Data preparation rules

1. Decode used text columns explicitly as UTF-8, with Windows-1252/Latin-1 recovery for legacy notes. The original input file is unchanged. Filtering retains valid coordinates, positive areas, midpoint year >=2000 and the exact source labels `Wild`, `Terrestrial` and `Individual`. This produces 30,519 records from 195 species.
2. Preserve case-sensitive method categories: `MCP`; the listed KDE variants; `AKDE`, `BRB`, `LOCOH` and `Brownian Bridge` as Advanced; all other labels as Other. The source label `LoCoH` is therefore Other. The original label is retained alongside the adjustment category.
3. Use EltonTraits as the species set and first trait body-mass source, with PanTHERIA fallback. Species mass first uses the geometric mean of positive measured HomeRange masses. Record mass uses that record's measured mass, with the combined trait table as fallback.
4. Read the supplied complete NEXUS `TREE1` input (5,912 tips), including the translation block, remove BEAST bracket annotations, recover species names and prune to the 182 matching species. Extend terminal edges to the maximum root-to-tip depth, then write the adjusted tree at 10 significant digits. The unadjusted pruned tree and maximum extension are exported; preparation requires the complete input tree.
5. Aggregate MOD17A3HGF.061 annual NPP values over 2001-2022. Exclude nonpositive values, fill values >=30000 and values >5 kg C m^-2 yr^-1. Compute the mean and sample SD by longitude/latitude rounded to five decimals, then join to records by those coordinates. `npp_preprocessing.csv` records this rule.
6. In current-environment point mode, require one row per exact, unrounded longitude/latitude pair in `current_environment_points.csv`, with numeric BIO1, BIO12, HFP, BIO4 and BIO15 fields. Reject duplicate pairs, missing fields and unmatched coordinates. BIO4/BIO15 are auxiliary seasonal descriptors; the main models use BIO1, BIO12 and HFP.
7. In current-environment raster mode, extract WorldClim 2.1 BIO1/BIO12 at study coordinates and transform coordinates to the HFP raster CRS before extraction. Optional BIO4/BIO15 rasters reconstruct their auxiliary columns. Retain the 30-arc-second baseline resolution and the continuous Mollweide 1-km HFP2009 file identified in the source manifest.
8. In future point mode, use the supplied `ssp_climate_points.csv`. In future raster mode, extract bands 1 and 12 from the 16 BCC-CSM2-MR 2.5-arc-minute bioclimatic TIFFs, then subtract the current baseline values. Required combinations are SSP126/245/370/585 and periods 2021-2040/2041-2060/2061-2080/2081-2100.

## Selecting inputs

`ARTICLE3_ENV_INPUT` and `ARTICLE3_SSP_INPUT` each accept `auto`, `points` or `rasters`. `points` requires the corresponding table; `rasters` forces raster extraction; `auto` selects points when available. The two settings are independent. Preflight requires seven tables for the supplied default workflow. With both settings set to `rasters`, it requires the five original tables plus 19 raster files; BIO4 and BIO15 are optional. Scripts do not fetch global rasters automatically.

Use a fresh code extraction before switching modes. Script 03 exports the actual input modes and environmental preprocessing details. Rerun preparation and the downstream models after changing modes.

## Validation

After preparation, set `ARTICLE3_ARCHIVE_ROOT` to the extracted `analysis_data` directory and source `validation/validate_raw_preparation.R`. The reference archive is used for comparison. The validator checks source-row identity, covariates, missingness, SSP fields and phylogenetic covariance, and writes `logs/raw_preparation_validation.csv`.

A previous independent reconstruction from the supplied original tables and environmental points passed all 111 preparation checks and all 15 core scientific result checks. Across 31 result tables and 734 compared fields in that recorded run, the maximum numeric difference was 2.240844e-9, within the 1e-8 result tolerance. Descriptive locality text differences after decoding are recorded separately. Full details are in `../analysis_data/verification/light_validation_summary.txt`.

The current statistical-summary export uses Pearson for species-level body mass and trophic level, Spearman for grouped warming across latitude zones and biogeographic regions, and descriptive climate-class summaries. It was regenerated from both archived inputs and the inputs/results of the independent reconstruction, with all 22 result checks passing in each run. See `../analysis_data/verification/trait_correlation_validation.md`. The historical full-workflow comparison logs retain their earlier summary snapshot; the current export and its validation supersede those summary rows.
