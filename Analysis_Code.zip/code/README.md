# Mammalian home-range analysis

Manuscript: *Thermal constraints rather than resource limitations shrink mammalian home ranges under climate change*.

This repository contains the R workflow, original database and trait inputs, environmental point inputs, analysis-ready data and fitted results.

## Extract the files

Extract Analysis_Code.zip, Analysis_Data_and_Results.zip and Source_Data_and_Environmental_Inputs.zip into the same parent folder:

```
release/
  code/R/                 code/scripts/
  code/vendor/            code/README.md
  analysis_data/data/processed/
  analysis_data/results/tables/
  analysis_data/results/models/
  raw_data/raw/HomeRangeData.csv
  raw_data/external/       raw_data/README.md
```

Each package has a SHA256 manifest. The raw-data package includes the original HomeRange, trait, phylogeny and annual NPP tables, plus current and future environmental point inputs. Global environmental rasters are obtained separately when spatial re-extraction is required; their official sources, versions and original checksums are listed in `../raw_data/external_raster_sources.csv`.

## Install and initialize

R 4.4.2 was used for validation. Open R in the `code` directory:

```r
source("scripts/00_install_packages.R")
.libPaths(c("local_library", .libPaths()))
```

The installer uses a project-local library. The official lavaan 0.6-20 source archive is included under `vendor`. Runtime package versions are exported to `results/tables/table_s5_software_environment.csv`. Scripts find inputs in the code directory and the directory specified by `ARTICLE3_DATA_ROOT`.

## 1. Published-results workflow

This workflow uses the archived models and inputs to regenerate figures and inspect the numerical products underlying the results.

```r
Sys.setenv(ARTICLE3_DATA_ROOT = normalizePath("../analysis_data"))
Sys.setenv(ARTICLE3_CHECK_MODE = "published")
source("scripts/00_preflight.R")
source("scripts/00_run_published_pipeline.R")
source("scripts/10_export_manuscript_statistics.R")
source("scripts/00_verify_results.R")
```

The following filenames are supplied for compatibility:

| Alternative filename | Canonical filename |
|---|---|
| msem_multilevel_v3_results.csv | msem_multilevel_results.csv |
| SEM_path_coefficients.csv | SEM_path_coefficients.csv |
| SEM_fit_measures.csv | msem_fit_measures.csv |

These files are in `results/tables` inside the analysis-data package. The package also contains the fitted SEM, LMM and PGLS objects, the data-filter log, SSP point inputs and supplementary tables.

## 2. Refit from analysis-ready data

This workflow re-estimates PGLS, LMM and multilevel SEM models, recomputes projections, and exports figures, supplementary tables and manuscript statistics.

```r
Sys.setenv(ARTICLE3_DATA_ROOT = normalizePath("../analysis_data"))
Sys.setenv(ARTICLE3_CHECK_MODE = "processed", ARTICLE3_SEM_MODE = "refit")
source("scripts/00_preflight.R")
source("scripts/00_run_processed.R")
source("scripts/00_verify_results.R")
```

## 3. Reconstruct from original tables and environmental point inputs

This workflow repeats data filtering, trait integration, tree preparation and NPP aggregation from the supplied original tables, joins the supplied environmental points, and refits the models.

```r
Sys.setenv(ARTICLE3_DATA_ROOT = normalizePath("../raw_data"),
           ARTICLE3_CHECK_MODE = "raw",
           ARTICLE3_SEM_MODE = "refit",
           ARTICLE3_ENV_INPUT = "auto",
           ARTICLE3_SSP_INPUT = "auto")
source("scripts/00_preflight.R")
source("scripts/00_run_all.R")
source("scripts/00_verify_results.R")
```

The default `auto` settings use `external/current_environment_points.csv` and `external/ssp/ssp_climate_points.csv` when available. Setting either input mode to `points` requires its point table. To recompute the corresponding inputs from environmental rasters, download and place the official files described in `../raw_data/README.md`, then set `ARTICLE3_ENV_INPUT="rasters"` and/or `ARTICLE3_SSP_INPUT="rasters"` before running preparation. The scripts do not download those large files automatically.

See `RAW_RECONSTRUCTION_NOTES.md` for preparation rules and `../raw_data/DATA_SOURCES.md` for provenance.

## Outputs and checks

Outputs are written inside `code/data/processed`, `code/results`, `code/figures` and `code/logs`. Start with a fresh code extraction before switching workflows so previously generated inputs do not take precedence over the selected data package. Figure layouts use the numerical data; assembled manuscript artwork is not required for computation.

Model checks use floating-point tolerances. `SEM_path_coefficients.csv` reports standardized coefficients, standard errors and confidence limits; it also retains unstandardized standard errors and the original Wald P values in separate columns. CSV files retain full-precision Akaike weights.

`scripts/10_export_manuscript_statistics.R` exports correlations, Kruskal-Wallis tests, within-diet regressions, the mass-diet interaction, body-mass coverage, species direction counts, climate-class summaries and the extra allometric model. Validation reports are in `../analysis_data/verification/`; `light_validation_summary.txt` describes the independent reconstruction using the supplied point inputs.

Associations of body mass and trophic level with species-level projected home-range change use Pearson correlation (r), focusing on SSP5-8.5 in 2081-2100. Correlations between mean warming and mean projected change across latitude zones and biogeographic regions use Spearman rank correlation. Climate-class outputs are descriptive summaries. The method, complete-pair sample size and full-precision test results are reported in `results/tables/manuscript_statistical_tests.csv`. The Pearson summaries are verified in `../analysis_data/verification/trait_correlation_validation.md`.

Code and data for this study are supplied together in this GitHub repository. Download the three archives listed above and preserve their extracted directory structure.
