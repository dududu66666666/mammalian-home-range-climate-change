options(stringsAsFactors = FALSE)

repo_root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)

project_path <- function(...) {
  file.path(repo_root, ...)
}

ensure_dir <- function(path) {
  dir.create(path, recursive = TRUE, showWarnings = FALSE)
  invisible(path)
}

ensure_project_dirs <- function() {
  dirs <- c(
    project_path("data", "raw"),
    project_path("data", "external"),
    project_path("data", "processed"),
    project_path("results", "tables"),
    project_path("results", "models"),
    project_path("figures", "main"),
    project_path("figures", "supplementary"),
    project_path("logs")
  )
  invisible(lapply(dirs, ensure_dir))
}

ensure_project_dirs()

check_required_packages <- function(pkgs) {
  missing <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing) > 0) {
    stop(
      sprintf(
        "Missing required packages: %s",
        paste(missing, collapse = ", ")
      ),
      call. = FALSE
    )
  }
}

path_is_absolute <- function(path) {
  grepl("^([A-Za-z]:|/|\\\\\\\\)", path)
}

get_search_roots <- function() {
  env_root <- Sys.getenv("ARTICLE3_DATA_ROOT", unset = "")
  unique(Filter(nzchar, c(repo_root, env_root)))
}

candidate_locations <- function(path) {
  if (path_is_absolute(path)) {
    return(path)
  }

  roots <- get_search_roots()
  # Accept the root of an extracted raw_data or analysis_data archive.
  relative_path <- sub("^data/", "", gsub("\\\\", "/", path))
  unique(c(
    file.path(repo_root, path),
    unlist(lapply(setdiff(roots, repo_root), function(root) {
      c(
        file.path(root, path),
        file.path(root, relative_path),
        file.path(root, basename(path)),
        file.path(root, "raw", basename(path)),
        file.path(root, "external", basename(path)),
        file.path(root, "processed", basename(path)),
        file.path(root, "processed_data", basename(path)),
        file.path(root, "results_tables", basename(path)),
        file.path(root, "results", "tables", basename(path))
      )
    }))
  ))
}

find_input <- function(candidates, type = c("file", "dir"), must_work = TRUE) {
  type <- match.arg(type)

  for (candidate in candidates) {
    for (location in candidate_locations(candidate)) {
      exists_here <- if (type == "file") file.exists(location) else dir.exists(location)
      if (exists_here) {
        return(normalizePath(location, winslash = "/", mustWork = TRUE))
      }
    }
  }

  if (must_work) {
    stop(
      sprintf(
        "Could not find required %s. Checked candidates:\n%s",
        type,
        paste(candidates, collapse = "\n")
      ),
      call. = FALSE
    )
  }

  NA_character_
}

require_columns <- function(data, columns, data_name = deparse(substitute(data))) {
  missing_cols <- setdiff(columns, names(data))
  if (length(missing_cols) > 0) {
    stop(
      sprintf(
        "%s is missing required columns: %s",
        data_name,
        paste(missing_cols, collapse = ", ")
      ),
      call. = FALSE
    )
  }
}

sanitize_text <- function(x) {
  if (is.factor(x)) {
    x <- as.character(x)
  }

  if (!is.character(x)) {
    return(x)
  }

  # Decode UTF-8 explicitly, independent of the operating-system locale.
  # Legacy notes may contain Windows-1252 bytes; handle them per string.
  convert <- function(values, from, sub = NA_character_) {
    vapply(values, function(value) {
      if (is.na(value)) return(NA_character_)
      tryCatch(suppressWarnings(iconv(value, from = from, to = "UTF-8", sub = sub)),
               error = function(e) NA_character_)
    }, character(1), USE.NAMES = FALSE)
  }
  out <- convert(x, "UTF-8")
  fallback_idx <- which(is.na(out) & !is.na(x))
  if (length(fallback_idx)) out[fallback_idx] <- convert(x[fallback_idx], "CP1252")
  fallback_idx <- which(is.na(out) & !is.na(x))
  if (length(fallback_idx)) out[fallback_idx] <- convert(x[fallback_idx], "latin1", sub = "")
  out
}

clean_text <- function(x) {
  x <- sanitize_text(x)
  if (!is.character(x)) {
    return(x)
  }
  trimws(x)
}

safe_numeric <- function(x) {
  x <- clean_text(x)

  if (is.numeric(x)) {
    return(as.numeric(x))
  }

  x[x %in% c("", "NA", "N/A", "na", "Na", "n/a")] <- NA_character_
  x <- gsub(",", "", x, fixed = TRUE)

  direct <- suppressWarnings(as.numeric(x))
  needs_parse <- is.na(direct) & !is.na(x) & nzchar(x)

  if (!any(needs_parse)) {
    return(direct)
  }

  parsed <- vapply(which(needs_parse), function(idx) {
    xi <- x[idx]
    matches <- regmatches(
      xi,
      gregexpr("[-+]?[0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?", xi, perl = TRUE)
    )[[1]]

    if (length(matches) == 0) {
      return(NA_real_)
    }

    nums <- suppressWarnings(as.numeric(matches))
    nums <- nums[!is.na(nums)]

    if (length(nums) == 0) {
      return(NA_real_)
    }

    if (
      length(nums) >= 2 &&
      grepl("[-/]| to ", xi, ignore.case = TRUE)
    ) {
      return(mean(nums[1:2]))
    }

    nums[1]
  }, numeric(1))

  direct[needs_parse] <- parsed
  direct
}

safe_log10 <- function(x) {
  x <- as.numeric(x)
  ifelse(is.na(x) | x <= 0, NA_real_, log10(x))
}

scale_z <- function(x) {
  x <- as.numeric(x)
  if (sum(!is.na(x)) < 2 || isTRUE(all.equal(stats::sd(x, na.rm = TRUE), 0))) {
    return(rep(NA_real_, length(x)))
  }
  as.numeric((x - mean(x, na.rm = TRUE)) / stats::sd(x, na.rm = TRUE))
}

geomean_positive <- function(x) {
  x <- as.numeric(x)
  x <- x[!is.na(x) & x > 0]
  if (length(x) == 0) {
    return(NA_real_)
  }
  10^mean(log10(x))
}

mode_value <- function(x) {
  x <- trimws(as.character(x))
  x <- x[!is.na(x) & nzchar(x)]
  if (length(x) == 0) {
    return(NA_character_)
  }
  names(sort(table(x), decreasing = TRUE))[1]
}

first_non_missing <- function(x) {
  x <- x[!is.na(x) & trimws(as.character(x)) != ""]
  if (length(x) == 0) {
    return(NA)
  }
  x[[1]]
}

standardize_species_name <- function(x) {
  x <- clean_text(x)
  x <- as.character(x)
  x <- gsub("\\s+", " ", x)
  x[x == ""] <- NA_character_
  gsub(" ", "_", x)
}

extract_tree_species_name <- function(x) {
  x <- clean_text(x)
  out <- sub("^([A-Z][a-z]+_[a-z-]+).*$", "\\1", x)
  out[out == ""] <- x[out == ""]
  out
}

classify_hr_method <- function(x) {
  x <- trimws(as.character(x))
  # Preserve the exact case-sensitive categories used to generate the archived data.
  dplyr::case_when(
    x %in% "MCP" ~ "MCP",
    x %in% c("KDE", "KDE (LSCV)", "KDE (href)", "KDE (ad hoc)") ~ "KDE",
    x %in% c("AKDE", "BRB", "LOCOH", "Brownian Bridge") ~ "Advanced",
    TRUE ~ "Other"
  )
}

classify_isopleth <- function(x) {
  x <- as.numeric(x)
  dplyr::case_when(
    x >= 95 ~ "95+",
    x >= 90 & x < 95 ~ "90-94",
    x < 90 ~ "<90",
    TRUE ~ "Unknown"
  )
}

format_p_value <- function(p) {
  dplyr::case_when(
    is.na(p) ~ NA_character_,
    p < 0.001 ~ "<0.001",
    TRUE ~ formatC(p, digits = 3, format = "f")
  )
}

significance_code <- function(p) {
  dplyr::case_when(
    is.na(p) ~ "",
    p < 0.001 ~ "***",
    p < 0.01 ~ "**",
    p < 0.05 ~ "*",
    TRUE ~ ""
  )
}

relevel_method <- function(x, reference = "MCP") {
  x <- factor(as.character(x))
  if (reference %in% levels(x)) {
    return(stats::relevel(x, ref = reference))
  }
  x
}

extract_raster_values <- function(raster_path, longitude, latitude, layer = NULL) {
  raster_obj <- terra::rast(raster_path)
  if (!is.null(layer)) {
    raster_obj <- raster_obj[[layer]]
  }
  pts <- terra::vect(cbind(longitude, latitude), crs = "EPSG:4326")
  terra::extract(raster_obj, pts)[, -1, drop = FALSE]
}

classify_lat_zone <- function(latitude) {
  dplyr::case_when(
    latitude >= 60 ~ "Arctic",
    latitude >= 40 & latitude < 60 ~ "N. Temperate",
    latitude >= 23.5 & latitude < 40 ~ "N. Subtropical",
    latitude >= 0 & latitude < 23.5 ~ "N. Tropical",
    latitude >= -23.5 & latitude < 0 ~ "S. Tropical",
    latitude >= -40 & latitude < -23.5 ~ "S. Subtropical",
    latitude < -40 ~ "S. Temperate",
    TRUE ~ NA_character_
  )
}

classify_region <- function(longitude, latitude) {
  dplyr::case_when(
    longitude >= -170 & longitude <= -50 & latitude >= 15 ~ "North America",
    longitude >= -90 & longitude <= -30 & latitude < 15 & latitude >= -60 ~ "South America",
    longitude >= -10 & longitude <= 40 & latitude >= 35 & latitude <= 72 ~ "Europe",
    longitude >= -20 & longitude <= 55 & latitude >= -35 & latitude < 35 ~ "Africa",
    longitude >= 40 & longitude <= 180 & latitude >= 35 ~ "N. Asia/C. Asia",
    longitude >= 60 & longitude <= 150 & latitude >= -10 & latitude < 35 ~ "S. Asia/SE Asia",
    longitude >= 110 & longitude <= 180 & latitude < -10 ~ "Australia",
    TRUE ~ "Other"
  )
}

classify_climate_zone <- function(bio1_temp, bio12_prec) {
  dplyr::case_when(
    is.na(bio1_temp) | is.na(bio12_prec) ~ NA_character_,
    bio1_temp < 0 ~ "Boreal/Alpine",
    bio1_temp >= 0 & bio12_prec < 500 ~ "Temperate Arid",
    bio1_temp >= 0 & bio12_prec >= 500 ~ "Temperate Humid",
    TRUE ~ NA_character_
  )
}

write_csv <- function(data, path) {
  ensure_dir(dirname(path))
  data.table::fwrite(data.table::as.data.table(data), path)
}

write_rds <- function(object, path) {
  ensure_dir(dirname(path))
  saveRDS(object, path)
}

save_plot_outputs <- function(plot, stem, subdir = c("main", "supplementary"), width_mm, height_mm, dpi = 600) {
  subdir <- match.arg(subdir)
  out_dir <- project_path("figures", subdir)
  ensure_dir(out_dir)
  pdf_file <- file.path(out_dir, paste0(stem, ".pdf"))
  png_file <- file.path(out_dir, paste0(stem, ".png"))

  ggplot2::ggsave(pdf_file, plot, width = width_mm, height = height_mm, units = "mm", bg = "white")
  ggplot2::ggsave(png_file, plot, width = width_mm, height = height_mm, units = "mm", dpi = dpi, bg = "white")

  invisible(c(pdf = pdf_file, png = png_file))
}

save_base_plot_outputs <- function(draw_fun, stem, subdir = c("main", "supplementary"), width_mm, height_mm, dpi = 600) {
  subdir <- match.arg(subdir)
  out_dir <- project_path("figures", subdir)
  ensure_dir(out_dir)

  pdf_file <- file.path(out_dir, paste0(stem, ".pdf"))
  png_file <- file.path(out_dir, paste0(stem, ".png"))

  grDevices::pdf(pdf_file, width = width_mm / 25.4, height = height_mm / 25.4, family = "sans")
  draw_fun()
  grDevices::dev.off()

  grDevices::png(png_file, width = width_mm / 25.4, height = height_mm / 25.4, units = "in", res = dpi)
  draw_fun()
  grDevices::dev.off()

  invisible(c(pdf = pdf_file, png = png_file))
}

theme_nc <- function(base_size = 11, base_family = "sans") {
  ggplot2::theme_classic(base_size = base_size, base_family = base_family) +
    ggplot2::theme(
      axis.line = ggplot2::element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = ggplot2::element_line(linewidth = 0.35, colour = "black"),
      axis.text = ggplot2::element_text(colour = "black"),
      axis.title = ggplot2::element_text(colour = "black"),
      plot.title = ggplot2::element_text(face = "bold", hjust = 0),
      plot.subtitle = ggplot2::element_text(colour = "gray35", hjust = 0),
      legend.title = ggplot2::element_text(face = "bold"),
      panel.border = ggplot2::element_rect(fill = NA, colour = "black", linewidth = 0.35),
      plot.background = ggplot2::element_rect(fill = "white", colour = NA)
    )
}
