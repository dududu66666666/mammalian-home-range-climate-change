source(file.path('R','project_setup.R'))
check_required_packages(c('data.table','dplyr','caper','ape'))
suppressPackageStartupMessages({library(data.table);library(dplyr);library(caper);library(ape)})
sp <- fread(find_input('results/tables/species_hr_predictions_mechanistic.csv'),data.table=FALSE)
records <- fread(find_input('results/tables/hr_records_ssp_predictions.csv'),data.table=FALSE)
full <- fread(find_input('data/processed/hr_species_with_traits.csv'),data.table=FALSE)
focus <- 'pct_hr_mean_ssp585_2081_2100'
rows <- list()
add_test <- function(name,test,n){rows[[length(rows)+1L]] <<- data.frame(
  analysis=name,method=test$method,n=n,statistic=unname(test$statistic),
  df=if(length(test$parameter))unname(test$parameter) else NA_real_,
  estimate=if(length(test$estimate))unname(test$estimate) else NA_real_,p_value=test$p.value)}
# Species-trait associations use Pearson correlation; grouped warming
# associations below use Spearman correlation.
for(trait in c('trophic_mean','log_mass_mean')){
  keep <- complete.cases(sp[,c(trait,focus)])
  add_test(paste('SSP5-8.5 2081-2100',trait),suppressWarnings(cor.test(
    sp[[trait]][keep],sp[[focus]][keep],method='pearson')),sum(keep))
}
for(group in c('diet','order')){
  dat <- sp[complete.cases(sp[,c(group,focus)]) & nzchar(as.character(sp[[group]])),]
  if(group=='order')dat <- dat[table(dat$order)[dat$order]>=5,]
  add_test(paste('Kruskal-Wallis',group,'order groups require >=5 species'),
           kruskal.test(dat[[focus]],as.factor(dat[[group]])),nrow(dat))
}
climate <- records %>% mutate(climate_zone=classify_climate_zone(bio1_temp,bio12_prec)) %>%
  filter(!is.na(climate_zone),!is.na(pct_hr_change_ssp585_2081_2100)) %>%
  group_by(climate_zone) %>% summarise(n_records=n(),n_species=n_distinct(species),
    mean_hr_change=mean(pct_hr_change_ssp585_2081_2100),
    sd_hr_change=sd(pct_hr_change_ssp585_2081_2100),
    mean_temp_increase=mean(delta_temp_ssp585_2081_2100),.groups='drop')
write_csv(climate,project_path('results','tables','hr_change_by_climate_zone.csv'))
for(group in c('latitude','region')){
  dat <- fread(find_input(paste0('results/tables/hr_change_by_',group,'.csv')),data.table=FALSE)
  add_test(paste('Warming vs home-range change across',group),suppressWarnings(
    cor.test(dat$mean_temp_increase,dat$mean_hr_change,method='spearman')),nrow(dat))
}
write_csv(bind_rows(rows),project_path('results','tables','manuscript_statistical_tests.csv'))
diet_fits <- bind_rows(lapply(c('Herbivore','Omnivore','Carnivore'),function(diet_name){
  dat <- sp[sp$diet %in% diet_name & complete.cases(sp[,c('log_mass_mean',focus)]),]
  fit <- lm(reformulate('log_mass_mean',response=focus),data=dat)
  coef <- summary(fit)$coefficients
  data.frame(diet=diet_name,n_species=nrow(dat),slope=coef[2,1],se=coef[2,2],
             p_value=coef[2,4],r_squared=summary(fit)$r.squared)
}))
write_csv(diet_fits,project_path('results','tables','within_diet_body_mass_regressions.csv'))
interaction_data <- sp[complete.cases(sp[,c('diet','log_mass_mean',focus)]) & nzchar(sp$diet),]
interaction_model <- lm(reformulate('log_mass_mean * diet',response=focus),data=interaction_data)
interaction_coefs <- as.data.frame(summary(interaction_model)$coefficients)
interaction_coefs$term <- rownames(interaction_coefs);rownames(interaction_coefs)<-NULL
write_csv(interaction_coefs,project_path('results','tables','body_mass_diet_interaction_coefficients.csv'))
f <- summary(interaction_model)$fstatistic
write_csv(data.frame(n_species=nrow(interaction_data),f_value=unname(f[1]),df1=unname(f[2]),
  df2=unname(f[3]),p_value=pf(f[1],f[2],f[3],lower.tail=FALSE),
  r_squared=summary(interaction_model)$r.squared),
  project_path('results','tables','body_mass_diet_interaction_summary.csv'))
mass_summaries <- bind_rows(lapply(list(full_filtered=full$log_mass_final,projection=sp$log_mass_mean),function(x){
  x<-10^x[!is.na(x)];q<-quantile(x,c(.25,.5,.75));
  data.frame(n_species=length(x),minimum=min(x),maximum=max(x),q1=q[1],median=q[2],q3=q[3],
    below_1_pct=100*mean(x<1),from_1_to_10_pct=100*mean(x>=1 & x<10),
    from_10_to_100_pct=100*mean(x>=10 & x<=100),above_100_pct=100*mean(x>100))
}))
mass_summaries$dataset<-c('full_filtered','projection')
write_csv(mass_summaries,project_path('results','tables','body_mass_coverage.csv'))
scenario_cols <- grep('^pct_hr_mean_',names(sp),value=TRUE)
write_csv(bind_rows(lapply(scenario_cols,function(col){x<-sp[[col]];x<-x[!is.na(x)];
  data.frame(scenario_key=sub('^pct_hr_mean_','',col),n_species=length(x),
    n_contracting=sum(x<0),n_expanding=sum(x>0),n_unchanged=sum(x==0),pct_expanding=100*mean(x>0))
})),project_path('results','tables','species_projection_direction_counts.csv'))
write_csv(sp[order(sp[[focus]]),],project_path('results','tables','species_projection_ranking.csv'))
species <- fread(find_input('data/processed/hr_species_complete.csv'),data.table=FALSE)
tree <- read.tree(find_input('data/processed/mammal_tree_pruned.tre'))
# The additional mass-only model used the complete trait/climate subset (168
# species), before the HFP completeness requirement of the main PGLS analysis.
keep <- complete.cases(species[,c('species_tree','log_mass_final','log_hr_mean',
  'trophic_level','bio1_temp_mean','bio12_prec_mean')]) & species$species_tree %in% tree$tip.label
mass_data <- species[keep,];mass_tree <- keep.tip(tree,mass_data$species_tree)
mass_data <- mass_data[match(mass_tree$tip.label,mass_data$species_tree),]
comp <- comparative.data(mass_tree,mass_data,names.col=species_tree,vcv=TRUE,na.omit=FALSE)
mass_fit <- pgls(log_hr_mean~log_mass_final,data=comp,lambda='ML')
coef <- summary(mass_fit)$coefficients
write_csv(data.frame(n_species=nrow(mass_data),slope=coef[2,1],se=coef[2,2],
  ci_lower=coef[2,1]-1.96*coef[2,2],ci_upper=coef[2,1]+1.96*coef[2,2],
  p_value=coef[2,4],Pagels_lambda=mass_fit$param['lambda']),
  project_path('results','tables','body_mass_only_allometric_PGLS.csv'))
write_rds(mass_fit,project_path('results','models','body_mass_only_allometric_PGLS.rds'))
message('10_export_manuscript_statistics.R completed.')
