source(file.path("R", "project_setup.R"))

check_required_packages(c(
  "data.table", "dplyr", "tidyr", "ggplot2", "patchwork",
  "sf", "rnaturalearth", "scales", "lavaan"
))

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(patchwork)
  library(sf)
  library(rnaturalearth)
  library(scales)
})

records_clean <- data.table::fread(find_input("data/processed/hr_records_clean.csv"))
filter_log <- data.table::fread(find_input("results/tables/data_filter_log.csv"))
msem_params <- data.table::fread(find_input("results/tables/msem_multilevel_results.csv"))
sem_paths <- data.table::fread(find_input("results/tables/SEM_path_coefficients.csv"))
records_pred <- data.table::fread(find_input("results/tables/hr_records_ssp_predictions.csv"))
species_pred <- data.table::fread(find_input("results/tables/species_hr_predictions_mechanistic.csv"))
scenario_stats <- data.table::fread(find_input("results/tables/full_scenario_statistics.csv"))
lat_summary <- data.table::fread(find_input("results/tables/hr_change_by_latitude.csv"))

world <- rnaturalearth::ne_countries(scale = "medium", returnclass = "sf")

ssp_colors <- c(
  "SSP1-2.6" = "#0072B2",
  "SSP2-4.5" = "#E69F00",
  "SSP3-7.0" = "#CC79A7",
  "SSP5-8.5" = "#D55E00"
)

diet_colors <- c(
  "Herbivore" = "#2CA25F",
  "Omnivore" = "#F28E2B",
  "Carnivore" = "#C44E52"
)

path_style <- function(beta, p) {
  sig <- !is.na(p) && p < 0.05
  list(
    colour = if (!sig) "gray65" else if (beta >= 0) "#C44E52" else "#4C72B0",
    linewidth = if (!sig || is.na(beta)) 0.6 else pmin(2.4, 0.8 + abs(beta) * 3),
    linetype = if (sig) "solid" else "dashed",
    label = if (is.na(beta)) "NA" else paste0(sprintf("%.2f", beta), significance_code(p))
  )
}

get_param <- function(label_name) {
  row <- msem_params[msem_params$label == label_name, ]
  if (nrow(row) == 0) {
    return(list(std = NA_real_, p = NA_real_, se = NA_real_))
  }
  list(std = row$std.all[1], p = row$pvalue[1], se = row$se[1])
}

save_main <- function(plot, stem, width_mm, height_mm) {
  save_plot_outputs(plot, stem, "main", width_mm, height_mm)
}

# Figure 1
grid_data <- records_clean %>%
  dplyr::filter(!is.na(longitude), !is.na(latitude)) %>%
  dplyr::mutate(
    lon_bin = round(longitude / 2) * 2,
    lat_bin = round(latitude / 2) * 2
  ) %>%
  dplyr::group_by(lon_bin, lat_bin) %>%
  dplyr::summarise(n_records = dplyr::n(), .groups = "drop")

p1a <- ggplot() +
  geom_sf(data = world, fill = "gray96", color = "gray75", linewidth = 0.2) +
  geom_tile(data = grid_data, aes(lon_bin, lat_bin, fill = log10(n_records + 1)), width = 2, height = 2, alpha = 0.85) +
  scale_fill_viridis_c(option = "plasma", name = "Records\n(log10)", breaks = c(0, 1, 2, 3), labels = c("1", "10", "100", "1000")) +
  coord_sf(xlim = c(-170, 180), ylim = c(-55, 75), expand = FALSE) +
  annotate("text", x = -165, y = 70, label = sprintf("n = %s records", scales::comma(nrow(records_clean))), hjust = 0, size = 3.5, fontface = "bold") +
  annotate("text", x = -165, y = 64, label = sprintf("%s species", dplyr::n_distinct(records_clean$species)), hjust = 0, size = 3.2) +
  labs(title = "A  Global distribution of home-range records") +
  theme_void() +
  theme(plot.title = element_text(face = "bold", hjust = 0), legend.position = "bottom")

step_counts <- filter_log %>%
  dplyr::filter(step %in% c("Raw records", "Years >= 2000", "Terrestrial species only", "Individual-level estimates only"))

boxes <- data.frame(
  x = 1,
  y = c(4, 3, 2, 1),
  label = c(
    sprintf("Raw database\n%s records", scales::comma(step_counts$n_records[step_counts$step == "Raw records"])),
    sprintf("Years >= 2000\n%s records", scales::comma(step_counts$n_records[step_counts$step == "Years >= 2000"])),
    sprintf("Wild terrestrial mammals\n%s records", scales::comma(step_counts$n_records[step_counts$step == "Terrestrial species only"])),
    sprintf("Final filtered dataset\n%s records | %s species", scales::comma(nrow(records_clean)), dplyr::n_distinct(records_clean$species))
  ),
  fill = c("#E8E8E8", "#D9E6F2", "#D9E6F2", "#CFE8C7")
)

p1b <- ggplot() +
  geom_rect(data = boxes, aes(xmin = 0, xmax = 2, ymin = y - 0.28, ymax = y + 0.28, fill = fill), color = "gray35", linewidth = 0.4) +
  geom_segment(aes(x = 1, xend = 1, y = 3.72, yend = 3.3), arrow = arrow(length = grid::unit(0.12, "inches"), type = "closed"), linewidth = 0.6) +
  geom_segment(aes(x = 1, xend = 1, y = 2.72, yend = 2.3), arrow = arrow(length = grid::unit(0.12, "inches"), type = "closed"), linewidth = 0.6) +
  geom_segment(aes(x = 1, xend = 1, y = 1.72, yend = 1.3), arrow = arrow(length = grid::unit(0.12, "inches"), type = "closed"), linewidth = 0.6) +
  geom_text(data = boxes, aes(x = x, y = y, label = label), size = 3.1, lineheight = 0.9) +
  scale_fill_identity() +
  coord_cartesian(xlim = c(-0.2, 2.2), ylim = c(0.5, 4.5)) +
  labs(title = "B  Data filtering workflow") +
  theme_void() +
  theme(plot.title = element_text(face = "bold", hjust = 0))

nodes <- data.frame(
  x = c(0, 0, 0, 4, 8, 8, 8),
  y = c(4, 2.5, 1, 2.5, 2.5, 4, 1),
  label = c("Temperature", "Precipitation", "HFP", "NPP", "Home range", "Body mass", "Trophic level"),
  fill = c("#FAD6D6", "#FAD6D6", "#FEE4CC", "#D7E8FA", "#D8F0D1", "#E8E8E8", "#E8E8E8")
)

p1c <- ggplot() +
  geom_curve(aes(x = 0.8, y = 4, xend = 3.3, yend = 2.8), curvature = -0.2, arrow = arrow(length = grid::unit(0.1, "inches"), type = "closed"), color = "#C44E52") +
  geom_segment(aes(x = 0.8, y = 2.5, xend = 3.3, yend = 2.5), arrow = arrow(length = grid::unit(0.1, "inches"), type = "closed"), color = "#C44E52") +
  geom_curve(aes(x = 0.8, y = 1, xend = 3.3, yend = 2.2), curvature = 0.2, arrow = arrow(length = grid::unit(0.1, "inches"), type = "closed"), color = "#F28E2B") +
  geom_segment(aes(x = 4.7, y = 2.5, xend = 7.2, yend = 2.5), arrow = arrow(length = grid::unit(0.1, "inches"), type = "closed"), color = "#4C72B0") +
  geom_curve(aes(x = 0.8, y = 4.3, xend = 7.2, yend = 3), curvature = -0.35, linetype = "dashed", arrow = arrow(length = grid::unit(0.08, "inches"), type = "closed"), color = "gray45") +
  geom_curve(aes(x = 0.8, y = 2.8, xend = 7.2, yend = 2.7), curvature = -0.15, linetype = "dashed", arrow = arrow(length = grid::unit(0.08, "inches"), type = "closed"), color = "gray45") +
  geom_curve(aes(x = 0.8, y = 0.7, xend = 7.2, yend = 2), curvature = 0.35, linetype = "dashed", arrow = arrow(length = grid::unit(0.08, "inches"), type = "closed"), color = "gray45") +
  geom_segment(aes(x = 8, y = 3.6, xend = 8, yend = 2.85), arrow = arrow(length = grid::unit(0.08, "inches"), type = "closed"), color = "gray40") +
  geom_segment(aes(x = 8, y = 1.35, xend = 8, yend = 2.15), arrow = arrow(length = grid::unit(0.08, "inches"), type = "closed"), color = "gray40") +
  geom_rect(data = nodes, aes(xmin = x - 0.85, xmax = x + 0.85, ymin = y - 0.3, ymax = y + 0.3, fill = fill), color = "gray35", linewidth = 0.4) +
  geom_text(data = nodes, aes(x, y, label = label), size = 3.1, lineheight = 0.9, fontface = "bold") +
  scale_fill_identity() +
  coord_equal(xlim = c(-1.5, 9.5), ylim = c(0.2, 4.8)) +
  labs(title = "C  Conceptual pathway framework") +
  theme_void() +
  theme(plot.title = element_text(face = "bold", hjust = 0))

workflow <- data.frame(
  x = c(1, 3, 5, 7),
  label = c("PGLS", "LMM", "Multilevel\nSEM", "SSP\nprojection"),
  fill = c("#DCE9F6", "#DCE9F6", "#D7ECD5", "#FDE4CF")
)

p1d <- ggplot() +
  geom_segment(aes(x = 1.55, xend = 2.45, y = 1, yend = 1), arrow = arrow(length = grid::unit(0.1, "inches"), type = "closed"), linewidth = 0.6, color = "gray50") +
  geom_segment(aes(x = 3.55, xend = 4.45, y = 1, yend = 1), arrow = arrow(length = grid::unit(0.1, "inches"), type = "closed"), linewidth = 0.6, color = "gray50") +
  geom_segment(aes(x = 5.55, xend = 6.45, y = 1, yend = 1), arrow = arrow(length = grid::unit(0.1, "inches"), type = "closed"), linewidth = 0.6, color = "gray50") +
  geom_rect(data = workflow, aes(xmin = x - 0.55, xmax = x + 0.55, ymin = 0.65, ymax = 1.35, fill = fill), color = "gray35", linewidth = 0.4) +
  geom_text(data = workflow, aes(x, 1, label = label), size = 3.1, fontface = "bold") +
  scale_fill_identity() +
  coord_cartesian(xlim = c(0.2, 7.8), ylim = c(0.5, 1.5)) +
  labs(title = "D  Analytical workflow") +
  theme_void() +
  theme(plot.title = element_text(face = "bold", hjust = 0))

fig1 <- p1a / (p1b | p1c) / p1d + plot_layout(heights = c(1.2, 1, 0.45))
save_main(p1a, "Figure1_panel_a", 210, 110)
save_main(p1b, "Figure1_panel_b", 120, 110)
save_main(p1c, "Figure1_panel_c", 170, 110)
save_main(p1d, "Figure1_panel_d", 180, 55)
save_main(fig1, "Figure1_combined", 210, 240)

# Figure 2
aw_bio1 <- get_param("aw_bio1"); aw_bio12 <- get_param("aw_bio12"); aw_hfp <- get_param("aw_hfp")
bw <- get_param("bw"); cw_bio1 <- get_param("cw_bio1"); cw_bio12 <- get_param("cw_bio12"); cw_hfp <- get_param("cw_hfp")
ab_bio1 <- get_param("ab_bio1"); ab_bio12 <- get_param("ab_bio12"); ab_hfp <- get_param("ab_hfp")
bb <- get_param("bb"); cb_mass <- get_param("cb_mass"); cb_troph <- get_param("cb_troph")
ind_bio1 <- get_param("indirect_within_bio1"); ind_bio12 <- get_param("indirect_within_bio12"); ind_hfp <- get_param("indirect_within_hfp")

draw_sem_panel <- function(level = c("within", "between")) {
  level <- match.arg(level)
  if (level == "within") {
    a1 <- path_style(aw_bio1$std, aw_bio1$p); a2 <- path_style(aw_bio12$std, aw_bio12$p); a3 <- path_style(aw_hfp$std, aw_hfp$p)
    b1 <- path_style(bw$std, bw$p); c1 <- path_style(cw_bio1$std, cw_bio1$p); c2 <- path_style(cw_bio12$std, cw_bio12$p); c3 <- path_style(cw_hfp$std, cw_hfp$p)
    subtitle <- "Within-species (record-level)"
  } else {
    a1 <- path_style(ab_bio1$std, ab_bio1$p); a2 <- path_style(ab_bio12$std, ab_bio12$p); a3 <- path_style(ab_hfp$std, ab_hfp$p)
    b1 <- path_style(bb$std, bb$p); c1 <- path_style(cb_mass$std, cb_mass$p); c2 <- path_style(cb_troph$std, cb_troph$p); c3 <- path_style(NA, 1)
    subtitle <- "Between-species (species-level)"
  }
  base <- ggplot() +
    geom_segment(aes(x = 1.2, y = 3.8, xend = 3.6, yend = 2.6), color = a1$colour, linewidth = a1$linewidth, linetype = a1$linetype, arrow = arrow(length = grid::unit(0.1, "inches"), type = "closed")) +
    geom_segment(aes(x = 1.2, y = 2.5, xend = 3.6, yend = 2.5), color = a2$colour, linewidth = a2$linewidth, linetype = a2$linetype, arrow = arrow(length = grid::unit(0.1, "inches"), type = "closed")) +
    geom_segment(aes(x = 1.2, y = 1.2, xend = 3.6, yend = 2.4), color = a3$colour, linewidth = a3$linewidth, linetype = a3$linetype, arrow = arrow(length = grid::unit(0.1, "inches"), type = "closed")) +
    geom_segment(aes(x = 4.4, y = 2.5, xend = 6.8, yend = 2.5), color = b1$colour, linewidth = b1$linewidth, linetype = b1$linetype, arrow = arrow(length = grid::unit(0.1, "inches"), type = "closed")) +
    annotate("rect", xmin = 0.2, xmax = 1.2, ymin = 3.45, ymax = 4.15, fill = "white") +
    annotate("rect", xmin = 0.2, xmax = 1.2, ymin = 2.15, ymax = 2.85, fill = "white") +
    annotate("rect", xmin = 0.2, xmax = 1.2, ymin = 0.85, ymax = 1.55, fill = "white") +
    annotate("rect", xmin = 3.6, xmax = 4.4, ymin = 2.15, ymax = 2.85, fill = "white") +
    annotate("rect", xmin = 6.8, xmax = 7.8, ymin = 2.15, ymax = 2.85, fill = "white") +
    annotate("text", x = 0.7, y = 3.8, label = "Temp", fontface = "bold") +
    annotate("text", x = 0.7, y = 2.5, label = "Precip", fontface = "bold") +
    annotate("text", x = 0.7, y = 1.2, label = "HFP", fontface = "bold") +
    annotate("text", x = 4.0, y = 2.5, label = "NPP", fontface = "bold") +
    annotate("text", x = 7.3, y = 2.5, label = "Home\nrange", fontface = "bold", lineheight = 0.9) +
    annotate("label", x = 2.5, y = 3.25, label = a1$label, size = 3, label.size = 0, fill = "white", color = a1$colour) +
    annotate("label", x = 2.5, y = 2.75, label = a2$label, size = 3, label.size = 0, fill = "white", color = a2$colour) +
    annotate("label", x = 2.5, y = 1.75, label = a3$label, size = 3, label.size = 0, fill = "white", color = a3$colour) +
    annotate("label", x = 5.6, y = 2.75, label = b1$label, size = 3, label.size = 0, fill = "white", color = b1$colour) +
    labs(subtitle = subtitle) +
    coord_equal(xlim = c(0, 8), ylim = c(0.6, 4.3)) +
    theme_void() +
    theme(plot.subtitle = element_text(face = "bold", hjust = 0))
  if (level == "within") {
    base <- base +
      geom_curve(aes(x = 1.2, y = 4.1, xend = 6.8, yend = 3.1), curvature = -0.3, color = c1$colour, linewidth = c1$linewidth, linetype = c1$linetype, arrow = arrow(length = grid::unit(0.08, "inches"), type = "closed")) +
      geom_curve(aes(x = 1.2, y = 2.8, xend = 6.8, yend = 2.8), curvature = -0.12, color = c2$colour, linewidth = c2$linewidth, linetype = c2$linetype, arrow = arrow(length = grid::unit(0.08, "inches"), type = "closed")) +
      geom_curve(aes(x = 1.2, y = 0.9, xend = 6.8, yend = 1.9), curvature = 0.3, color = c3$colour, linewidth = c3$linewidth, linetype = c3$linetype, arrow = arrow(length = grid::unit(0.08, "inches"), type = "closed")) +
      annotate("label", x = 4.5, y = 3.9, label = c1$label, size = 2.8, label.size = 0, fill = "white", color = c1$colour) +
      annotate("label", x = 4.5, y = 3.25, label = c2$label, size = 2.8, label.size = 0, fill = "white", color = c2$colour) +
      annotate("label", x = 4.5, y = 1.0, label = c3$label, size = 2.8, label.size = 0, fill = "white", color = c3$colour)
  } else {
    base <- base +
      geom_segment(aes(x = 7.3, y = 3.7, xend = 7.3, yend = 2.9), color = c1$colour, linewidth = c1$linewidth, linetype = c1$linetype, arrow = arrow(length = grid::unit(0.08, "inches"), type = "closed")) +
      geom_segment(aes(x = 7.1, y = 1.3, xend = 7.1, yend = 2.1), color = c2$colour, linewidth = c2$linewidth, linetype = c2$linetype, arrow = arrow(length = grid::unit(0.08, "inches"), type = "closed")) +
      annotate("text", x = 7.3, y = 4.05, label = paste0("Body mass\n", c1$label), size = 3) +
      annotate("text", x = 7.1, y = 0.85, label = paste0("Trophic level\n", c2$label), size = 3)
  }
  base
}

p2a <- draw_sem_panel("within") + labs(title = "A  Within-species path diagram") +
  theme(plot.title = element_text(size = 12, face = "bold"))
p2b <- draw_sem_panel("between") + labs(title = "B  Between-species path diagram") +
  theme(plot.title = element_text(size = 12, face = "bold"))

effect_data <- data.frame(
  Variable = factor(c("Temperature", "Precipitation", "Human footprint"), levels = c("Human footprint", "Precipitation", "Temperature")),
  Direct = c(cw_bio1$std, cw_bio12$std, cw_hfp$std),
  Indirect = c(ind_bio1$std, ind_bio12$std, ind_hfp$std)
) %>% mutate(Total = Direct + Indirect)

p2c <- effect_data %>%
  tidyr::pivot_longer(c(Direct, Indirect), names_to = "Type", values_to = "Beta") %>%
  ggplot(aes(Variable, Beta, fill = Type)) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray55") +
  geom_col(width = 0.65) +
  coord_flip() +
  scale_fill_manual(values = c("Direct" = "#4C72B0", "Indirect" = "#55A868")) +
  labs(title = "C  Direct versus indirect effects", x = NULL, y = "Standardized effect") +
  theme_nc() +
  theme(legend.position = "bottom", plot.title = element_text(size = 12, face = "bold"))

# Standardized CIs must come from standardizedSolution, not the raw model SE.
forest_fit <- readRDS(find_input("results/models/msem_multilevel_model.rds"))
stopifnot(lavaan::lavInspect(forest_fit, "converged"))
forest_std <- lavaan::standardizedSolution(forest_fit, type = "std.all",
                                         se = TRUE, ci = TRUE, level = 0.95)
forest_raw <- lavaan::parameterEstimates(forest_fit, standardized = TRUE)
forest_data <- data.frame(
  Level = factor(c(rep("Within-species", 7), rep("Between-species", 3)),
                 levels = c("Within-species", "Between-species")),
  Path = c("Temp -> NPP", "Precip -> NPP", "HFP -> NPP", "NPP -> HR",
           "Temp -> HR", "Precip -> HR", "HFP -> HR", "Body mass -> HR",
           "Trophic level -> HR", "NPP -> HR"),
  label = c("aw_bio1", "aw_bio12", "aw_hfp", "bw", "cw_bio1", "cw_bio12",
            "cw_hfp", "cb_mass", "cb_troph", "bb"),
  y = c(10:4, 2:0), stringsAsFactors = FALSE
)
forest_data$Path <- gsub("->", "\u2192", forest_data$Path, fixed = TRUE)
forest_std_rows <- match(forest_data$label, forest_std$label)
forest_raw_rows <- match(forest_data$label, forest_raw$label)
stopifnot(!anyNA(forest_std_rows), !anyNA(forest_raw_rows))
forest_data$Beta <- forest_std$est.std[forest_std_rows]
forest_data$SE_std <- forest_std$se[forest_std_rows]
forest_data$CI_lower <- forest_std$ci.lower[forest_std_rows]
forest_data$CI_upper <- forest_std$ci.upper[forest_std_rows]
# Retain the original model Wald tests for the significance symbols.
forest_data$p_value_original <- forest_raw$pvalue[forest_raw_rows]
forest_data$Significance <- significance_code(forest_data$p_value_original)
forest_data$Estimate_label <- paste0(sprintf("%.2f", forest_data$Beta), forest_data$Significance)
stopifnot(max(abs(forest_data$Beta - forest_raw$std.all[forest_raw_rows])) < 1e-10)
write_csv(forest_data, project_path("results", "tables", "Figure2D_plot_data.csv"))
write_csv(forest_std, project_path("results", "tables", "SEM_standardized_parameters.csv"))
forest_colors <- c("Within-species" = "#0072B2", "Between-species" = "#D55E00")
forest_headers <- data.frame(
  Level = factor(c("Within-species", "Between-species"), levels = levels(forest_data$Level)),
  x = -0.55, y = c(11.15, 3.12), text = c("Within-species", "Between-species")
)
p2d <- ggplot(forest_data, aes(Beta, y)) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "#838383", linewidth = 0.3) +
  geom_hline(yintercept = 3.52, color = "#CDCDCD", linewidth = 0.3) +
  geom_segment(aes(x = CI_lower, xend = CI_upper, yend = y, color = Level), linewidth = 0.45) +
  geom_point(aes(color = Level, shape = Level), size = 0.85) +
  geom_segment(aes(x = CI_lower, xend = CI_lower, y = y - 0.18, yend = y + 0.18, color = Level), linewidth = 0.32) +
  geom_segment(aes(x = CI_upper, xend = CI_upper, y = y - 0.18, yend = y + 0.18, color = Level), linewidth = 0.32) +
  geom_text(aes(x = 1.17, label = Estimate_label), hjust = 0, size = 2.65, color = "#262626") +
  annotate("rect", xmin = -0.57, xmax = 1.54, ymin = 10.6, ymax = 11.65, fill = "white", color = NA) +
  annotate("rect", xmin = -0.57, xmax = 1.54, ymin = 2.64, ymax = 3.43, fill = "white", color = NA) +
  geom_text(data = forest_headers, aes(x = x, y = y, label = text, color = Level),
            inherit.aes = FALSE, hjust = 0, size = 2.8, fontface = "bold", show.legend = FALSE) +
  scale_color_manual(values = forest_colors, name = NULL) +
  scale_shape_manual(values = c("Within-species" = 16, "Between-species" = 18), name = NULL) +
  scale_y_continuous(breaks = forest_data$y, labels = forest_data$Path,
                     limits = c(-0.55, 11.65), expand = expansion(mult = 0)) +
  scale_x_continuous(breaks = seq(-0.4, 1, by = 0.2), limits = c(-0.57, 1.54),
                     expand = expansion(mult = 0)) +
  labs(title = "D", x = expression("Standardized path coefficient (" * beta * ")"), y = NULL) +
  guides(color = guide_legend(override.aes = list(size = 2.15)), shape = guide_legend()) +
  theme_minimal(base_size = 8.5) +
  theme(panel.grid.major.y = element_blank(), panel.grid.minor = element_blank(),
        panel.grid.major.x = element_line(color = "#E8E8E8", linewidth = 0.25),
        axis.text = element_text(color = "#333333", size = 7.5),
        axis.text.y = element_text(margin = margin(r = 3)),
        axis.title.x = element_text(size = 8.2, margin = margin(t = 5)),
        plot.title = element_text(size = 12, face = "bold"), plot.title.position = "plot",
        legend.position = "top", legend.justification = "left", legend.text = element_text(size = 8),
        plot.margin = margin(4, 4, 4, 4), plot.background = element_rect(fill = "white", color = NA))

fig2 <- (p2a | p2b) / (p2c | p2d)
save_main(p2a, "Figure2_panel_a", 160, 120)
save_main(p2b, "Figure2_panel_b", 160, 120)
save_main(p2c, "Figure2_panel_c", 150, 120)
save_main(p2d, "Figure2_panel_d", 150, 120)
save_main(fig2, "Figure2_combined", 210, 180)

# Figure 3
scenario_cols <- grep("^pct_hr_mean_", names(species_pred), value = TRUE)
plot_data <- species_pred %>%
  dplyr::select(species, dplyr::all_of(scenario_cols)) %>%
  tidyr::pivot_longer(dplyr::all_of(scenario_cols), names_to = "scenario_period", values_to = "pct_change") %>%
  dplyr::mutate(
    scenario = dplyr::case_when(grepl("ssp126", scenario_period) ~ "SSP1-2.6", grepl("ssp245", scenario_period) ~ "SSP2-4.5", grepl("ssp370", scenario_period) ~ "SSP3-7.0", grepl("ssp585", scenario_period) ~ "SSP5-8.5"),
    period = dplyr::case_when(grepl("2021_2040", scenario_period) ~ "2021-2040", grepl("2041_2060", scenario_period) ~ "2041-2060", grepl("2061_2080", scenario_period) ~ "2061-2080", grepl("2081_2100", scenario_period) ~ "2081-2100"),
    scenario = factor(scenario, levels = names(ssp_colors)),
    period = factor(period, levels = c("2021-2040", "2041-2060", "2061-2080", "2081-2100"))
  )

p3a <- ggplot(plot_data, aes("", pct_change, fill = scenario)) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray55") +
  geom_violin(color = NA, alpha = 0.9) +
  geom_boxplot(width = 0.14, fill = "white", outlier.shape = NA) +
  facet_grid(scenario ~ period, switch = "both") +
  scale_fill_manual(values = ssp_colors, guide = "none") +
  labs(title = "A  Projected change across all SSP-period combinations", x = NULL, y = "Home-range change (%)") +
  theme_nc() +
  theme(strip.background = element_blank(), axis.text.x = element_blank(), axis.ticks.x = element_blank())

scenario_stats <- scenario_stats %>%
  dplyr::mutate(
    year_mid = c(
      "2021-2040" = 2030,
      "2041-2060" = 2050,
      "2061-2080" = 2070,
      "2081-2100" = 2090
    )[as.character(period)]
  )
p3b <- ggplot(scenario_stats, aes(year_mid, mean_change, color = scenario, fill = scenario)) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray55") +
  geom_ribbon(aes(ymin = mean_change - sd_change / sqrt(n_species), ymax = mean_change + sd_change / sqrt(n_species)), alpha = 0.16, color = NA) +
  geom_line(linewidth = 0.9) +
  geom_point(shape = 21, color = "white", size = 2.5) +
  scale_color_manual(values = ssp_colors) +
  scale_fill_manual(values = ssp_colors) +
  labs(title = "B  Mean projected change through time", x = "Year", y = "Mean home-range change (%)", color = NULL, fill = NULL) +
  theme_nc() +
  theme(legend.position = "top")

spatial_data <- records_pred %>%
  dplyr::filter(!is.na(longitude), !is.na(latitude), !is.na(pct_hr_change_ssp585_2081_2100)) %>%
  dplyr::mutate(lon_bin = round(longitude / 5) * 5, lat_bin = round(latitude / 5) * 5) %>%
  dplyr::group_by(lon_bin, lat_bin) %>%
  dplyr::summarise(mean_change = mean(pct_hr_change_ssp585_2081_2100, na.rm = TRUE), n = dplyr::n(), .groups = "drop") %>%
  dplyr::filter(n >= 3)

p3c <- ggplot() +
  geom_sf(data = world, fill = "gray96", color = "gray75", linewidth = 0.2) +
  geom_tile(data = spatial_data, aes(lon_bin, lat_bin, fill = mean_change), width = 5, height = 5, alpha = 0.9) +
  scale_fill_gradient2(low = "#D6604D", mid = "white", high = "#4393C3", midpoint = -50, limits = c(-80, -20), oob = squish, name = "HR change (%)") +
  coord_sf(xlim = c(-170, 180), ylim = c(-55, 75), expand = FALSE) +
  labs(title = "C  Spatial heterogeneity under SSP5-8.5 (2081-2100)") +
  theme_void() +
  theme(plot.title = element_text(face = "bold", hjust = 0), legend.position = "bottom")

label_pos <- data.frame(
  lat_zone = c("S. Temperate", "N. Tropical", "S. Subtropical", "S. Tropical", "N. Subtropical", "N. Temperate", "Arctic"),
  label_short = c("S. Temp.", "N. Trop.", "S. Subtrop.", "S. Trop.", "N. Subtrop.", "N. Temp.", "Arctic"),
  label_x = c(3.22, 4.28, 4.70, 5.02, 5.24, 6.10, 6.12),
  label_y = c(-39.2, -39.0, -52.0, -50.2, -57.1, -63.4, -68.7)
)
lat_plot <- lat_summary %>% dplyr::left_join(label_pos, by = "lat_zone")
fit_lat <- lm(mean_hr_change ~ mean_temp_increase, data = lat_plot)

p3d <- ggplot(lat_plot, aes(mean_temp_increase, mean_hr_change)) +
  geom_smooth(method = "lm", se = TRUE, color = "#D6604D", fill = "#D6604D", alpha = 0.18) +
  geom_segment(aes(xend = label_x, yend = label_y), linewidth = 0.25, color = "gray35") +
  geom_point(aes(size = n_records), shape = 21, fill = "#E46D54", color = "#D6604D", stroke = 0.3) +
  geom_text(aes(label_x, label_y, label = label_short), hjust = 0, size = 2.8) +
  annotate("text", x = 6.45, y = -36, hjust = 1, vjust = 1, size = 3, label = sprintf("R2 = %.2f\nSlope = %.1f%%/deg C", summary(fit_lat)$r.squared, coef(fit_lat)[2])) +
  scale_size_continuous(range = c(2.5, 5), guide = "none") +
  labs(title = "D  Warming versus contraction across latitude zones", x = "Temperature increase (deg C)", y = "Home-range change (%)") +
  theme_nc()

fig3 <- (p3a / p3b) | (p3c / p3d)
save_main(p3a, "Figure3_panel_a", 210, 180)
save_main(p3b, "Figure3_panel_b", 210, 90)
save_main(p3c, "Figure3_panel_c", 140, 110)
save_main(p3d, "Figure3_panel_d", 120, 100)
save_main(fig3, "Figure3_combined", 230, 210)

# Figure 4
focus_col <- "pct_hr_mean_ssp585_2081_2100"
top20 <- species_pred %>%
  dplyr::filter(!is.na(.data[[focus_col]])) %>%
  dplyr::arrange(.data[[focus_col]]) %>%
  dplyr::slice_head(n = 20) %>%
  dplyr::mutate(species_label = factor(gsub("_", " ", species), levels = rev(gsub("_", " ", species))))

p4a <- ggplot(top20, aes(species_label, .data[[focus_col]], fill = diet)) +
  geom_col(width = 0.75, alpha = 0.9) +
  geom_text(aes(label = sprintf("%.0f%%", .data[[focus_col]])), hjust = 1.05, color = "white", size = 2.7, fontface = "bold") +
  coord_flip() +
  scale_fill_manual(values = diet_colors, na.value = "gray75") +
  labs(title = "A  Top 20 species with the largest projected contractions", x = NULL, y = "Home-range change (%)", fill = "Diet") +
  theme_nc() +
  theme(axis.text.y = element_text(face = "italic"), legend.position = "bottom")

diet_data <- species_pred %>%
  dplyr::filter(!is.na(diet), !is.na(.data[[focus_col]])) %>%
  dplyr::mutate(diet = factor(diet, levels = c("Herbivore", "Omnivore", "Carnivore")))
diet_kw <- kruskal.test(diet_data[[focus_col]] ~ diet_data$diet)

p4b <- ggplot(diet_data, aes(diet, .data[[focus_col]], fill = diet)) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray55") +
  geom_violin(alpha = 0.7, color = NA) +
  geom_boxplot(width = 0.14, fill = "white", outlier.shape = NA) +
  annotate("text", x = 1.2, y = max(diet_data[[focus_col]], na.rm = TRUE), hjust = 0, vjust = 1, label = paste0("Kruskal-Wallis p ", format_p_value(diet_kw$p.value)), size = 3) +
  scale_fill_manual(values = diet_colors, na.value = "gray75", guide = "none") +
  labs(title = "B  Comparison among dietary groups", x = NULL, y = "Home-range change (%)") +
  theme_nc()

order_data <- species_pred %>%
  dplyr::filter(!is.na(order), !is.na(.data[[focus_col]])) %>%
  dplyr::group_by(order) %>%
  dplyr::mutate(n_order = dplyr::n()) %>%
  dplyr::ungroup() %>%
  dplyr::filter(n_order >= 5) %>%
  dplyr::mutate(order = reorder(order, .data[[focus_col]], median))
order_kw <- kruskal.test(order_data[[focus_col]] ~ order_data$order)
order_stats <- order_data %>% dplyr::group_by(order) %>% dplyr::summarise(n = dplyr::n(), .groups = "drop")

p4c <- ggplot(order_data, aes(order, .data[[focus_col]], fill = order)) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray55") +
  geom_boxplot(alpha = 0.85, outlier.size = 1.2) +
  geom_text(data = order_stats, aes(order, min(order_data[[focus_col]], na.rm = TRUE), label = paste0("n=", n)), inherit.aes = FALSE, size = 2.6, vjust = 1.4) +
  annotate("text", x = 1.2, y = max(order_data[[focus_col]], na.rm = TRUE), hjust = 0, vjust = 1, label = paste0("Kruskal-Wallis p ", format_p_value(order_kw$p.value)), size = 3) +
  scale_fill_brewer(palette = "Set3", guide = "none") +
  coord_flip() +
  labs(title = "C  Comparison among mammalian orders", x = NULL, y = "Home-range change (%)") +
  theme_nc() +
  theme(axis.text.y = element_text(face = "bold", size = 9))

fig4 <- p4a | (p4b / p4c)
save_main(p4a, "Figure4_panel_a", 170, 170)
save_main(p4b, "Figure4_panel_b", 140, 120)
save_main(p4c, "Figure4_panel_c", 160, 150)
save_main(fig4, "Figure4_combined", 220, 180)

message("06_make_main_figures.R completed.")
