source(file.path("R", "project_setup.R"))

software_packages <- c(
  "data.table", "dplyr", "tidyr", "ggplot2", "terra", "ape", "caper",
  "lme4", "lmerTest", "MuMIn", "lavaan", "patchwork", "rnaturalearth"
)
# Check the software inventory before fitting any models, so S5 never invents
# or silently omits package versions and installation errors occur early.
check_required_packages(software_packages)

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
  library(ape)
  library(lme4)
  library(lmerTest)
  library(MuMIn)
})

records_clean_file <- find_input("data/processed/hr_records_clean.csv")
species_complete_file <- find_input("data/processed/hr_species_complete.csv")
records_npp_file <- find_input("data/processed/hr_records_with_npp.csv")
records_pred_file <- find_input("results/tables/hr_records_ssp_predictions.csv")
species_pred_file <- find_input("results/tables/species_hr_predictions_mechanistic.csv")
tree_file <- find_input("data/processed/mammal_tree_pruned.tre")
pgls_file <- find_input("results/tables/pgls_model_comparison.csv")

hr_records_clean <- data.table::fread(records_clean_file)
hr_species_complete <- data.table::fread(species_complete_file)
hr_records_npp <- data.table::fread(records_npp_file)
hr_records_pred <- data.table::fread(records_pred_file)
species_pred <- data.table::fread(species_pred_file)
tree_pruned <- ape::read.tree(tree_file)
pgls_comparison <- data.table::fread(pgls_file)

table_s1 <- dplyr::bind_rows(
  data.frame(
    Stage = "Full filtered dataset",
    Unit = "record",
    N_records = nrow(hr_records_clean),
    N_species = dplyr::n_distinct(hr_records_clean$species),
    Inclusion_criteria = "Wild individuals; terrestrial species; individual-level estimates; valid coordinates; years >= 2000.",
    stringsAsFactors = FALSE
  ),
  data.frame(
    Stage = "SSP projection subset",
    Unit = "record",
    N_records = nrow(hr_records_pred),
    N_species = dplyr::n_distinct(hr_records_pred$species),
    Inclusion_criteria = "Complete current covariates and successful matching to CMIP6 climate scenarios.",
    stringsAsFactors = FALSE
  ),
  {
    lmm_subset <- hr_records_npp %>%
      dplyr::filter(!is.na(log_hr), !is.na(bio1_temp), !is.na(bio12_prec), !is.na(human_footprint), !is.na(npp_final), npp_final > 0)
    data.frame(
      Stage = "LMM complete-case dataset",
      Unit = "record",
      N_records = nrow(lmm_subset),
      N_species = dplyr::n_distinct(lmm_subset$species),
      Inclusion_criteria = "Complete cases for temperature, precipitation, HFP, NPP, and method category.",
      stringsAsFactors = FALSE
    )
  },
  {
    sem_subset <- hr_records_npp %>%
      dplyr::filter(
        !is.na(log_hr),
        !is.na(log_mass_final),
        !is.na(trophic_level),
        !is.na(bio1_temp),
        !is.na(bio12_prec),
        !is.na(human_footprint),
        !is.na(npp_final),
        npp_final > 0
      ) %>%
      dplyr::group_by(species) %>%
      dplyr::filter(dplyr::n() >= 5) %>%
      dplyr::ungroup()
    data.frame(
      Stage = "Multilevel SEM complete-case dataset",
      Unit = "record",
      N_records = nrow(sem_subset),
      N_species = dplyr::n_distinct(sem_subset$species),
      Inclusion_criteria = "Complete SEM covariates and species represented by at least five records.",
      stringsAsFactors = FALSE
    )
  },
  {
    pgls_subset <- hr_species_complete %>%
      dplyr::filter(
        !is.na(species_tree),
        !is.na(log_hr_mean),
        !is.na(log_mass_final),
        !is.na(trophic_level),
        !is.na(bio1_temp_mean),
        !is.na(bio12_prec_mean),
        !is.na(hfp_mean),
        species_tree %in% tree_pruned$tip.label
      )
    data.frame(
      Stage = "PGLS dataset",
      Unit = "species",
      N_records = NA_integer_,
      N_species = unique(pgls_comparison$N_species)[1],
      Inclusion_criteria = "Species-level trait, environmental and method completeness plus phylogenetic matching; fitted-model sample size.",
      stringsAsFactors = FALSE
    )
  }
)

table_s2 <- pgls_comparison

fit_lmm_ml <- function(formula, data) {
  lmerTest::lmer(formula, data = data, REML = FALSE)
}

hr_lmm <- hr_records_npp %>%
  dplyr::filter(
    !is.na(log_hr),
    !is.na(bio1_temp),
    !is.na(bio12_prec),
    !is.na(human_footprint),
    !is.na(npp_final),
    npp_final > 0
  ) %>%
  dplyr::mutate(
    hr_method_cat = dplyr::coalesce(hr_method_cat, classify_hr_method(hr_method)),
    bio1_z = scale_z(bio1_temp),
    log_bio12 = safe_log10(bio12_prec + 1),
    log_bio12_z = scale_z(log_bio12),
    hfp_z = scale_z(human_footprint),
    log_npp = safe_log10(npp_final),
    log_npp_z = scale_z(log_npp),
    method_factor = factor(hr_method_cat, levels = c("MCP", "KDE", "Advanced", "Other"))
  ) %>%
  dplyr::filter(!is.na(method_factor))

model_formulas <- list(
  M1_full = log_hr ~ bio1_z + log_bio12_z + hfp_z + log_npp_z + method_factor + (1 | species),
  M2_no_temp = log_hr ~ log_bio12_z + hfp_z + log_npp_z + method_factor + (1 | species),
  M3_no_precip = log_hr ~ bio1_z + hfp_z + log_npp_z + method_factor + (1 | species),
  M4_no_hfp = log_hr ~ bio1_z + log_bio12_z + log_npp_z + method_factor + (1 | species),
  M5_no_npp = log_hr ~ bio1_z + log_bio12_z + hfp_z + method_factor + (1 | species),
  M6_method_only = log_hr ~ method_factor + (1 | species),
  M0_null = log_hr ~ 1 + (1 | species)
)

lmm_models <- lapply(model_formulas, fit_lmm_ml, data = hr_lmm)

table_s3 <- dplyr::bind_rows(lapply(names(lmm_models), function(model_name) {
  model_object <- lmm_models[[model_name]]
  data.frame(
    Model = model_name,
    Formula = paste(deparse(formula(model_object), width.cutoff = 500), collapse = " "),
    N_records = nobs(model_object),
    N_species = dplyr::n_distinct(hr_lmm$species),
    K = attr(logLik(model_object), "df"),
    logLik = as.numeric(logLik(model_object)),
    AIC = AIC(model_object),
    AICc = MuMIn::AICc(model_object),
    stringsAsFactors = FALSE
  )
})) %>%
  dplyr::arrange(AICc) %>%
  dplyr::mutate(
    Delta_AICc = AICc - min(AICc),
    Log_Akaike_weight = -0.5 * Delta_AICc - log(sum(exp(-0.5 * Delta_AICc))),
    Akaike_weight = exp(Log_Akaike_weight)
  )

write_rds(lmm_models, project_path("results", "models", "LMM_candidate_models_with_null.rds"))

make_individual_uid <- function(study_id, species, ind_id, row_id) {
  missing_ind <- is.na(ind_id) | trimws(as.character(ind_id)) == ""
  ifelse(
    missing_ind,
    paste0("singleton_", row_id),
    paste(ifelse(is.na(study_id), "studyNA", as.character(study_id)), species, as.character(ind_id), sep = "__")
  )
}

hr_lmm_sens <- hr_lmm %>%
  dplyr::mutate(
    row_id = dplyr::row_number(),
    individual_uid = make_individual_uid(study_id, species, ind_id, row_id),
    individual_uid = factor(individual_uid),
    species = factor(species)
  )

lmm_species_only <- lmerTest::lmer(
  log_hr ~ bio1_z + log_bio12_z + hfp_z + log_npp_z + method_factor + (1 | species),
  data = hr_lmm_sens,
  REML = FALSE
)

lmm_species_individual <- lmerTest::lmer(
  log_hr ~ bio1_z + log_bio12_z + hfp_z + log_npp_z + method_factor + (1 | species) + (1 | individual_uid),
  data = hr_lmm_sens,
  REML = FALSE
)

extract_fixed_effects <- function(model_object, estimate_col_name) {
  coefs <- as.data.frame(summary(model_object)$coefficients)
  coefs$term <- rownames(coefs)
  rownames(coefs) <- NULL
  coefs %>%
    dplyr::filter(term != "(Intercept)") %>%
    dplyr::mutate(
      ci_low = Estimate - 1.96 * `Std. Error`,
      ci_high = Estimate + 1.96 * `Std. Error`,
      p_label = format_p_value(`Pr(>|t|)`)
    ) %>%
    dplyr::transmute(
      Predictor = term,
      !!estimate_col_name := round(Estimate, 3),
      !!paste0(estimate_col_name, "_SE") := round(`Std. Error`, 3),
      !!paste0(estimate_col_name, "_CI") := paste0(round(ci_low, 3), " to ", round(ci_high, 3)),
      !!paste0(estimate_col_name, "_P") := p_label
    )
}

table_s4 <- dplyr::full_join(
  extract_fixed_effects(lmm_species_only, "Species_only"),
  extract_fixed_effects(lmm_species_individual, "Species_plus_individual"),
  by = "Predictor"
)

table_s5 <- dplyr::bind_rows(
  data.frame(
    Software_package = "R",
    Version = as.character(getRversion()),
    Analytical_role = "Statistical computing environment for all analyses",
    URL = "https://www.r-project.org/",
    stringsAsFactors = FALSE
  ),
  data.frame(
    Software_package = software_packages,
    Version = vapply(software_packages, function(pkg) as.character(utils::packageVersion(pkg)), character(1)),
    Analytical_role = c(
      "Fast table processing",
      "Data wrangling",
      "Data reshaping",
      "Visualization",
      "Raster processing",
      "Phylogeny handling",
      "PGLS",
      "Mixed models",
      "Mixed-model inference",
      "Model summaries and AICc",
      "Multilevel SEM",
      "Figure assembly",
      "Basemap data"
    ),
    URL = c(
      "https://cran.r-project.org/package=data.table",
      "https://cran.r-project.org/package=dplyr",
      "https://cran.r-project.org/package=tidyr",
      "https://cran.r-project.org/package=ggplot2",
      "https://cran.r-project.org/package=terra",
      "https://cran.r-project.org/package=ape",
      "https://cran.r-project.org/package=caper",
      "https://cran.r-project.org/package=lme4",
      "https://cran.r-project.org/package=lmerTest",
      "https://cran.r-project.org/package=MuMIn",
      "https://cran.r-project.org/package=lavaan",
      "https://cran.r-project.org/package=patchwork",
      "https://cran.r-project.org/package=rnaturalearth"
    ),
    stringsAsFactors = FALSE
  )
)

write_csv(table_s1, project_path("results", "tables", "table_s1_sample_sizes.csv"))
write_csv(table_s2, project_path("results", "tables", "table_s2_pgls_model_comparison.csv"))
write_csv(table_s3, project_path("results", "tables", "table_s3_lmm_model_comparison.csv"))
write_csv(table_s4, project_path("results", "tables", "table_s4_lmm_sensitivity.csv"))
write_csv(table_s5, project_path("results", "tables", "table_s5_software_environment.csv"))

message("08_make_supplementary_tables.R completed.")
