source(file.path("R", "project_setup.R"))

check_required_packages(c("data.table", "dplyr"))

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
})

home_range_file <- find_input(
  c(
    "data/raw/HomeRangeData.csv",
    "HomeRangeData.csv"
  )
)

message(sprintf("Reading %s", home_range_file))
hr_raw <- data.table::fread(home_range_file, encoding = "UTF-8")

used_columns <- c(
  "Study_ID", "Species", "Ind_ID", "Home_Range_km2", "HR_Level", "No_Individuals",
  "Sex", "Life_Stage", "Body_mass_kg", "Context", "Locomotion", "Latitude", "Longitude",
  "Country", "Locality", "yearStart", "yearEnd", "Tracking_Method", "HR_Method_Simple", "Isopleth_Size"
)
char_cols <- intersect(used_columns, names(hr_raw)[vapply(hr_raw, is.character, logical(1))])
if (length(char_cols) > 0) {
  hr_raw[, (char_cols) := lapply(.SD, sanitize_text), .SDcols = char_cols]
}

require_columns(
  hr_raw,
  c(
    "Study_ID", "Species", "Ind_ID", "Home_Range_km2", "HR_Level",
    "No_Individuals", "Sex", "Life_Stage", "Body_mass_kg", "Context",
    "Locomotion", "Latitude", "Longitude", "Country", "Locality",
    "yearStart", "yearEnd", "Tracking_Method", "HR_Method_Simple",
    "Isopleth_Size"
  ),
  "HomeRangeData.csv"
)

hr_records <- hr_raw %>%
  dplyr::transmute(
    source_row_id = seq_len(nrow(hr_raw)),
    study_id = clean_text(Study_ID),
    species = clean_text(Species),
    species_tree = standardize_species_name(clean_text(Species)),
    ind_id = clean_text(Ind_ID),
    home_range_km2 = safe_numeric(Home_Range_km2),
    hr_level = clean_text(HR_Level),
    n_individuals = safe_numeric(No_Individuals),
    sex = clean_text(Sex),
    life_stage = clean_text(Life_Stage),
    body_mass_kg = safe_numeric(Body_mass_kg),
    context = clean_text(Context),
    locomotion = clean_text(Locomotion),
    latitude = safe_numeric(Latitude),
    longitude = safe_numeric(Longitude),
    country = clean_text(Country),
    locality = clean_text(Locality),
    year_start = safe_numeric(yearStart),
    year_end = safe_numeric(yearEnd),
    tracking_method = clean_text(Tracking_Method),
    hr_method = clean_text(HR_Method_Simple),
    isopleth = clean_text(as.character(Isopleth_Size))
  ) %>%
  dplyr::mutate(
    year_mid = dplyr::case_when(
      !is.na(year_start) & !is.na(year_end) ~ round((year_start + year_end) / 2),
      !is.na(year_start) ~ year_start,
      !is.na(year_end) ~ year_end,
      TRUE ~ NA_real_
    )
  )

filter_steps <- list(
  "Raw records" = rep(TRUE, nrow(hr_records)),
  "Years >= 2000" = !is.na(hr_records$year_mid) & hr_records$year_mid >= 2000,
  "Positive home-range area" = !is.na(hr_records$home_range_km2) & hr_records$home_range_km2 > 0,
  "Valid coordinates" = !is.na(hr_records$longitude) &
    !is.na(hr_records$latitude) &
    hr_records$longitude >= -180 & hr_records$longitude <= 180 &
    hr_records$latitude >= -90 & hr_records$latitude <= 90,
  "Wild individuals only" = !is.na(hr_records$context) & hr_records$context == "Wild",
  "Terrestrial species only" = !is.na(hr_records$locomotion) & hr_records$locomotion == "Terrestrial",
  "Individual-level estimates only" = !is.na(hr_records$hr_level) & hr_records$hr_level == "Individual"
)

keep <- rep(TRUE, nrow(hr_records))
filter_log <- list()

for (step_name in names(filter_steps)) {
  keep <- keep & filter_steps[[step_name]]
  filter_log[[step_name]] <- data.frame(
    step = step_name,
    n_records = sum(keep),
    n_species = dplyr::n_distinct(hr_records$species[keep]),
    stringsAsFactors = FALSE
  )
}

filter_log <- dplyr::bind_rows(filter_log) %>%
  dplyr::mutate(
    removed = c(NA_integer_, diff(n_records) * -1L)
  )

hr_records_clean <- hr_records[keep, , drop = FALSE] %>%
  dplyr::mutate(
    log_hr = safe_log10(home_range_km2),
    log_mass = safe_log10(body_mass_kg),
    hr_method_cat = classify_hr_method(hr_method),
    isopleth_num = suppressWarnings(as.numeric(isopleth)),
    isopleth_cat = classify_isopleth(isopleth_num)
  )

species_summary <- hr_records_clean %>%
  dplyr::group_by(species, species_tree) %>%
  dplyr::summarise(
    log_hr_mean = mean(log_hr, na.rm = TRUE),
    log_hr_sd = stats::sd(log_hr, na.rm = TRUE),
    hr_geomean_km2 = geomean_positive(home_range_km2),
    log_mass_mean = mean(log_mass, na.rm = TRUE),
    mass_geomean_kg = geomean_positive(body_mass_kg),
    n_records = dplyr::n(),
    n_studies = dplyr::n_distinct(study_id),
    n_individuals = sum(n_individuals, na.rm = TRUE),
    lat_mean = mean(latitude, na.rm = TRUE),
    lon_mean = mean(longitude, na.rm = TRUE),
    lat_sd = stats::sd(latitude, na.rm = TRUE),
    lon_sd = stats::sd(longitude, na.rm = TRUE),
    lat_min = min(latitude, na.rm = TRUE),
    lat_max = max(latitude, na.rm = TRUE),
    lon_min = min(longitude, na.rm = TRUE),
    lon_max = max(longitude, na.rm = TRUE),
    year_median = stats::median(year_mid, na.rm = TRUE),
    year_min = min(year_mid, na.rm = TRUE),
    year_max = max(year_mid, na.rm = TRUE),
    method_primary = mode_value(hr_method_cat),
    prop_mcp = mean(hr_method_cat == "MCP", na.rm = TRUE),
    prop_kde = mean(hr_method_cat == "KDE", na.rm = TRUE),
    .groups = "drop"
  )

write_csv(hr_records_clean, project_path("data", "processed", "hr_records_clean.csv"))
write_csv(species_summary, project_path("data", "processed", "hr_species_summary.csv"))
write_csv(filter_log, project_path("results", "tables", "data_filter_log.csv"))

message("01_clean_home_range_data.R completed.")
