# Run from the code directory; installations use a project-local library.
required_packages <- c('data.table','dplyr','tidyr','ggplot2','patchwork','terra',
 'sf','rnaturalearth','rnaturalearthdata','scales','ape','caper','lme4','lmerTest','MuMIn',
 'MASS','mnormt','pbivnorm','numDeriv','quadprog')
project_library <- file.path(getwd(),'local_library')
dir.create(project_library,recursive=TRUE,showWarnings=FALSE)
.libPaths(c(project_library,.libPaths()))
options(repos=c(CRAN='https://cloud.r-project.org'))
missing <- required_packages[!vapply(required_packages,requireNamespace,logical(1),quietly=TRUE)]
if(length(missing))install.packages(missing,lib=project_library)
lavaan_path <- find.package('lavaan',quiet=TRUE)
lavaan_ok <- length(lavaan_path)>0L &&
 package_version(read.dcf(file.path(lavaan_path,'DESCRIPTION'),fields='Version')[1L])==
 package_version('0.6-20')
if(!lavaan_ok){
 if('lavaan' %in% loadedNamespaces())stop('Restart R before installing lavaan 0.6-20.')
 archive<-normalizePath(file.path('vendor','lavaan_0.6-20.tar.gz'),mustWork=TRUE)
 r_binary<-file.path(R.home('bin'),if(.Platform$OS.type=='windows')'R.exe' else 'R')
 status<-system2(r_binary,c('CMD','INSTALL','--no-multiarch',
  shQuote(paste0('--library=',project_library)),shQuote(archive)))
 if(status!=0)stop('Installation of lavaan 0.6-20 failed; see installer diagnostics.')
}
message('Packages ready. In a new R session, use .libPaths(c("local_library", .libPaths())).')
