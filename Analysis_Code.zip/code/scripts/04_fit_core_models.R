source(file.path("R", "project_setup.R"))

check_required_packages(c(
  "data.table",
  "dplyr",
  "ape",
  "caper",
  "lme4",
  "lmerTest",
  "MuMIn",
  "lavaan"
))

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
  library(ape)
  library(caper)
  library(lme4)
  library(lmerTest)
  library(MuMIn)
  library(lavaan)
})

species_file <- find_input("data/processed/hr_species_complete.csv")
records_env_file <- find_input("data/processed/hr_records_with_env.csv")
records_npp_file <- find_input("data/processed/hr_records_with_npp.csv")
tree_file <- find_input("data/processed/mammal_tree_pruned.tre")

hr_species <- data.table::fread(species_file)
hr_records_env <- data.table::fread(records_env_file)
hr_records_npp <- data.table::fread(records_npp_file)
tree_pruned <- ape::read.tree(tree_file)

message("Fitting LMM...")

hr_lmm <- hr_records_npp %>%
  dplyr::filter(
    !is.na(log_hr),
    !is.na(species),
    !is.na(bio1_temp),
    !is.na(bio12_prec),
    !is.na(human_footprint),
    !is.na(npp_final),
    npp_final > 0
  ) %>%
  dplyr::mutate(
    hr_method_cat = dplyr::coalesce(hr_method_cat, classify_hr_method(hr_method)),
    bio1_z = scale_z(bio1_temp),
    log_bio12 = safe_log10(bio12_prec + 1),
    log_bio12_z = scale_z(log_bio12),
    hfp_z = scale_z(human_footprint),
    log_npp = safe_log10(npp_final),
    log_npp_z = scale_z(log_npp),
    method_factor = relevel_method(hr_method_cat, "MCP")
  ) %>%
  dplyr::filter(!is.na(method_factor))

lmm_env <- lmerTest::lmer(
  log_hr ~ bio1_z + log_bio12_z + hfp_z + log_npp_z + method_factor + (1 | species),
  data = hr_lmm,
  REML = FALSE
)

lmm_coefs <- as.data.frame(summary(lmm_env)$coefficients)
lmm_coefs$term <- rownames(lmm_coefs)
rownames(lmm_coefs) <- NULL
lmm_coefs <- lmm_coefs %>%
  dplyr::select(term, dplyr::everything()) %>%
  dplyr::rename(
    estimate = Estimate,
    std_error = `Std. Error`,
    df = df,
    t_value = `t value`,
    p_value = `Pr(>|t|)`
  ) %>%
  dplyr::mutate(significance = significance_code(p_value))

var_comp <- as.data.frame(VarCorr(lmm_env))
var_species <- var_comp$vcov[var_comp$grp == "species"][1]
var_resid <- sigma(lmm_env)^2
icc_value <- var_species / (var_species + var_resid)
r2_values <- suppressWarnings(MuMIn::r.squaredGLMM(lmm_env))

lmm_fit_stats <- data.frame(
  metric = c("n_records", "n_species", "ICC", "R2_marginal", "R2_conditional"),
  value = c(
    nrow(hr_lmm),
    dplyr::n_distinct(hr_lmm$species),
    icc_value,
    as.numeric(r2_values[1]),
    as.numeric(r2_values[2])
  )
)

write_csv(lmm_coefs, project_path("results", "tables", "lmm_coefficients.csv"))
write_csv(lmm_fit_stats, project_path("results", "tables", "lmm_fit_statistics.csv"))
write_rds(lmm_env, project_path("results", "models", "lmm_model.rds"))

message("Fitting PGLS models...")

if (!"method_primary" %in% names(hr_species)) {
  species_method <- hr_records_env %>%
    dplyr::filter(!is.na(hr_method_cat)) %>%
    dplyr::group_by(species) %>%
    dplyr::summarise(method_primary = mode_value(hr_method_cat), .groups = "drop")
  hr_species <- hr_species %>% dplyr::left_join(species_method, by = "species")
}

required_species_cols <- c(
  "species_tree",
  "log_mass_final",
  "trophic_level",
  "log_hr_mean",
  "bio1_temp_mean",
  "bio12_prec_mean",
  "hfp_mean",
  "method_primary"
)
require_columns(hr_species, required_species_cols, "hr_species_complete.csv")

hr_pgls <- hr_species %>%
  dplyr::filter(
    !is.na(log_mass_final),
    !is.na(trophic_level),
    !is.na(log_hr_mean),
    !is.na(bio1_temp_mean),
    !is.na(bio12_prec_mean),
    !is.na(hfp_mean),
    !is.na(method_primary),
    species_tree %in% tree_pruned$tip.label
  ) %>%
  dplyr::mutate(
    log_mass_z = scale_z(log_mass_final),
    trophic_z = scale_z(trophic_level),
    bio1_z = scale_z(bio1_temp_mean),
    log_bio12 = safe_log10(bio12_prec_mean + 1),
    log_bio12_z = scale_z(log_bio12),
    hfp_z = scale_z(hfp_mean),
    method_factor = relevel_method(method_primary, "MCP")
  ) %>%
  as.data.frame()

rownames(hr_pgls) <- hr_pgls$species_tree
tree_pgls <- ape::keep.tip(tree_pruned, hr_pgls$species_tree)
hr_pgls <- hr_pgls[match(tree_pgls$tip.label, hr_pgls$species_tree), , drop = FALSE]
rownames(hr_pgls) <- hr_pgls$species_tree

comp_data <- caper::comparative.data(
  phy = tree_pgls,
  data = hr_pgls,
  names.col = species_tree,
  vcv = TRUE,
  na.omit = FALSE,
  warn.dropped = TRUE
)

models_list <- list(
  M1 = caper::pgls(log_hr_mean ~ log_mass_z + trophic_z + bio1_z + log_bio12_z + hfp_z + method_factor, data = comp_data, lambda = "ML"),
  M2 = caper::pgls(log_hr_mean ~ log_mass_z + trophic_z + bio1_z + log_bio12_z + method_factor, data = comp_data, lambda = "ML"),
  M3 = caper::pgls(log_hr_mean ~ log_mass_z + bio1_z + log_bio12_z + method_factor, data = comp_data, lambda = "ML"),
  M4 = caper::pgls(log_hr_mean ~ log_mass_z + hfp_z + method_factor, data = comp_data, lambda = "ML"),
  M5 = caper::pgls(log_hr_mean ~ log_mass_z + trophic_z + method_factor, data = comp_data, lambda = "ML"),
  M6 = caper::pgls(log_hr_mean ~ log_mass_z + method_factor, data = comp_data, lambda = "ML"),
  M0_null = caper::pgls(log_hr_mean ~ 1, data = comp_data, lambda = "ML")
)

# caper reports only the regression parameter count. Include the residual
# variance and every phylogenetic covariance parameter estimated by ML.
pgls_model_comparison <- dplyr::bind_rows(lapply(names(models_list), function(model_name) {
  model_object <- models_list[[model_name]]
  ll <- as.numeric(logLik(model_object))
  k <- length(model_object$model$coef) + 1L + sum(model_object$mlVals)
  n <- model_object$n
  aic <- -2 * ll + 2 * k
  data.frame(
    Model = model_name,
    Formula = paste(deparse(formula(model_object), width.cutoff = 500), collapse = " "),
    N_species = n,
    K = k,
    logLik = ll,
    AIC = aic,
    AICc = aic + 2 * k * (k + 1) / (n - k - 1),
    Pagels_lambda = unname(model_object$param["lambda"]),
    R2 = if (model_name == "M0_null") NA_real_ else as.numeric(summary(model_object)$r.squared),
    stringsAsFactors = FALSE
  )
})) %>%
  dplyr::arrange(AICc) %>%
  dplyr::mutate(
    Delta_AICc = AICc - min(AICc),
    Log_Akaike_weight = -0.5 * Delta_AICc - log(sum(exp(-0.5 * Delta_AICc))),
    Akaike_weight = exp(Log_Akaike_weight)
  )

top_model <- models_list[[pgls_model_comparison$Model[1]]]
top_coefs <- summary(top_model)$coefficients

pgls_effect_sizes <- data.frame(
  term = rownames(top_coefs),
  estimate = top_coefs[, "Estimate"],
  std_error = top_coefs[, "Std. Error"],
  t_value = top_coefs[, "t value"],
  p_value = top_coefs[, "Pr(>|t|)"],
  stringsAsFactors = FALSE
) %>%
  dplyr::mutate(significance = significance_code(p_value))

pgls_main_effects <- pgls_effect_sizes %>%
  dplyr::filter(!grepl("^method_factor", term))

write_csv(pgls_model_comparison, project_path("results", "tables", "pgls_model_comparison.csv"))
write_csv(pgls_model_comparison, project_path("results", "tables", "table_s2_pgls_model_comparison.csv"))
write_csv(pgls_effect_sizes, project_path("results", "tables", "pgls_effect_sizes.csv"))
write_csv(pgls_main_effects, project_path("results", "tables", "pgls_main_effects.csv"))
write_rds(top_model, project_path("results", "models", "pgls_best_model.rds"))
write_rds(list(models = models_list, comparative_data = comp_data),
          project_path("results", "models", "PGLS_candidate_models_with_null.rds"))

message("Fitting multilevel SEM...")

hr_msem <- hr_records_npp %>%
  dplyr::filter(
    !is.na(log_hr),
    !is.na(log_mass_final),
    !is.na(trophic_level),
    !is.na(bio1_temp),
    !is.na(bio12_prec),
    !is.na(human_footprint),
    !is.na(npp_final),
    npp_final > 0
  ) %>%
  dplyr::mutate(
    log_bio12 = safe_log10(bio12_prec + 1),
    log_npp = safe_log10(npp_final)
  )

species_counts <- hr_msem %>% dplyr::count(species)
species_keep <- species_counts$species[species_counts$n >= 5]

hr_msem <- hr_msem %>%
  dplyr::filter(species %in% species_keep)

species_means <- hr_msem %>%
  dplyr::group_by(species) %>%
  dplyr::summarise(
    sp_log_mass_mean = mean(log_mass_final, na.rm = TRUE),
    sp_trophic = mean(trophic_level, na.rm = TRUE),
    .groups = "drop"
  )

hr_msem <- hr_msem %>%
  dplyr::left_join(species_means, by = "species") %>%
  dplyr::mutate(
    bio1_z = scale_z(bio1_temp),
    log_bio12_z = scale_z(log_bio12),
    hfp_z = scale_z(human_footprint),
    log_npp_z = scale_z(log_npp),
    log_hr_z = scale_z(log_hr),
    log_mass_sp_z = scale_z(sp_log_mass_mean),
    trophic_sp_z = scale_z(sp_trophic)
  )

msem_model <- "
  level: 1
    log_npp_z ~ aw_bio1*bio1_z + aw_bio12*log_bio12_z + aw_hfp*hfp_z
    log_hr_z  ~ bw*log_npp_z + cw_bio1*bio1_z + cw_bio12*log_bio12_z + cw_hfp*hfp_z

  level: 2
    log_npp_z ~ ab_bio1*bio1_z + ab_bio12*log_bio12_z + ab_hfp*hfp_z
    log_hr_z  ~ bb*log_npp_z + cb_bio1*bio1_z + cb_bio12*log_bio12_z + cb_hfp*hfp_z + cb_mass*log_mass_sp_z + cb_troph*trophic_sp_z

  indirect_within_bio1 := aw_bio1 * bw
  indirect_within_bio12 := aw_bio12 * bw
  indirect_within_hfp := aw_hfp * bw

  indirect_between_bio1 := ab_bio1 * bb
  indirect_between_bio12 := ab_bio12 * bb
  indirect_between_hfp := ab_hfp * bb
"

sem_mode <- tolower(Sys.getenv("ARTICLE3_SEM_MODE", unset = "refit"))
if (!sem_mode %in% c("refit", "archived")) {
  stop("ARTICLE3_SEM_MODE must be 'refit' or 'archived'.", call. = FALSE)
}
if (sem_mode == "archived") {
  # This option exports the archived fitted model; it does not refit the SEM.
  sem_model_file <- find_input(c("results/models/msem_multilevel_model.rds",
                                "msem_multilevel_v3_model.rds"))
  msem_fit <- readRDS(sem_model_file)
  message("Exporting archived SEM: ", sem_model_file)
} else {
  if (as.character(utils::packageVersion("lavaan")) != "0.6.20") {
    message("The archived SEM was fitted with lavaan 0.6-20. This refit uses ",
            utils::packageVersion("lavaan"), "; compare exported results with the reference tables.")
  }
  msem_fit <- lavaan::sem(model = msem_model, data = hr_msem,
                         cluster = "species", verbose = FALSE)
}
stopifnot(lavaan::lavInspect(msem_fit, "converged"))

msem_params <- lavaan::parameterEstimates(msem_fit, standardized = TRUE)
msem_standardized <- lavaan::standardizedSolution(msem_fit, type = "std.all",
                                                 se = TRUE, ci = TRUE, level = 0.95)
msem_fit_stats <- data.frame(
  metric = c("chisq", "df", "pvalue", "cfi", "tli", "rmsea", "srmr"),
  value = as.numeric(lavaan::fitMeasures(msem_fit, c("chisq", "df", "pvalue", "cfi", "tli", "rmsea", "srmr")))
)

extract_std_param <- function(params, label_name) {
  row <- params[params$label == label_name, ]
  if (nrow(row) == 0) {
    return(list(std = NA_real_, se = NA_real_, p = NA_real_))
  }
  list(std = row$std.all[1], se = row$se[1], p = row$pvalue[1])
}

aw_bio1 <- extract_std_param(msem_params, "aw_bio1")
aw_bio12 <- extract_std_param(msem_params, "aw_bio12")
aw_hfp <- extract_std_param(msem_params, "aw_hfp")
bw <- extract_std_param(msem_params, "bw")
cw_bio1 <- extract_std_param(msem_params, "cw_bio1")
cw_bio12 <- extract_std_param(msem_params, "cw_bio12")
cw_hfp <- extract_std_param(msem_params, "cw_hfp")
ab_bio1 <- extract_std_param(msem_params, "ab_bio1")
ab_bio12 <- extract_std_param(msem_params, "ab_bio12")
ab_hfp <- extract_std_param(msem_params, "ab_hfp")
bb <- extract_std_param(msem_params, "bb")
cb_bio1 <- extract_std_param(msem_params, "cb_bio1")
cb_bio12 <- extract_std_param(msem_params, "cb_bio12")
cb_hfp <- extract_std_param(msem_params, "cb_hfp")
cb_mass <- extract_std_param(msem_params, "cb_mass")
cb_troph <- extract_std_param(msem_params, "cb_troph")

sem_path_coefficients <- data.frame(
  Level = c(rep("Within", 7), rep("Between", 9)),
  Path = c(
    "Temperature -> NPP", "Precipitation -> NPP", "HFP -> NPP",
    "NPP -> HR",
    "Temperature -> HR", "Precipitation -> HR", "HFP -> HR",
    "Temperature -> NPP", "Precipitation -> NPP", "HFP -> NPP",
    "NPP -> HR",
    "Temperature -> HR", "Precipitation -> HR", "HFP -> HR",
    "Body Mass -> HR", "Trophic Level -> HR"
  ),
  Beta = c(
    aw_bio1$std, aw_bio12$std, aw_hfp$std,
    bw$std,
    cw_bio1$std, cw_bio12$std, cw_hfp$std,
    ab_bio1$std, ab_bio12$std, ab_hfp$std,
    bb$std,
    cb_bio1$std, cb_bio12$std, cb_hfp$std,
    cb_mass$std, cb_troph$std
  ),
  SE = c(
    aw_bio1$se, aw_bio12$se, aw_hfp$se,
    bw$se,
    cw_bio1$se, cw_bio12$se, cw_hfp$se,
    ab_bio1$se, ab_bio12$se, ab_hfp$se,
    bb$se,
    cb_bio1$se, cb_bio12$se, cb_hfp$se,
    cb_mass$se, cb_troph$se
  ),
  p_value = c(
    aw_bio1$p, aw_bio12$p, aw_hfp$p,
    bw$p,
    cw_bio1$p, cw_bio12$p, cw_hfp$p,
    ab_bio1$p, ab_bio12$p, ab_hfp$p,
    bb$p,
    cb_bio1$p, cb_bio12$p, cb_hfp$p,
    cb_mass$p, cb_troph$p
  )
) %>%
  dplyr::mutate(Significance = significance_code(p_value))

sem_path_coefficients$label <- c("aw_bio1", "aw_bio12", "aw_hfp", "bw",
  "cw_bio1", "cw_bio12", "cw_hfp", "ab_bio1", "ab_bio12", "ab_hfp", "bb",
  "cb_bio1", "cb_bio12", "cb_hfp", "cb_mass", "cb_troph")
std_rows <- match(sem_path_coefficients$label, msem_standardized$label)
stopifnot(!anyNA(std_rows))
# The published path table uses Beta, SE and CI on the same standardized scale.
# Preserve the original model SE and Wald P values explicitly for audit.
sem_path_coefficients$SE_unstandardized <- sem_path_coefficients$SE
sem_path_coefficients$SE <- msem_standardized$se[std_rows]
sem_path_coefficients$SE_std <- msem_standardized$se[std_rows]
sem_path_coefficients$CI_lower <- msem_standardized$ci.lower[std_rows]
sem_path_coefficients$CI_upper <- msem_standardized$ci.upper[std_rows]
sem_path_coefficients$p_value_std <- msem_standardized$pvalue[std_rows]

write_csv(msem_params, project_path("results", "tables", "msem_multilevel_results.csv"))
write_csv(msem_params, project_path("results", "tables", "msem_multilevel_v3_results.csv"))
write_csv(msem_standardized, project_path("results", "tables", "SEM_standardized_parameters.csv"))
write_csv(msem_fit_stats, project_path("results", "tables", "msem_fit_measures.csv"))
write_csv(msem_fit_stats, project_path("results", "tables", "SEM_fit_measures.csv"))
write_csv(sem_path_coefficients, project_path("results", "tables", "SEM_path_coefficients.csv"))
write_rds(msem_fit, project_path("results", "models", "msem_multilevel_model.rds"))
write_csv(data.frame(SEM_mode = sem_mode, lavaan_runtime = as.character(utils::packageVersion("lavaan")),
                     lavaan_fitted = msem_fit@version, N_records = nrow(hr_msem),
                     N_species = dplyr::n_distinct(hr_msem$species)),
          project_path("results", "tables", "SEM_execution_environment.csv"))

message("04_fit_core_models.R completed.")
