source(file.path("R", "project_setup.R"))

check_required_packages(c("data.table", "dplyr", "tidyr"))

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
  library(tidyr)
})

records_file <- find_input("data/processed/hr_records_with_npp.csv")
ssp_file <- find_input("data/processed/ssp_climate_points.csv")
sem_results_file <- find_input("results/tables/msem_multilevel_results.csv")

hr_records_npp <- data.table::fread(records_file)
ssp_climate <- data.table::fread(ssp_file)
msem_params <- data.table::fread(sem_results_file)

get_est <- function(label_name) {
  row <- msem_params[msem_params$label == label_name, ]
  if (nrow(row) == 0) {
    return(NA_real_)
  }
  row$est[1]
}

aw_bio1 <- get_est("aw_bio1")
aw_bio12 <- get_est("aw_bio12")
aw_hfp <- get_est("aw_hfp")
bw <- get_est("bw")
cw_bio1 <- get_est("cw_bio1")
cw_bio12 <- get_est("cw_bio12")
cw_hfp <- get_est("cw_hfp")

indirect_bio1 <- aw_bio1 * bw
indirect_bio12 <- aw_bio12 * bw
indirect_hfp <- aw_hfp * bw

hr_data <- hr_records_npp %>%
  dplyr::filter(
    !is.na(log_hr),
    !is.na(bio1_temp),
    !is.na(bio12_prec),
    !is.na(human_footprint),
    !is.na(npp_final),
    npp_final > 0
  ) %>%
  dplyr::mutate(
    log_bio12 = safe_log10(bio12_prec + 1),
    log_npp = safe_log10(npp_final),
    lon_key = round(longitude, 5),
    lat_key = round(latitude, 5)
  )

scale_params <- list(
  bio1 = list(mean = mean(hr_data$bio1_temp, na.rm = TRUE), sd = stats::sd(hr_data$bio1_temp, na.rm = TRUE)),
  log_bio12 = list(mean = mean(hr_data$log_bio12, na.rm = TRUE), sd = stats::sd(hr_data$log_bio12, na.rm = TRUE)),
  log_hr = list(mean = mean(hr_data$log_hr, na.rm = TRUE), sd = stats::sd(hr_data$log_hr, na.rm = TRUE))
)

ssp_climate <- ssp_climate %>%
  dplyr::mutate(
    lon_key = round(longitude, 5),
    lat_key = round(latitude, 5)
  )

hr_ssp <- hr_data %>%
  dplyr::left_join(
    ssp_climate %>% dplyr::select(-longitude, -latitude),
    by = c("lon_key", "lat_key")
  )

ssp_keys <- sub("^bio1_", "", grep("^bio1_ssp", names(hr_ssp), value = TRUE))
ssp_keys <- ssp_keys[paste0("bio12_", ssp_keys) %in% names(hr_ssp)]

predict_hr_msem <- function(data, ssp_key) {
  bio1_future <- data[[paste0("bio1_", ssp_key)]]
  bio12_future <- data[[paste0("bio12_", ssp_key)]]

  delta_bio1_z <- (bio1_future - data$bio1_temp) / scale_params$bio1$sd
  delta_log_bio12_z <- (safe_log10(bio12_future + 1) - data$log_bio12) / scale_params$log_bio12$sd
  delta_hfp_z <- 0

  delta_npp_z <- aw_bio1 * delta_bio1_z + aw_bio12 * delta_log_bio12_z + aw_hfp * delta_hfp_z
  delta_hr_bio1_direct <- cw_bio1 * delta_bio1_z
  delta_hr_bio12_direct <- cw_bio12 * delta_log_bio12_z
  delta_hr_hfp_direct <- cw_hfp * delta_hfp_z
  delta_hr_bio1_indirect <- indirect_bio1 * delta_bio1_z
  delta_hr_bio12_indirect <- indirect_bio12 * delta_log_bio12_z
  delta_hr_hfp_indirect <- indirect_hfp * delta_hfp_z

  delta_hr_total <- delta_hr_bio1_direct + delta_hr_bio12_direct +
    delta_hr_bio1_indirect + delta_hr_bio12_indirect +
    delta_hr_hfp_direct + delta_hr_hfp_indirect

  delta_hr_log10 <- delta_hr_total * scale_params$log_hr$sd

  data.frame(
    delta_npp_z = delta_npp_z,
    delta_hr_total = delta_hr_total,
    delta_hr_log10 = delta_hr_log10,
    delta_hr_bio1_direct = delta_hr_bio1_direct,
    delta_hr_bio12_direct = delta_hr_bio12_direct,
    delta_hr_hfp_direct = delta_hr_hfp_direct,
    delta_hr_bio1_indirect = delta_hr_bio1_indirect,
    delta_hr_bio12_indirect = delta_hr_bio12_indirect,
    delta_hr_hfp_indirect = delta_hr_hfp_indirect,
    delta_temp = bio1_future - data$bio1_temp,
    delta_prec = bio12_future - data$bio12_prec,
    pct_prec_change = ifelse(data$bio12_prec > 0, (bio12_future - data$bio12_prec) / data$bio12_prec * 100, NA_real_)
  )
}

for (ssp_key in ssp_keys) {
  pred <- predict_hr_msem(hr_ssp, ssp_key)

  hr_ssp[[paste0("delta_npp_", ssp_key)]] <- pred$delta_npp_z
  hr_ssp[[paste0("delta_hr_total_", ssp_key)]] <- pred$delta_hr_total
  hr_ssp[[paste0("delta_hr_bio1_direct_", ssp_key)]] <- pred$delta_hr_bio1_direct
  hr_ssp[[paste0("delta_hr_bio12_direct_", ssp_key)]] <- pred$delta_hr_bio12_direct
  hr_ssp[[paste0("delta_hr_hfp_direct_", ssp_key)]] <- pred$delta_hr_hfp_direct
  hr_ssp[[paste0("delta_hr_bio1_indirect_", ssp_key)]] <- pred$delta_hr_bio1_indirect
  hr_ssp[[paste0("delta_hr_bio12_indirect_", ssp_key)]] <- pred$delta_hr_bio12_indirect
  hr_ssp[[paste0("delta_hr_hfp_indirect_", ssp_key)]] <- pred$delta_hr_hfp_indirect
  hr_ssp[[paste0("pct_hr_change_", ssp_key)]] <- (10^pred$delta_hr_log10 - 1) * 100
  hr_ssp[[paste0("delta_temp_", ssp_key)]] <- pred$delta_temp
  hr_ssp[[paste0("delta_prec_", ssp_key)]] <- pred$delta_prec
  hr_ssp[[paste0("pct_prec_change_", ssp_key)]] <- pred$pct_prec_change
}

diet_col <- if ("diet_category" %in% names(hr_ssp)) "diet_category" else if ("diet" %in% names(hr_ssp)) "diet" else NA_character_
order_col <- if ("order" %in% names(hr_ssp)) "order" else NA_character_

species_predictions <- hr_ssp %>%
  dplyr::group_by(species) %>%
  dplyr::summarise(
    n_records = dplyr::n(),
    log_hr_mean = mean(log_hr, na.rm = TRUE),
    log_mass_mean = mean(log_mass_final, na.rm = TRUE),
    trophic_mean = mean(trophic_level, na.rm = TRUE),
    longitude_mean = mean(longitude, na.rm = TRUE),
    latitude_mean = mean(latitude, na.rm = TRUE),
    diet = if (!is.na(diet_col)) first_non_missing(.data[[diet_col]]) else NA_character_,
    order = if (!is.na(order_col)) first_non_missing(.data[[order_col]]) else NA_character_,
    .groups = "drop"
  )

for (ssp_key in ssp_keys) {
  temp <- hr_ssp %>%
    dplyr::group_by(species) %>%
    dplyr::summarise(
      !!paste0("pct_hr_mean_", ssp_key) := mean(.data[[paste0("pct_hr_change_", ssp_key)]], na.rm = TRUE),
      !!paste0("bio1_direct_", ssp_key) := mean(.data[[paste0("delta_hr_bio1_direct_", ssp_key)]], na.rm = TRUE),
      !!paste0("bio12_direct_", ssp_key) := mean(.data[[paste0("delta_hr_bio12_direct_", ssp_key)]], na.rm = TRUE),
      !!paste0("hfp_direct_", ssp_key) := mean(.data[[paste0("delta_hr_hfp_direct_", ssp_key)]], na.rm = TRUE),
      !!paste0("bio1_indirect_", ssp_key) := mean(.data[[paste0("delta_hr_bio1_indirect_", ssp_key)]], na.rm = TRUE),
      !!paste0("bio12_indirect_", ssp_key) := mean(.data[[paste0("delta_hr_bio12_indirect_", ssp_key)]], na.rm = TRUE),
      !!paste0("hfp_indirect_", ssp_key) := mean(.data[[paste0("delta_hr_hfp_indirect_", ssp_key)]], na.rm = TRUE),
      .groups = "drop"
    )
  species_predictions <- species_predictions %>% dplyr::left_join(temp, by = "species")
}

driver_summary <- dplyr::bind_rows(lapply(ssp_keys, function(ssp_key) {
  data.frame(
    scenario_key = ssp_key,
    bio1_direct = mean(species_predictions[[paste0("bio1_direct_", ssp_key)]], na.rm = TRUE),
    bio12_direct = mean(species_predictions[[paste0("bio12_direct_", ssp_key)]], na.rm = TRUE),
    hfp_direct = mean(species_predictions[[paste0("hfp_direct_", ssp_key)]], na.rm = TRUE),
    bio1_indirect = mean(species_predictions[[paste0("bio1_indirect_", ssp_key)]], na.rm = TRUE),
    bio12_indirect = mean(species_predictions[[paste0("bio12_indirect_", ssp_key)]], na.rm = TRUE),
    hfp_indirect = mean(species_predictions[[paste0("hfp_indirect_", ssp_key)]], na.rm = TRUE),
    stringsAsFactors = FALSE
  )
})) %>%
  dplyr::mutate(
    direct_total = bio1_direct + bio12_direct + hfp_direct,
    indirect_total = bio1_indirect + bio12_indirect + hfp_indirect,
    pct_direct = round(abs(direct_total) / (abs(direct_total) + abs(indirect_total)) * 100, 1),
    pct_indirect = round(abs(indirect_total) / (abs(direct_total) + abs(indirect_total)) * 100, 1)
  )

parse_scenario <- function(x) {
  dplyr::case_when(
    grepl("ssp126", x) ~ "SSP1-2.6",
    grepl("ssp245", x) ~ "SSP2-4.5",
    grepl("ssp370", x) ~ "SSP3-7.0",
    grepl("ssp585", x) ~ "SSP5-8.5",
    TRUE ~ NA_character_
  )
}

parse_period <- function(x) {
  dplyr::case_when(
    grepl("2021_2040", x) ~ "2021-2040",
    grepl("2041_2060", x) ~ "2041-2060",
    grepl("2061_2080", x) ~ "2061-2080",
    grepl("2081_2100", x) ~ "2081-2100",
    TRUE ~ NA_character_
  )
}

full_scenario_statistics <- dplyr::bind_rows(lapply(ssp_keys, function(ssp_key) {
  values <- species_predictions[[paste0("pct_hr_mean_", ssp_key)]]
  data.frame(
    scenario_key = ssp_key,
    scenario = parse_scenario(ssp_key),
    period = parse_period(ssp_key),
    mean_change = mean(values, na.rm = TRUE),
    sd_change = stats::sd(values, na.rm = TRUE),
    median_change = stats::median(values, na.rm = TRUE),
    n_species = sum(!is.na(values)),
    stringsAsFactors = FALSE
  )
}))

lat_summary <- hr_ssp %>%
  dplyr::filter(
    !is.na(latitude),
    !is.na(delta_temp_ssp585_2081_2100),
    !is.na(pct_hr_change_ssp585_2081_2100)
  ) %>%
  dplyr::mutate(lat_zone = classify_lat_zone(latitude)) %>%
  dplyr::filter(!is.na(lat_zone)) %>%
  dplyr::group_by(lat_zone) %>%
  dplyr::summarise(
    mean_temp_increase = mean(delta_temp_ssp585_2081_2100, na.rm = TRUE),
    mean_hr_change = mean(pct_hr_change_ssp585_2081_2100, na.rm = TRUE),
    sd_hr_change = stats::sd(pct_hr_change_ssp585_2081_2100, na.rm = TRUE),
    n_records = dplyr::n(),
    n_species = dplyr::n_distinct(species),
    .groups = "drop"
  )

region_summary <- hr_ssp %>%
  dplyr::mutate(region = classify_region(longitude, latitude)) %>%
  dplyr::filter(
    region != "Other",
    !is.na(pct_hr_change_ssp585_2081_2100)
  ) %>%
  dplyr::group_by(region) %>%
  dplyr::summarise(
    n_records = dplyr::n(),
    n_species = dplyr::n_distinct(species),
    mean_hr_change = mean(pct_hr_change_ssp585_2081_2100, na.rm = TRUE),
    sd_hr_change = stats::sd(pct_hr_change_ssp585_2081_2100, na.rm = TRUE),
    mean_temp_increase = mean(delta_temp_ssp585_2081_2100, na.rm = TRUE),
    .groups = "drop"
  )

climate_summary <- hr_ssp %>%
  dplyr::mutate(climate_zone = classify_climate_zone(bio1_temp, bio12_prec)) %>%
  dplyr::filter(!is.na(climate_zone), !is.na(pct_hr_change_ssp585_2081_2100)) %>%
  dplyr::group_by(climate_zone) %>%
  dplyr::summarise(
    n_records = dplyr::n(),
    n_species = dplyr::n_distinct(species),
    mean_hr_change = mean(pct_hr_change_ssp585_2081_2100, na.rm = TRUE),
    sd_hr_change = stats::sd(pct_hr_change_ssp585_2081_2100, na.rm = TRUE),
    .groups = "drop"
  )

species_predictions <- species_predictions %>%
  dplyr::mutate(
    risk_score = dplyr::dense_rank(.data[["pct_hr_mean_ssp585_2081_2100"]]),
    risk_level = dplyr::case_when(
      .data[["pct_hr_mean_ssp585_2081_2100"]] <= -60 ~ "Very high contraction",
      .data[["pct_hr_mean_ssp585_2081_2100"]] <= -40 ~ "High contraction",
      .data[["pct_hr_mean_ssp585_2081_2100"]] <= -20 ~ "Moderate contraction",
      TRUE ~ "Low contraction or stable"
    )
  )

write_csv(hr_ssp, project_path("results", "tables", "hr_records_ssp_predictions.csv"))
write_csv(species_predictions, project_path("results", "tables", "species_hr_predictions_mechanistic.csv"))
write_csv(driver_summary, project_path("results", "tables", "driver_decomposition_summary.csv"))
write_csv(full_scenario_statistics, project_path("results", "tables", "full_scenario_statistics.csv"))
write_csv(lat_summary, project_path("results", "tables", "hr_change_by_latitude.csv"))
write_csv(region_summary, project_path("results", "tables", "hr_change_by_region.csv"))
write_csv(climate_summary, project_path("results", "tables", "hr_change_by_climate_zone.csv"))
write_rds(scale_params, project_path("results", "models", "scale_params_msem.rds"))

message("05_project_future_home_range.R completed.")
