source(file.path("R", "project_setup.R"))

check_required_packages(c("data.table", "dplyr", "ape"))

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
  library(ape)
})

species_file <- find_input("data/processed/hr_species_summary.csv")
records_file <- find_input("data/processed/hr_records_clean.csv")
pantheria_file <- find_input(c("data/external/PanTHERIA.txt", "PanTHERIA.txt"))
elton_file <- find_input(c("data/external/EltonTraits_mammals.txt", "EltonTraits_mammals.txt"))
tree_file <- find_input(
  c(
    "data/external/mammal_tree_upham2019.nex",
    "mammal_tree_upham2019.nex",
    "mammal_tree_upham20191.tre",
    "data/external/mammal_tree_upham2019.tre",
    "data/external/mammal_tree.tre",
    "data/external/mammal_tree_upham.tre",
    "mammal_tree_upham2019.tre",
    "mammal_tree_upham.tre"
  )
)

message("02: reading processed species and record tables")
hr_species <- data.table::fread(species_file)
hr_records <- data.table::fread(records_file)
message("02: reading PanTHERIA and Elton trait tables")
pantheria <- data.table::fread(
  pantheria_file,
  na.strings = c("-999", "-999.00", "NA", ""),
  encoding = "unknown"
)
elton <- data.table::fread(
  elton_file,
  na.strings = c("NA", ""),
  encoding = "unknown"
)

sanitize_char_cols <- function(dt) {
  char_cols <- names(dt)[vapply(dt, is.character, logical(1))]
  if (length(char_cols) > 0) {
    dt[, (char_cols) := lapply(.SD, sanitize_text), .SDcols = char_cols]
  }
  dt
}

message("02: sanitizing required key columns")
hr_species[, species := clean_text(species)]
hr_species[, species_tree := standardize_species_name(species)]
hr_records[, species := clean_text(species)]
hr_records[, species_tree := standardize_species_name(species)]
pantheria <- sanitize_char_cols(pantheria)
elton <- sanitize_char_cols(elton)

require_columns(
  pantheria,
  c("MSW05_Binomial", "MSW05_Order", "MSW05_Family", "5-1_AdultBodyMass_g", "6-2_TrophicLevel"),
  "PanTHERIA"
)
require_columns(
  elton,
  c(
    "Scientific", "MSWFamilyLatin", "Diet-Inv", "Diet-Vend", "Diet-Vect",
    "Diet-Vfish", "Diet-Vunk", "Diet-Scav", "Diet-Fruit", "Diet-Nect",
    "Diet-Seed", "Diet-PlantO", "BodyMass-Value"
  ),
  "EltonTraits_mammals"
)

message("02: building PanTHERIA trait table")
pantheria_clean <- pantheria %>%
  dplyr::transmute(
    species = clean_text(MSW05_Binomial),
    species_tree = standardize_species_name(clean_text(MSW05_Binomial)),
    order = clean_text(MSW05_Order),
    family = clean_text(MSW05_Family),
    mass_kg_pantheria = safe_numeric(`5-1_AdultBodyMass_g`) / 1000,
    trophic_level_pantheria = dplyr::case_when(
      safe_numeric(`6-2_TrophicLevel`) == 1 ~ 2.0,
      safe_numeric(`6-2_TrophicLevel`) == 2 ~ 3.0,
      safe_numeric(`6-2_TrophicLevel`) == 3 ~ 4.0,
      TRUE ~ NA_real_
    )
  )

message("02: building Elton trait table")
elton_clean <- elton %>%
  dplyr::transmute(
    species = clean_text(Scientific),
    species_tree = standardize_species_name(clean_text(Scientific)),
    family_elton = clean_text(MSWFamilyLatin),
    diet_inv = safe_numeric(`Diet-Inv`),
    diet_vend = safe_numeric(`Diet-Vend`),
    diet_vect = safe_numeric(`Diet-Vect`),
    diet_vfish = safe_numeric(`Diet-Vfish`),
    diet_vunk = safe_numeric(`Diet-Vunk`),
    diet_scav = safe_numeric(`Diet-Scav`),
    diet_fruit = safe_numeric(`Diet-Fruit`),
    diet_nect = safe_numeric(`Diet-Nect`),
    diet_seed = safe_numeric(`Diet-Seed`),
    diet_planto = safe_numeric(`Diet-PlantO`),
    mass_kg_elton = safe_numeric(`BodyMass-Value`) / 1000
  ) %>%
  dplyr::mutate(
    diet_animal = diet_inv + diet_vend + diet_vect + diet_vfish + diet_vunk + diet_scav,
    diet_plant = diet_fruit + diet_nect + diet_seed + diet_planto,
    trophic_level_elton = 2 + (diet_animal / 100) * 2,
    diet_category = dplyr::case_when(
      diet_animal >= 70 ~ "Carnivore",
      diet_plant >= 70 ~ "Herbivore",
      TRUE ~ "Omnivore"
    )
  )

message("02: merging trait sources")
traits_combined <- dplyr::left_join(
  elton_clean,
  pantheria_clean,
  by = c("species", "species_tree")
) %>%
  dplyr::mutate(
    family = dplyr::coalesce(family, family_elton),
    mass_kg = dplyr::coalesce(mass_kg_elton, mass_kg_pantheria),
    log_mass = safe_log10(mass_kg),
    trophic_level = dplyr::coalesce(trophic_level_elton, trophic_level_pantheria)
  ) %>%
  dplyr::select(
    species, species_tree, order, family,
    mass_kg_pantheria, mass_kg_elton, mass_kg, log_mass,
    trophic_level_pantheria, trophic_level_elton, trophic_level,
    diet_category, diet_animal, diet_plant,
    diet_inv, diet_vend, diet_vect, diet_fruit, diet_seed, diet_planto
  )

message("02: joining traits to species summary")
hr_species_with_traits <- hr_species %>%
  dplyr::left_join(traits_combined, by = c("species", "species_tree")) %>%
  dplyr::mutate(
    mass_kg_final = dplyr::coalesce(mass_geomean_kg, mass_kg),
    log_mass_final = dplyr::coalesce(log_mass_mean, log_mass),
    mass_source = dplyr::case_when(
      !is.na(mass_geomean_kg) ~ "HomeRange_original",
      !is.na(mass_kg) ~ "TraitDB",
      TRUE ~ "Missing"
    )
  )

message("02: joining traits to record table")
hr_records_with_traits <- hr_records %>%
  dplyr::left_join(
    traits_combined %>%
      dplyr::select(
        species, species_tree, order, family,
        diet_category, diet_animal, diet_plant, trophic_level,
        diet_inv, diet_vend, diet_vect, diet_fruit, diet_seed, diet_planto,
        mass_kg_trait = mass_kg, log_mass_trait = log_mass
      ),
    by = c("species", "species_tree")
  ) %>%
  dplyr::mutate(
    mass_kg_final = dplyr::coalesce(body_mass_kg, mass_kg_trait),
    log_mass_final = dplyr::coalesce(log_mass, log_mass_trait)
  )

message("02: reading phylogeny file")
tree_header <- readLines(tree_file, n = 1, warn = FALSE, encoding = "UTF-8")
if (length(tree_header) == 0) {
  stop("The phylogeny file is empty.", call. = FALSE)
}

tree_from_raw <- tryCatch({
  tmp_tree <- if (grepl("^#NEXUS", tree_header[1], ignore.case = TRUE)) {
    nexus_lines <- readLines(tree_file, warn = FALSE, encoding = "UTF-8")
    if (!grepl("^\\s*End;\\s*$", tail(nexus_lines[nzchar(trimws(nexus_lines))], 1), ignore.case = TRUE)) {
      stop("The raw NEXUS phylogeny is incomplete: final End; block terminator is missing.")
    }
    # BEAST bracket annotations are not branch lengths; remove only annotations.
    nexus_lines <- gsub("\\[[^]]*\\]", "", nexus_lines)
    nexus_connection <- textConnection(nexus_lines)
    parsed <- tryCatch(ape::read.nexus(nexus_connection), finally = close(nexus_connection))
    parsed
  } else {
    ape::read.tree(tree_file)
  }

  if (inherits(tmp_tree, "multiPhylo")) {
    if (length(tmp_tree) != 1L) {
      stop("Provide the single phylogeny used for this analysis; automatic selection from multiple trees is disabled.")
    }
    tmp_tree <- tmp_tree[[1]]
  }

  tmp_tree$tip.label <- sanitize_text(tmp_tree$tip.label)
  tmp_tree$tip.label <- extract_tree_species_name(tmp_tree$tip.label)
  if (anyDuplicated(tmp_tree$tip.label)) stop("Duplicate species names after parsing raw phylogeny tip labels.")
  if (is.null(tmp_tree$edge.length) || any(!is.finite(tmp_tree$edge.length))) {
    stop("The raw phylogeny must contain finite branch lengths.")
  }
  tmp_tree
}, error = function(e) {
  stop(sprintf("Raw phylogeny parsing failed for %s: %s. No processed-tree fallback is used.",
               tree_file, conditionMessage(e)), call. = FALSE)
})

message("02: matching species to phylogeny")
tree_species <- intersect(unique(hr_species_with_traits$species_tree), tree_from_raw$tip.label)
if (length(tree_species) == 0) {
  stop("No home-range species could be matched to the phylogeny tip labels.", call. = FALSE)
}
tree_pruned_unadjusted <- ape::keep.tip(tree_from_raw, tree_species)
tree_pruned <- tree_pruned_unadjusted
# Explicit numerical preprocessing for extant tips, after pruning.
# Original analysis: 77777.R, prune -> force.ultrametric(method = "extend") -> write.tree.
tip_depths <- ape::node.depth.edgelength(tree_pruned)[seq_len(ape::Ntip(tree_pruned))]
terminal_edges <- which(tree_pruned$edge[, 2] <= ape::Ntip(tree_pruned))
terminal_extension <- max(tip_depths) - tip_depths[tree_pruned$edge[terminal_edges, 2]]
if (max(terminal_extension) > 0.001) {
  stop("Tip-depth differences exceed the 0.001 branch-length tolerance for numerical ultrametric correction.")
}
tree_pruned$edge.length[terminal_edges] <- tree_pruned$edge.length[terminal_edges] + terminal_extension
write_csv(data.frame(
  input_file = basename(tree_file), input_tree_tips = ape::Ntip(tree_from_raw),
  analysis_tree_tips = ape::Ntip(tree_pruned), rule = "prune_then_extend_terminal_edges_to_max_tip_depth",
  max_terminal_extension = max(terminal_extension), output_significant_digits = 10,
  reason = "original prune-then-extend preprocessing removes very small extant-tip depth discrepancies",
  legacy_source = "77777.R lines 1253-1287: keep.tip; force.ultrametric(method=extend); write.tree(default digits=10)"
), project_path("results", "tables", "phylogeny_preprocessing.csv"))

message("02: writing outputs")
tree_match_summary <- data.frame(
  metric = c("home_range_species", "species_matched_to_tree", "tree_tips_after_pruning"),
  value = c(
    dplyr::n_distinct(hr_species_with_traits$species_tree),
    length(tree_species),
    ape::Ntip(tree_pruned)
  )
)

write_csv(traits_combined, project_path("data", "processed", "traits_combined.csv"))
write_csv(hr_species_with_traits, project_path("data", "processed", "hr_species_with_traits.csv"))
write_csv(hr_records_with_traits, project_path("data", "processed", "hr_records_with_traits.csv"))
write_csv(tree_match_summary, project_path("results", "tables", "tree_match_summary.csv"))
ape::write.tree(tree_pruned_unadjusted, file = project_path("data", "processed", "mammal_tree_pruned_unadjusted.tre"), digits = 15)
ape::write.tree(tree_pruned, file = project_path("data", "processed", "mammal_tree_pruned.tre"), digits = 10)

message("02_integrate_traits_and_phylogeny.R completed.")
