source(file.path('R','project_setup.R'))
check_required_packages('data.table')
read_table<-function(name)data.table::fread(find_input(paste0('results/tables/',name)),data.table=FALSE)
pgls<-read_table('table_s2_pgls_model_comparison.csv');lmm<-read_table('table_s3_lmm_model_comparison.csv')
require_columns(pgls,c('Model','N_species','K','AICc'),'revised Table S2')
require_columns(lmm,c('Model','N_records','N_species','K','AICc'),'revised Table S3')
sem<-read_table('msem_multilevel_results.csv');proj<-read_table('full_scenario_statistics.csv')
traits<-read_table('manuscript_statistical_tests.csv')
require_columns(traits,c('analysis','method','n','estimate','p_value'),'statistical summaries')
checks<-list()
add<-function(name,value,expected,tolerance){checks[[length(checks)+1L]]<<-data.frame(
 check=name,expected=expected,actual=value,tolerance=tolerance,
 pass=length(value)==1L && is.finite(value) && abs(value-expected)<=tolerance)}
add('PGLS candidate count',nrow(pgls),7,0)
add('PGLS species',pgls$N_species[1],167,0)
add('PGLS full K',pgls$K[pgls$Model=='M1'],11,0)
add('PGLS full AICc',pgls$AICc[pgls$Model=='M1'],323.812077,0.00001)
add('LMM candidate count',nrow(lmm),7,0)
add('LMM records',lmm$N_records[1],27075,0)
add('LMM species',lmm$N_species[1],177,0)
add('LMM full AICc',lmm$AICc[lmm$Model=='M1_full'],66620.51,0.0051)
add('Within precipitation to NPP',sem$std.all[sem$label=='aw_bio12'],0.65114377,0.0000001)
add('Within temperature to HR',sem$std.all[sem$label=='cw_bio1'],-0.42482405,0.0000001)
add('Between body mass to HR',sem$std.all[sem$label=='cb_mass'],0.93802712,0.0000001)
trait_expected<-data.frame(
 analysis=paste('SSP5-8.5 2081-2100',c('trophic_mean','log_mass_mean')),
 n=c(158,165),r=c(0.023105396404609,-0.166936903471999),
 p_value=c(0.773222206828662,0.032104809562345))
trait_rows<-traits[match(trait_expected$analysis,traits$analysis),]
add('Trait correlations use Pearson',sum(grepl('Pearson',trait_rows$method)),2,0)
for(i in seq_len(nrow(trait_expected))){
 label<-c('Trophic level','Body mass')[i]
 add(paste(label,'correlation sample size'),trait_rows$n[i],trait_expected$n[i],0)
 add(paste(label,'Pearson r'),trait_rows$estimate[i],trait_expected$r[i],0.00000001)
 add(paste(label,'Pearson P'),trait_rows$p_value[i],trait_expected$p_value[i],0.00000001)
}
for(i in 1:4){key<-paste0('ssp',c(126,245,370,585)[i],'_2081_2100')
 add(key,proj$mean_change[proj$scenario_key==key],
  c(-24.18843497,-37.59186930,-50.95653021,-53.81393054)[i],0.0051)}
out<-do.call(rbind,checks)
write_csv(out,project_path('logs','release_result_checks.csv'))
if(!all(out$pass))stop('Mismatch with the validated release; see logs/release_result_checks.csv.')
message(sprintf('Validated result checks passed: %d/%d.',sum(out$pass),nrow(out)))
invisible(out)
