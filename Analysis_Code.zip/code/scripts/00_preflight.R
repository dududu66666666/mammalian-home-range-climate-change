# Run from the code directory; set ARTICLE3_CHECK_MODE to published, processed or raw.
source(file.path('R','project_setup.R'))
args<-commandArgs(trailingOnly=TRUE)
mode<-if(length(args) && args[1] %in% c('published','processed','raw'))args[1] else Sys.getenv('ARTICLE3_CHECK_MODE','published')
mode<-match.arg(mode,c('published','processed','raw'))
processed<-paste0('data/processed/',c('hr_records_clean.csv','hr_species_with_traits.csv',
 'hr_records_with_env.csv','hr_records_with_npp.csv','hr_species_complete.csv',
 'mammal_tree_pruned.tre','ssp_climate_points.csv'))
published<-c(processed,paste0('results/tables/',c('data_filter_log.csv',
 'msem_multilevel_results.csv','SEM_path_coefficients.csv','msem_fit_measures.csv',
 'SEM_standardized_parameters.csv','lmm_coefficients.csv','lmm_fit_statistics.csv',
 'pgls_model_comparison.csv','pgls_effect_sizes.csv','species_hr_predictions_mechanistic.csv',
 'hr_records_ssp_predictions.csv','full_scenario_statistics.csv','hr_change_by_latitude.csv',
 'hr_change_by_region.csv','table_s2_pgls_model_comparison.csv','table_s3_lmm_model_comparison.csv',
 'table_s4_lmm_sensitivity.csv')),'results/models/msem_multilevel_model.rds')
raw<-c('data/raw/HomeRangeData.csv','data/external/PanTHERIA.txt',
 'data/external/EltonTraits_mammals.txt','data/external/mammal_tree_upham2019.nex',
 'data/external/npp/npp_data.csv')
optional<-character()
environment_point_file<-'data/external/current_environment_points.csv'
environment_point_resolved<-NA_character_
if(mode=='raw'){
 input_mode<-function(variable){
   value<-Sys.getenv(variable,'auto')
   if(!value %in% c('auto','points','rasters'))stop(sprintf('%s must be auto, points, or rasters.',variable),call.=FALSE)
   value
 }
 env_mode<-input_mode('ARTICLE3_ENV_INPUT')
 ssp_mode<-input_mode('ARTICLE3_SSP_INPUT')
 environment_point_locations<-unique(unlist(lapply(get_search_roots(),function(root){
   file.path(root,c('data/external/current_environment_points.csv',
                   'external/current_environment_points.csv',
                   'current_environment_points.csv'))
 })))
 environment_point_resolved<-find_input(environment_point_locations,must_work=FALSE)
 if(env_mode=='points' || (env_mode=='auto' && !is.na(environment_point_resolved))){
   raw<-c(raw,environment_point_file)
 }else{
   raw<-c(raw,paste0('data/external/current_climate/wc2.1_30s_bio_',c(1,12),'.tif'),
          'data/external/hfp/HFP2009.tif')
   # BIO4/BIO15 remain optional for supplementary seasonal descriptors.
   optional<-paste0('data/external/current_climate/wc2.1_30s_bio_',c(4,15),'.tif')
 }
 ssp_point_file<-'data/external/ssp/ssp_climate_points.csv'
 ssp_point_resolved<-find_input(ssp_point_file,must_work=FALSE)
 if(ssp_mode=='points' || (ssp_mode=='auto' && !is.na(ssp_point_resolved))){
   raw<-c(raw,ssp_point_file)
 }else{
   raw<-c(raw,paste0('data/external/ssp/wc2.1_2.5m_bioc_BCC-CSM2-MR_',
     rep(paste0('ssp',c(126,245,370,585)),each=4),'_',
     rep(c('2021-2040','2041-2060','2061-2080','2081-2100'),4),'.tif'))
 }
}
required<-switch(mode,published=published,processed=processed,raw=raw)
files_to_check<-c(required,optional)
resolved<-vapply(files_to_check,function(file){
 if(mode=='raw' && identical(file,environment_point_file))return(environment_point_resolved)
 find_input(file,must_work=FALSE)
},character(1))
report<-data.frame(mode=mode,required_file=files_to_check,required=files_to_check %in% required,present=!is.na(resolved),
 bytes=vapply(resolved,function(p)if(is.na(p))NA_real_ else file.info(p)$size,numeric(1)))
write_csv(report,project_path('logs',paste0('preflight_',mode,'.csv')))
missing<-files_to_check[report$required & is.na(resolved)]
if(length(missing))stop(paste('Missing release inputs:',paste(missing,collapse='\n'),sep='\n'))
message(sprintf('Preflight %s passed: %d files.',mode,length(required)))
invisible(report)
