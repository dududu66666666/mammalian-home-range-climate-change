source(file.path("R", "project_setup.R"))

check_required_packages(c("data.table", "dplyr", "ggplot2", "patchwork", "ape"))

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
  library(ggplot2)
  library(patchwork)
  library(ape)
})

species_full <- data.table::fread(find_input("data/processed/hr_species_complete.csv"))
species_traits <- data.table::fread(find_input("data/processed/hr_species_with_traits.csv"))
records_npp <- data.table::fread(find_input("data/processed/hr_records_with_npp.csv"))
species_pred <- data.table::fread(find_input("results/tables/species_hr_predictions_mechanistic.csv"))
region_summary <- data.table::fread(find_input("results/tables/hr_change_by_region.csv"))
tree_pruned <- ape::read.tree(find_input("data/processed/mammal_tree_pruned.tre"))

save_supp <- function(plot, stem, width_mm, height_mm) {
  save_plot_outputs(plot, stem, "supplementary", width_mm, height_mm)
}

# S1: body-mass distributions
sp195 <- species_traits %>%
  dplyr::distinct(species, .keep_all = TRUE) %>%
  dplyr::filter(!is.na(mass_kg_final), mass_kg_final > 0, !is.na(log_mass_final)) %>%
  dplyr::mutate(dataset = "A  Full filtered dataset")

sp177 <- species_pred %>%
  dplyr::distinct(species, .keep_all = TRUE) %>%
  dplyr::filter(!is.na(log_mass_mean)) %>%
  dplyr::mutate(dataset = "B  SSP projection subset")

s1_dat <- dplyr::bind_rows(
  sp195 %>% dplyr::transmute(species, log10_mass = log_mass_final, dataset),
  sp177 %>% dplyr::transmute(species, log10_mass = log_mass_mean, dataset)
)

p_s1 <- ggplot(s1_dat, aes(log10_mass)) +
  geom_histogram(bins = 18, fill = "grey70", color = "white", linewidth = 0.35) +
  geom_vline(xintercept = c(0, 1, 2), linetype = "dashed", linewidth = 0.35, colour = "grey35") +
  facet_wrap(~ dataset, ncol = 1, scales = "fixed") +
  scale_x_continuous(labels = function(x) parse(text = paste0("10^", x))) +
  labs(x = expression(log[10]~"body mass (kg)"), y = "Number of species") +
  theme_nc()

save_supp(p_s1, "Supplementary_Figure_S1_body_mass_distribution", 140, 160)

# S2: within-diet body-mass regressions
s2_dat <- species_pred %>%
  dplyr::filter(!is.na(log_mass_mean), !is.na(diet), !is.na(pct_hr_mean_ssp585_2081_2100)) %>%
  dplyr::mutate(
    diet = factor(diet, levels = c("Herbivore", "Omnivore", "Carnivore")),
    panel = factor(
      c("A  Herbivore", "B  Omnivore", "C  Carnivore")[match(diet, c("Herbivore", "Omnivore", "Carnivore"))],
      levels = c("A  Herbivore", "B  Omnivore", "C  Carnivore")
    )
  )

s2_stats <- s2_dat %>%
  dplyr::group_by(diet, panel) %>%
  dplyr::group_modify(~{
    fit <- lm(pct_hr_mean_ssp585_2081_2100 ~ log_mass_mean, data = .x)
    sm <- summary(fit)
    data.frame(
      x = min(.x$log_mass_mean, na.rm = TRUE),
      y = max(.x$pct_hr_mean_ssp585_2081_2100, na.rm = TRUE),
      label = sprintf("n = %d\nslope = %.2f\np = %s", nrow(.x), coef(sm)[2, 1], format_p_value(coef(sm)[2, 4]))
    )
  })

p_s2 <- ggplot(s2_dat, aes(log_mass_mean, pct_hr_mean_ssp585_2081_2100)) +
  geom_point(shape = 21, size = 2.1, fill = "grey60", colour = "black", stroke = 0.25, alpha = 0.9) +
  geom_smooth(method = "lm", se = TRUE, linewidth = 0.55, colour = "black", fill = "grey80") +
  geom_text(data = s2_stats, aes(x, y, label = label), inherit.aes = FALSE, hjust = 0, vjust = 1, size = 3) +
  facet_wrap(~ panel, nrow = 1, scales = "fixed") +
  scale_x_continuous(labels = function(x) parse(text = paste0("10^", x))) +
  labs(x = expression(log[10]~"body mass (kg)"), y = "Projected home-range change (%)") +
  theme_nc()

save_supp(p_s2, "Supplementary_Figure_S2_within_diet_regressions", 190, 80)

# S3: phylogenetic and environmental coverage
sp195_env <- species_full %>%
  dplyr::distinct(species, .keep_all = TRUE)

sp_npp <- records_npp %>%
  dplyr::filter(!is.na(npp_final), npp_final > 0) %>%
  dplyr::group_by(species) %>%
  dplyr::summarise(log_npp_mean = mean(log10(npp_final), na.rm = TRUE), .groups = "drop")

sp195_env <- sp195_env %>% dplyr::left_join(sp_npp, by = "species")
sp177_env <- species_pred %>%
  dplyr::distinct(species, .keep_all = TRUE) %>%
  dplyr::left_join(
    sp195_env %>% dplyr::select(species, species_tree, order, bio1_temp_mean, bio12_prec_mean, log_npp_mean),
    by = "species"
  )

cov_df <- dplyr::bind_rows(
  sp195_env %>% dplyr::transmute(species, dataset = "195 full filtered dataset", bio1_temp_mean, bio12_prec_mean, log_npp_mean),
  sp177_env %>% dplyr::transmute(species, dataset = "177 projection subset", bio1_temp_mean, bio12_prec_mean, log_npp_mean)
)

cov_cols <- c("195 full filtered dataset" = "grey70", "177 projection subset" = "#4C78A8")
cov_fills <- c("195 full filtered dataset" = "grey85", "177 projection subset" = "#BFD3E6")

p_s3b <- ggplot(cov_df, aes(bio1_temp_mean, color = dataset, fill = dataset)) +
  geom_density(alpha = 0.2, linewidth = 0.8) +
  scale_color_manual(values = cov_cols) +
  scale_fill_manual(values = cov_fills) +
  labs(title = "B  Mean annual temperature", x = "BIO1", y = "Density") +
  theme_nc()

p_s3c <- ggplot(cov_df, aes(log10(bio12_prec_mean + 1), color = dataset, fill = dataset)) +
  geom_density(alpha = 0.2, linewidth = 0.8) +
  scale_color_manual(values = cov_cols) +
  scale_fill_manual(values = cov_fills) +
  labs(title = "C  Annual precipitation", x = expression(log[10]~"(BIO12 + 1)"), y = "Density") +
  theme_nc()

p_s3d <- ggplot(cov_df, aes(log_npp_mean, color = dataset, fill = dataset)) +
  geom_density(alpha = 0.2, linewidth = 0.8) +
  scale_color_manual(values = cov_cols) +
  scale_fill_manual(values = cov_fills) +
  labs(title = "D  Net primary productivity", x = expression(log[10]~"NPP"), y = "Density") +
  theme_nc()

env_ref <- sp195_env %>%
  dplyr::filter(!is.na(bio1_temp_mean), !is.na(bio12_prec_mean), !is.na(log_npp_mean)) %>%
  dplyr::select(bio1_temp_mean, bio12_prec_mean, log_npp_mean)

pca_mod <- prcomp(env_ref, scale. = TRUE)
pcs195 <- predict(pca_mod, newdata = sp195_env %>% dplyr::select(bio1_temp_mean, bio12_prec_mean, log_npp_mean))
pcs177 <- predict(pca_mod, newdata = sp177_env %>% dplyr::select(bio1_temp_mean, bio12_prec_mean, log_npp_mean))

pca195 <- dplyr::bind_cols(sp195_env, as.data.frame(pcs195))
pca177 <- dplyr::bind_cols(sp177_env, as.data.frame(pcs177))

p_s3e <- ggplot() +
  geom_point(data = pca195, aes(PC1, PC2), color = "grey80", size = 1.2, alpha = 0.7) +
  geom_point(data = pca177, aes(PC1, PC2), color = "#4C78A8", size = 1.6, alpha = 0.9) +
  labs(title = "E  PCA of environmental space", x = "PC1", y = "PC2") +
  theme_nc()

tips_177 <- na.omit(unique(sp177_env$species_tree))
tips_195 <- tree_pruned$tip.label
tips_177 <- intersect(tips_177, tips_195)
obs_pd <- sum(ape::keep.tip(tree_pruned, tips_177)$edge.length)
set.seed(123)
rand_pd <- replicate(1000, {
  rand_tips <- sample(tips_195, length(tips_177), replace = FALSE)
  sum(ape::keep.tip(tree_pruned, rand_tips)$edge.length)
})

p_s3f <- ggplot(data.frame(pd = rand_pd), aes(pd)) +
  geom_histogram(bins = 30, fill = "grey75", color = "white") +
  geom_vline(xintercept = obs_pd, color = "#D55E00", linewidth = 0.9) +
  labs(title = "F  Phylogenetic diversity randomization", x = "Phylogenetic diversity", y = "Random draws") +
  theme_nc()

fig_s3_bf <- (p_s3b | p_s3c | p_s3d) / (p_s3e | p_s3f)
save_supp(p_s3b, "Supplementary_Figure_S3_panel_B_temperature_density", 120, 90)
save_supp(p_s3c, "Supplementary_Figure_S3_panel_C_precipitation_density", 120, 90)
save_supp(p_s3d, "Supplementary_Figure_S3_panel_D_npp_density", 120, 90)
save_supp(p_s3e, "Supplementary_Figure_S3_panel_E_pca", 120, 90)
save_supp(p_s3f, "Supplementary_Figure_S3_panel_F_pd_randomization", 120, 90)
save_supp(fig_s3_bf, "Supplementary_Figure_S3_panels_B_to_F", 220, 160)

tip_meta <- sp195_env %>%
  dplyr::transmute(
    species_tree = dplyr::coalesce(species_tree, standardize_species_name(species)),
    order_plot = order
  ) %>%
  dplyr::filter(species_tree %in% tree_pruned$tip.label) %>%
  dplyr::distinct()

tip_meta <- data.frame(species_tree = tree_pruned$tip.label) %>%
  dplyr::left_join(tip_meta, by = "species_tree") %>%
  dplyr::mutate(
    subset = species_tree %in% tips_177,
    order_plot = ifelse(is.na(order_plot), "Unknown", order_plot)
  )

order_levels <- unique(tip_meta$order_plot)
order_cols <- setNames(grDevices::hcl(h = seq(15, 375, length.out = length(order_levels) + 1)[1:length(order_levels)], c = 90, l = 65), order_levels)

draw_phylo <- function() {
  layout(matrix(c(1, 2), nrow = 1), widths = c(4.8, 1.6))
  par(mar = c(1, 1, 1, 0.2), xpd = NA, family = "sans")
  plot(tree_pruned, type = "fan", use.edge.length = TRUE, show.tip.label = FALSE, edge.color = adjustcolor("grey45", alpha.f = 0.45), edge.width = 0.5, no.margin = FALSE)
  pp <- get("last_plot.phylo", envir = .PlotPhyloEnv)
  ntip <- ape::Ntip(tree_pruned)
  points(pp$xx[1:ntip], pp$yy[1:ntip], pch = 16, cex = 0.55, col = order_cols[tip_meta$order_plot])
  points(pp$xx[tip_meta$subset][1:sum(tip_meta$subset)], pp$yy[tip_meta$subset][1:sum(tip_meta$subset)], pch = 21, cex = 0.95, lwd = 0.6, bg = NA, col = "#0B5C9D")
  par(mar = c(0.8, 0.5, 0.8, 0.8), family = "sans")
  plot.new()
  legend("topleft", legend = c("177 projection subset", "Other species"), pch = c(21, 16), pt.bg = c(NA, "grey75"), col = c("#0B5C9D", "grey75"), pt.cex = c(1.2, 0.8), bty = "n")
  legend("left", inset = c(0, -0.12), legend = order_levels, pch = 16, col = order_cols[order_levels], ncol = 1, bty = "n", cex = 0.8)
}

save_base_plot_outputs(draw_phylo, "Supplementary_Figure_S3_panel_A_phylogeny", "supplementary", 240, 170)

# S4: biogeographic regions
p_s4 <- ggplot(region_summary, aes(reorder(region, mean_hr_change), mean_hr_change)) +
  geom_col(fill = "#4C78A8", alpha = 0.9, width = 0.7) +
  geom_errorbar(aes(ymin = mean_hr_change - sd_hr_change, ymax = mean_hr_change + sd_hr_change), width = 0.22, linewidth = 0.5) +
  coord_flip() +
  labs(title = "Supplementary Figure S4", subtitle = "Mean home-range change (+/- SD) by biogeographic region under SSP5-8.5 (2081-2100)", x = NULL, y = "Home-range change (%)") +
  theme_nc()

save_supp(p_s4, "Supplementary_Figure_S4_biogeographic_regions", 180, 120)

message("07_make_supplementary_figures.R completed.")
