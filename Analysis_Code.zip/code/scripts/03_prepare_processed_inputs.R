source(file.path("R", "project_setup.R"))

check_required_packages(c("data.table", "dplyr", "tidyr", "ape"))

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
  library(tidyr)
})

records_file <- find_input("data/processed/hr_records_with_traits.csv")
species_file <- find_input("data/processed/hr_species_with_traits.csv")

env_input_mode <- Sys.getenv("ARTICLE3_ENV_INPUT", unset = "auto")
if (!env_input_mode %in% c("auto", "points", "rasters")) {
  stop("ARTICLE3_ENV_INPUT must be auto, points, or rasters.", call. = FALSE)
}
# Only look for this extraction table in explicitly selected external-input roots.
# Do not substitute a processed record table or search a local-drive cache.
environment_point_locations <- unique(unlist(lapply(get_search_roots(), function(root) {
  file.path(root, c("data/external/current_environment_points.csv",
                   "external/current_environment_points.csv",
                   "current_environment_points.csv"))
})))
environment_point_locations <- environment_point_locations[file.exists(environment_point_locations)]
environment_points_file <- if (length(environment_point_locations)) {
  normalizePath(environment_point_locations[[1]], winslash = "/", mustWork = TRUE)
} else NA_character_
use_environment_points <- env_input_mode != "rasters" && !is.na(environment_points_file)
if (env_input_mode == "points" && !use_environment_points) {
  stop("ARTICLE3_ENV_INPUT=points requires external/current_environment_points.csv in the selected input root.", call. = FALSE)
}

bio1_file <- find_input(
  c(
    "data/external/current_climate/wc2.1_30s_bio_1.tif",
    "climate_data/climate/wc2.1_10m/wc2.1_30s_bio_1.tif",
    "wc2.1_30s_bio_1.tif"
  ),
  must_work = !use_environment_points
)
bio12_file <- find_input(
  c(
    "data/external/current_climate/wc2.1_30s_bio_12.tif",
    "climate_data/climate/wc2.1_10m/wc2.1_30s_bio_12.tif",
    "wc2.1_30s_bio_12.tif"
  ),
  must_work = !use_environment_points
)
bio4_file <- find_input(
  c(
    "data/external/current_climate/wc2.1_30s_bio_4.tif",
    "climate_data/climate/wc2.1_10m/wc2.1_30s_bio_4.tif",
    "wc2.1_30s_bio_4.tif"
  ),
  must_work = FALSE
)
bio15_file <- find_input(
  c(
    "data/external/current_climate/wc2.1_30s_bio_15.tif",
    "climate_data/climate/wc2.1_10m/wc2.1_30s_bio_15.tif",
    "wc2.1_30s_bio_15.tif"
  ),
  must_work = FALSE
)
hfp_file <- find_input(
  c(
    "data/external/hfp/HFP2009.tif",
    "env_data/HFP2009.tif",
    "HFP2009.tif"
  ),
  must_work = !use_environment_points
)
npp_file <- find_input(
  c(
    "data/external/npp/npp_data.csv",
    "npp_data/npp_data.csv",
    "npp_data.csv"
  )
)
ssp_points_file <- find_input(
  c(
    "data/external/ssp/ssp_climate_points.csv",
    "ssp_climate_points.csv"
  ),
  must_work = FALSE
)
ssp_dir <- find_input(
  c(
    "data/external/ssp",
    "ssp_climate"
  ),
  type = "dir",
  must_work = FALSE
)

hr_records <- data.table::fread(records_file)
hr_species <- data.table::fread(species_file)
analysis_tree_file <- find_input("data/processed/mammal_tree_pruned.tre")
analysis_tree_species <- ape::read.tree(analysis_tree_file)$tip.label
hr_species <- hr_species[hr_species$species_tree %in% analysis_tree_species, , drop = FALSE]

require_columns(
  hr_records,
  c("species", "species_tree", "longitude", "latitude", "year_mid", "log_hr", "hr_method_cat"),
  "hr_records_with_traits.csv"
)

extract_single_layer <- function(raster_file, longitude, latitude) {
  as.numeric(extract_raster_values(raster_file, longitude, latitude)[, 1])
}

records_env <- hr_records %>%
  dplyr::filter(!is.na(longitude), !is.na(latitude))

environment_fields <- c("bio1_temp", "bio12_prec", "human_footprint",
                        "bio4_temp_season", "bio15_prec_season")
if (use_environment_points) {
  environment_points <- data.table::fread(environment_points_file)
  require_columns(environment_points, c("longitude", "latitude", environment_fields),
                  "current_environment_points.csv")
  if (!all(vapply(environment_points[, c("longitude", "latitude"), with = FALSE], is.numeric, logical(1))) ||
      any(!is.finite(environment_points$longitude)) || any(!is.finite(environment_points$latitude))) {
    stop("Current-environment point coordinates must be finite numeric values.", call. = FALSE)
  }
  if (!all(vapply(environment_points[, environment_fields, with = FALSE], is.numeric, logical(1)))) {
    stop("The five current-environment fields must be numeric; missing raster-cell values may be NA.", call. = FALSE)
  }
  duplicate_points <- environment_points %>%
    dplyr::count(longitude, latitude) %>%
    dplyr::filter(n != 1L)
  if (nrow(duplicate_points)) {
    stop("current_environment_points.csv must contain exactly one row per unrounded coordinate pair.", call. = FALSE)
  }
  environment_points <- environment_points %>%
    dplyr::select(longitude, latitude, dplyr::all_of(environment_fields)) %>%
    dplyr::mutate(.environment_point_present = TRUE)
  record_count <- nrow(records_env)
  records_env <- records_env %>%
    dplyr::left_join(environment_points, by = c("longitude", "latitude"), relationship = "many-to-one")
  if (nrow(records_env) != record_count || anyNA(records_env$.environment_point_present)) {
    stop("The current-environment point table must cover every record coordinate exactly, without rounding or row multiplication.", call. = FALSE)
  }
  records_env <- records_env %>% dplyr::select(-.environment_point_present)
} else {
  check_required_packages("terra")
  records_env$bio1_temp <- extract_single_layer(bio1_file, records_env$longitude, records_env$latitude)
  records_env$bio12_prec <- extract_single_layer(bio12_file, records_env$longitude, records_env$latitude)
  records_env$human_footprint <- extract_single_layer(hfp_file, records_env$longitude, records_env$latitude)
  records_env$bio4_temp_season <- if (!is.na(bio4_file)) {
    extract_single_layer(bio4_file, records_env$longitude, records_env$latitude)
  } else NA_real_
  records_env$bio15_prec_season <- if (!is.na(bio15_file)) {
    extract_single_layer(bio15_file, records_env$longitude, records_env$latitude)
  } else NA_real_
}
records_env$pop_density <- NA_real_
write_csv(data.frame(
  requested_mode = env_input_mode,
  used_mode = if (use_environment_points) "points" else "rasters",
  source = if (use_environment_points) basename(environment_points_file) else "WorldClim BIO1/BIO12 and HFP rasters; BIO4/BIO15 when available",
  coordinate_matching = "exact numeric longitude and latitude; no rounding",
  n_coordinates = nrow(dplyr::distinct(records_env, longitude, latitude))
), project_path("results", "tables", "current_environment_preprocessing.csv"))

npp_raw <- data.table::fread(npp_file)
require_columns(
  npp_raw,
  c("Latitude", "Longitude", "Date", "MOD17A3HGF_061_Npp_500m"),
  "npp_data.csv"
)

npp_processed <- npp_raw %>%
  dplyr::transmute(
    latitude = as.numeric(Latitude),
    longitude = as.numeric(Longitude),
    date_parsed = dplyr::coalesce(
      as.Date(Date, format = "%Y/%m/%d"),
      as.Date(Date, format = "%Y-%m-%d"),
      suppressWarnings(as.Date(Date))
    ),
    npp_year = as.integer(format(date_parsed, "%Y")),
    lon_key = round(longitude, 5),
    lat_key = round(latitude, 5),
    npp_raw = as.numeric(MOD17A3HGF_061_Npp_500m)
  ) %>%
  dplyr::mutate(
    npp_raw = dplyr::if_else(
      !is.na(npp_raw) & (npp_raw <= 0 | npp_raw >= 30000 | npp_raw > 5),
      NA_real_,
      npp_raw
    )
  ) %>%
  # The archived analyses use the 2001-2022 location mean, not record-year NPP.
  dplyr::group_by(lon_key, lat_key) %>%
  dplyr::summarise(
    npp_mean = mean(npp_raw, na.rm = TRUE),
    npp_sd = stats::sd(npp_raw, na.rm = TRUE),
    npp_final = mean(npp_raw, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  dplyr::mutate(
    dplyr::across(c(npp_mean, npp_sd, npp_final), ~ dplyr::if_else(is.nan(.x), NA_real_, .x))
  )

records_npp <- records_env %>%
  dplyr::mutate(
    lon_key = round(longitude, 5),
    lat_key = round(latitude, 5)
  ) %>%
  dplyr::left_join(npp_processed, by = c("lon_key", "lat_key")) %>%
  dplyr::mutate(
    log_npp = safe_log10(npp_final),
    npp_z = scale_z(npp_final),
    log_npp_z = scale_z(log_npp)
  )

species_env <- records_npp %>%
  dplyr::group_by(species) %>%
  dplyr::summarise(
    bio1_temp_mean = mean(bio1_temp, na.rm = TRUE),
    bio1_temp_sd = stats::sd(bio1_temp, na.rm = TRUE),
    bio12_prec_mean = mean(bio12_prec, na.rm = TRUE),
    bio12_prec_sd = stats::sd(bio12_prec, na.rm = TRUE),
    bio4_temp_season_mean = mean(bio4_temp_season, na.rm = TRUE),
    bio15_prec_season_mean = mean(bio15_prec_season, na.rm = TRUE),
    hfp_mean = mean(human_footprint, na.rm = TRUE),
    hfp_sd = stats::sd(human_footprint, na.rm = TRUE),
    pop_density_mean = mean(pop_density, na.rm = TRUE),
    pop_density_sd = stats::sd(pop_density, na.rm = TRUE),
    n_records_env = dplyr::n(),
    .groups = "drop"
  ) %>%
  dplyr::mutate(
    dplyr::across(where(is.numeric), ~ dplyr::if_else(is.nan(.x), NA_real_, .x))
  )

hr_species_complete <- hr_species %>%
  dplyr::left_join(species_env, by = "species")

coord_table <- records_npp %>%
  dplyr::select(longitude, latitude, bio1_temp, bio12_prec) %>%
  dplyr::distinct(longitude, latitude, .keep_all = TRUE) %>%
  dplyr::arrange(longitude, latitude) %>%
  dplyr::rename(
    bio1_current = bio1_temp,
    bio12_current = bio12_prec
  )

generate_ssp_points_from_rasters <- function(coord_df, ssp_dir_path) {
  check_required_packages("terra")
  ssp_files <- list.files(
    ssp_dir_path,
    pattern = "BCC-CSM2-MR_ssp(126|245|370|585)_(2021-2040|2041-2060|2061-2080|2081-2100)\\.tif$",
    full.names = TRUE
  )

  expected_files <- paste0("wc2.1_2.5m_bioc_BCC-CSM2-MR_",
    rep(c("ssp126", "ssp245", "ssp370", "ssp585"), each = 4), "_",
    rep(c("2021-2040", "2041-2060", "2061-2080", "2081-2100"), times = 4), ".tif")
  if (length(ssp_files) != 16L || !setequal(basename(ssp_files), expected_files)) {
    stop("Provide all 16 BCC-CSM2-MR 2.5-arc-minute SSP rasters (four scenarios by four periods).", call. = FALSE)
  }

  out <- coord_df

  for (file_name in sort(ssp_files)) {
    message(sprintf("03: extracting SSP point values from %s", basename(file_name)))
    key <- basename(file_name)
    key <- sub("^.*BCC-CSM2-MR_", "", key)
    key <- sub("\\.tif$", "", key)
    key <- gsub("-", "_", key)

    vals <- extract_raster_values(file_name, coord_df$longitude, coord_df$latitude, layer = c(1, 12))
    vals <- as.data.frame(vals)
    names(vals) <- c(paste0("bio1_", key), paste0("bio12_", key))
    out <- dplyr::bind_cols(out, vals)
  }

  ssp_keys <- sub("^bio1_", "", grep("^bio1_ssp", names(out), value = TRUE))

  for (key in ssp_keys) {
    out[[paste0("delta_temp_", key)]] <- out[[paste0("bio1_", key)]] - out$bio1_current
    out[[paste0("delta_prec_", key)]] <- out[[paste0("bio12_", key)]] - out$bio12_current
    out[[paste0("pct_prec_change_", key)]] <- ifelse(
      out$bio12_current > 0,
      out[[paste0("delta_prec_", key)]] / out$bio12_current * 100,
      NA_real_
    )
  }

  out
}

ssp_input_mode <- Sys.getenv("ARTICLE3_SSP_INPUT", unset = "auto")
if (!ssp_input_mode %in% c("auto", "rasters", "points")) {
  stop("ARTICLE3_SSP_INPUT must be auto, rasters, or points.")
}
ssp_points <- if (ssp_input_mode != "rasters" && !is.na(ssp_points_file)) {
  data.table::fread(ssp_points_file)
} else if (ssp_input_mode != "points" && !is.na(ssp_dir)) {
  generate_ssp_points_from_rasters(coord_table, ssp_dir)
} else {
  stop(
    "Provide either ssp_climate_points.csv or the CMIP6 SSP raster directory.",
    call. = FALSE
  )
}

expected_keys <- paste0(rep(c("ssp126", "ssp245", "ssp370", "ssp585"), each = 4), "_",
                        rep(c("2021_2040", "2041_2060", "2061_2080", "2081_2100"), times = 4))
require_columns(ssp_points, c("longitude", "latitude", "bio1_current", "bio12_current",
                             paste0("bio1_", expected_keys), paste0("bio12_", expected_keys),
                             paste0("delta_temp_", expected_keys), paste0("delta_prec_", expected_keys)),
                "ssp_climate_points.csv")
write_csv(data.frame(
  source_product = "MOD17A3HGF.061", source_file = basename(npp_file),
  start_year = min(as.integer(substr(npp_raw$Date, 1, 4)), na.rm = TRUE),
  end_year = max(as.integer(substr(npp_raw$Date, 1, 4)), na.rm = TRUE),
  aggregation = "coordinate mean and sample SD across all available 2001-2022 annual values",
  coordinate_rounding_decimals = 5,
  exclusion = "NPP <=0; NPP >=30000 fill; NPP >5 kg C m^-2 yr^-1",
  time_matching = "No record-year match; archived analyses use the location period mean"
), project_path("results", "tables", "npp_preprocessing.csv"))

write_csv(records_env, project_path("data", "processed", "hr_records_with_env.csv"))
write_csv(records_npp, project_path("data", "processed", "hr_records_with_npp.csv"))
write_csv(hr_species_complete, project_path("data", "processed", "hr_species_complete.csv"))
write_csv(ssp_points, project_path("data", "processed", "ssp_climate_points.csv"))

message("03_prepare_processed_inputs.R completed.")
