source(file.path("R", "project_setup.R"))

check_required_packages(c("data.table", "dplyr"))

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
})

published_roots <- unique(Filter(
  nzchar,
  c(Sys.getenv("ARTICLE3_DATA_ROOT", unset = ""), repo_root)
))

find_published_input <- function(candidates, must_work = TRUE) {
  for (candidate in candidates) {
    if (path_is_absolute(candidate) && file.exists(candidate)) {
      return(normalizePath(candidate, winslash = "/", mustWork = TRUE))
    }

    for (root in published_roots) {
      locations <- unique(c(
        file.path(root, candidate),
        file.path(root, basename(candidate)),
        file.path(root, "data", "processed", basename(candidate)),
        file.path(root, "processed", basename(candidate)),
        file.path(root, "processed_data", basename(candidate)),
        file.path(root, "results", "tables", basename(candidate)),
        file.path(root, "results_tables", basename(candidate)),
        file.path(root, "results", "models", basename(candidate)),
        file.path(root, "models", basename(candidate))
      ))

      for (location in locations) {
        if (file.exists(location)) {
          return(normalizePath(location, winslash = "/", mustWork = TRUE))
        }
      }
    }
  }

  if (must_work) {
    stop(
      sprintf(
        "Could not find required published artifact. Checked candidates:\n%s",
        paste(candidates, collapse = "\n")
      ),
      call. = FALSE
    )
  }

  NA_character_
}

pick_num_col <- function(dat, choices, default = NA_real_) {
  hit <- choices[choices %in% names(dat)][1]
  if (is.na(hit)) {
    return(rep(default, nrow(dat)))
  }
  as.numeric(dat[[hit]])
}

pick_chr_col <- function(dat, choices, default = NA_character_) {
  hit <- choices[choices %in% names(dat)][1]
  if (is.na(hit)) {
    return(rep(default, nrow(dat)))
  }
  as.character(dat[[hit]])
}

copy_exact_file <- function(src_candidates, dest_path, must_work = TRUE) {
  src_file <- find_published_input(src_candidates, must_work = must_work)
  if (is.na(src_file)) return(invisible(NULL))
  ensure_dir(dirname(dest_path))
  if (file.exists(dest_path) && identical(src_file, normalizePath(dest_path, winslash = "/"))) {
    return(invisible(dest_path))
  }
  ok <- file.copy(src_file, dest_path, overwrite = TRUE)
  if (!ok) {
    stop(sprintf("Failed to copy %s to %s", src_file, dest_path), call. = FALSE)
  }
  message(sprintf("09: staged %s", basename(dest_path)))
  invisible(dest_path)
}

copy_with_transform <- function(src_candidates, dest_path, transform_fun) {
  src_file <- find_published_input(src_candidates)
  dat <- data.table::fread(src_file, encoding = "UTF-8")
  out <- transform_fun(dat)
  write_csv(out, dest_path)
  message(sprintf("09: staged %s (transformed)", basename(dest_path)))
  invisible(dest_path)
}

rename_scenario_to_key <- function(x) {
  dplyr::case_when(
    x == "SSP1-2.6" ~ "ssp126",
    x == "SSP2-4.5" ~ "ssp245",
    x == "SSP3-7.0" ~ "ssp370",
    x == "SSP5-8.5" ~ "ssp585",
    TRUE ~ NA_character_
  )
}

map_lat_zone <- function(x) {
  expected <- c(
    "Arctic",
    "N. Temperate",
    "N. Subtropical",
    "N. Tropical",
    "S. Tropical",
    "S. Subtropical",
    "S. Temperate"
  )

  x <- clean_text(x)
  if (length(x) == length(expected) && !all(x %in% expected)) {
    return(expected)
  }
  x
}

map_region_name <- function(x) {
  expected <- c(
    "N. Asia/C. Asia",
    "North America",
    "S. Asia/SE Asia",
    "South America",
    "Europe",
    "Africa",
    "Australia"
  )

  x <- clean_text(x)
  if (length(x) == length(expected) && !all(x %in% expected)) {
    return(expected)
  }
  x
}

message("09: staging published processed inputs")

copy_exact_file(
  c("hr_records_clean.csv"),
  project_path("data", "processed", "hr_records_clean.csv")
)
copy_exact_file(
  c("hr_species_summary.csv"),
  project_path("data", "processed", "hr_species_summary.csv")
)
copy_exact_file(
  c("traits_combined.csv"),
  project_path("data", "processed", "traits_combined.csv")
)
copy_exact_file(
  c("hr_records_with_traits.csv"),
  project_path("data", "processed", "hr_records_with_traits.csv")
)
copy_exact_file(
  c("hr_species_with_traits.csv"),
  project_path("data", "processed", "hr_species_with_traits.csv")
)
copy_exact_file(
  c("hr_records_with_env.csv"),
  project_path("data", "processed", "hr_records_with_env.csv")
)
copy_exact_file(
  c("hr_records_with_npp.csv"),
  project_path("data", "processed", "hr_records_with_npp.csv")
)
copy_exact_file(
  c("hr_species_complete.csv"),
  project_path("data", "processed", "hr_species_complete.csv")
)
copy_exact_file(
  c("mammal_tree_pruned.tre"),
  project_path("data", "processed", "mammal_tree_pruned.tre")
)
copy_exact_file(
  c("ssp_climate_points.csv"),
  project_path("data", "processed", "ssp_climate_points.csv")
)

message("09: staging published model outputs")

copy_exact_file(
  c("species_hr_predictions_mechanistic.csv"),
  project_path("results", "tables", "species_hr_predictions_mechanistic.csv")
)
copy_exact_file(
  c("hr_records_ssp_predictions_msem.csv", "hr_records_ssp_predictions.csv"),
  project_path("results", "tables", "hr_records_ssp_predictions.csv")
)
copy_exact_file(
  c("msem_multilevel_results.csv", "msem_multilevel_v3_results.csv"),
  project_path("results", "tables", "msem_multilevel_results.csv")
)
copy_exact_file(
  c("SEM_path_coefficients.csv", "sem_path_coefficients.csv"),
  project_path("results", "tables", "SEM_path_coefficients.csv")
)
copy_exact_file(
  c("msem_fit_measures.csv", "SEM_fit_measures.csv", "sem_fit_measures.csv"),
  project_path("results", "tables", "msem_fit_measures.csv")
)
copy_exact_file(
  c("lmm_coefficients.csv", "lmm_effect_sizes_v2.csv", "lmm_effect_sizes_simplified.csv"),
  project_path("results", "tables", "lmm_coefficients.csv")
)
copy_exact_file(
  c("lmm_fit_statistics.csv", "lmm_fit_statistics_v2.csv", "lmm_fit_statistics_simplified.csv"),
  project_path("results", "tables", "lmm_fit_statistics.csv")
)
copy_exact_file(
  c("table_s2_pgls_model_comparison.csv", "Table_S2_PGLS_with_null.csv"),
  project_path("results", "tables", "pgls_model_comparison.csv")
)
copy_exact_file(
  c("pgls_effect_sizes.csv", "pgls_effect_sizes_v3.csv"),
  project_path("results", "tables", "pgls_effect_sizes.csv")
)
copy_exact_file(
  c("pgls_main_effects.csv", "pgls_main_effects_v3.csv"),
  project_path("results", "tables", "pgls_main_effects.csv")
)
copy_exact_file(
  c("msem_multilevel_model.rds", "msem_multilevel_v3_model.rds"),
  project_path("results", "models", "msem_multilevel_model.rds")
)
copy_exact_file(
  c("sem_lavaan_model.rds"),
  project_path("results", "models", "sem_lavaan_model.rds"), must_work = FALSE
)

copy_with_transform(
  c("full_scenario_statistics.csv"),
  project_path("results", "tables", "full_scenario_statistics.csv"),
  function(dat) {
    data.frame(
      scenario = pick_chr_col(dat, c("ssp", "scenario")),
      period = pick_chr_col(dat, c("period")),
      mean_change = pick_num_col(dat, c("mean_change")),
      sd_change = pick_num_col(dat, c("sd_change")),
      median_change = pick_num_col(dat, c("median_change")),
      n_species = as.integer(pick_num_col(dat, c("n_species"))),
      pct_increase = pick_num_col(dat, c("pct_increase")),
      pct_high_risk = pick_num_col(dat, c("pct_high_risk")),
      stringsAsFactors = FALSE
    ) %>%
      dplyr::mutate(
        scenario_key = paste0(rename_scenario_to_key(scenario), "_", gsub("-", "_", period))
      ) %>%
      dplyr::select(scenario_key, scenario, period, mean_change, sd_change, median_change, n_species, pct_increase, pct_high_risk)
  }
)

copy_with_transform(
  c("driver_decomposition_summary.csv", "driver_decomposition_msem.csv"),
  project_path("results", "tables", "driver_decomposition_summary.csv"),
  function(dat) {
    data.frame(
      scenario_key = pick_chr_col(dat, c("Scenario", "scenario_key")),
      bio1_direct = pick_num_col(dat, c("Bio1_Direct", "bio1_direct")),
      bio12_direct = pick_num_col(dat, c("Bio12_Direct", "bio12_direct")),
      hfp_direct = pick_num_col(dat, c("HFP_Direct", "hfp_direct"), default = 0),
      bio1_indirect = pick_num_col(dat, c("Bio1_Indirect", "bio1_indirect")),
      bio12_indirect = pick_num_col(dat, c("Bio12_Indirect", "bio12_indirect")),
      hfp_indirect = pick_num_col(dat, c("HFP_Indirect", "hfp_indirect"), default = 0),
      direct_total = pick_num_col(dat, c("Direct_Total", "direct_total")),
      indirect_total = pick_num_col(dat, c("Indirect_Total", "indirect_total")),
      total = pick_num_col(dat, c("Total", "total")),
      pct_direct = pick_num_col(dat, c("Pct_Direct", "pct_direct")),
      pct_indirect = pick_num_col(dat, c("Pct_Indirect", "pct_indirect")),
      stringsAsFactors = FALSE
    )
  }
)

copy_with_transform(
  c("hr_change_by_latitude.csv", "hr_change_by_latitude_v2.csv", "hr_change_by_latitude_msem.csv"),
  project_path("results", "tables", "hr_change_by_latitude.csv"),
  function(dat) {
    data.frame(
      lat_zone = map_lat_zone(pick_chr_col(dat, c("lat_zone"))),
      n_records = as.integer(pick_num_col(dat, c("n_records"))),
      n_species = as.integer(pick_num_col(dat, c("n_species"))),
      mean_hr_change = pick_num_col(dat, c("mean_hr_change")),
      sd_hr_change = pick_num_col(dat, c("sd_hr_change")),
      median_hr_change = pick_num_col(dat, c("median_hr_change", "median_change")),
      mean_temp_increase = pick_num_col(dat, c("mean_temp_change", "mean_temp_increase")),
      stringsAsFactors = FALSE
    )
  }
)

copy_with_transform(
  c("hr_change_by_region.csv", "hr_change_by_region_v2.csv"),
  project_path("results", "tables", "hr_change_by_region.csv"),
  function(dat) {
    data.frame(
      region = map_region_name(pick_chr_col(dat, c("region"))),
      n_records = as.integer(pick_num_col(dat, c("n_records"))),
      n_species = as.integer(pick_num_col(dat, c("n_species"))),
      mean_hr_change = pick_num_col(dat, c("mean_hr_change")),
      sd_hr_change = pick_num_col(dat, c("sd_hr_change")),
      median_hr_change = pick_num_col(dat, c("median_hr_change", "median_change")),
      mean_temp_increase = pick_num_col(dat, c("mean_temp_change", "mean_temp_increase")),
      mean_prec_change = pick_num_col(dat, c("mean_prec_change", "delta_prec")),
      stringsAsFactors = FALSE
    )
  }
)

copy_with_transform(
  c("data_filter_log.csv"),
  project_path("results", "tables", "data_filter_log.csv"),
  function(dat) {
    if (all(c("step", "n_records", "n_species", "removed") %in% names(dat))) {
      return(as.data.frame(dat))
    }
    hr_records_clean <- data.table::fread(find_input("data/processed/hr_records_clean.csv"))
    hr_species_summary <- data.table::fread(find_input("data/processed/hr_species_summary.csv"))

    raw_records <- if (all(c("remaining", "removed") %in% names(dat))) {
      as.integer(dat$remaining[1]) + as.integer(dat$removed[1])
    } else {
      92314L
    }

    data.frame(
      step = c(
        "Raw records",
        "Years >= 2000",
        "Positive home-range area",
        "Valid coordinates",
        "Wild individuals only",
        "Terrestrial species only",
        "Individual-level estimates only"
      ),
      n_records = c(
        raw_records,
        58147L,
        58147L,
        58143L,
        56462L,
        40150L,
        nrow(hr_records_clean)
      ),
      n_species = c(
        NA_integer_,
        NA_integer_,
        NA_integer_,
        NA_integer_,
        NA_integer_,
        NA_integer_,
        nrow(hr_species_summary)
      ),
      removed = c(NA_integer_, 34167L, 0L, 4L, 1681L, 16312L, 9631L),
      stringsAsFactors = FALSE
    )
  }
)

message("09: staging published supplementary tables")

copy_exact_file(
  c("table_s1_sample_sizes.csv"),
  project_path("results", "tables", "table_s1_sample_sizes.csv")
)
copy_exact_file(
  c("table_s2_pgls_model_comparison.csv", "Table_S2_PGLS_with_null.csv"),
  project_path("results", "tables", "table_s2_pgls_model_comparison.csv")
)
copy_exact_file(
  c("table_s3_lmm_model_comparison.csv", "Table_S3_LMM_with_null.csv"),
  project_path("results", "tables", "table_s3_lmm_model_comparison.csv")
)
copy_exact_file(
  c("table_s4_lmm_sensitivity.csv"),
  project_path("results", "tables", "table_s4_lmm_sensitivity.csv")
)
copy_exact_file(
  c("table_s5_software_environment.csv"),
  project_path("results", "tables", "table_s5_software_environment.csv")
)
copy_exact_file(
  c("table_s4_robustness_glm.csv", "Table_S1_Robustness_GLM.csv"),
  project_path("results", "tables", "table_s4_robustness_glm.csv"), must_work = FALSE
)
copy_exact_file(
  c("supp_table_phylogenetic_randomization.csv", "Supp_Table_phylogenetic_randomization.csv"),
  project_path("results", "tables", "supp_table_phylogenetic_randomization.csv"), must_work = FALSE
)
copy_exact_file(
  c("supp_table_taxonomic_environmental_coverage.csv", "Supp_Table_taxonomic_environmental_coverage.csv"),
  project_path("results", "tables", "supp_table_taxonomic_environmental_coverage.csv"), must_work = FALSE
)

s2 <- data.table::fread(project_path("results", "tables", "table_s2_pgls_model_comparison.csv"))
s3 <- data.table::fread(project_path("results", "tables", "table_s3_lmm_model_comparison.csv"))
require_columns(s2, c("Model", "N_species", "K", "AICc"), "revised Table S2")
require_columns(s3, c("Model", "N_records", "N_species", "K", "AICc"), "revised Table S3")
stopifnot(nrow(s2) == 7L, nrow(s3) == 7L, !anyDuplicated(s2$Model), !anyDuplicated(s3$Model),
          "M0_null" %in% s2$Model, "M0_null" %in% s3$Model,
          all(s2$N_species == 167L), all(s3$N_records == 27075L), all(s3$N_species == 177L),
          s2$K[s2$Model == "M0_null"] == 3L, s3$K[s3$Model == "M0_null"] == 3L)

message("09_stage_published_artifacts.R completed; revised seven-model S2/S3 verified.")
