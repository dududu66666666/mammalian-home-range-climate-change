get_script_path <- function() {
 frame_files <- Filter(function(x)!is.null(x) && nzchar(x),lapply(sys.frames(),function(env)env$ofile))
 if(length(frame_files))return(normalizePath(frame_files[[length(frame_files)]],winslash='/',mustWork=TRUE))
 all_args <- commandArgs(trailingOnly=FALSE)
 hit <- grep('^--file=',all_args,value=TRUE)
 if(length(hit))return(normalizePath(sub('^--file=','',hit[1]),winslash='/',mustWork=TRUE))
 stop('Run this entry point from the code directory or source it by its file path.')
}
script_path <- get_script_path()
repo_root <- normalizePath(file.path(dirname(script_path), ".."), winslash = "/", mustWork = TRUE)
setwd(repo_root)

script_order <- c(
  "09_stage_published_artifacts.R",
  "06_make_main_figures.R",
  "07_make_supplementary_figures.R"
)

for (script_name in script_order) {
  message(sprintf("Running %s ...", script_name))
  source(file.path("scripts", script_name), local = FALSE)
}

message("Published-results pipeline completed.")
