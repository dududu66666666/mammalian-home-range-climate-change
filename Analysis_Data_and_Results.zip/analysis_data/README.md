# Analysis data and results

Extract Analysis_Data_and_Results.zip beside `code` and `raw_data`. From the `code` directory, set:

```r
Sys.setenv(ARTICLE3_DATA_ROOT = normalizePath("../analysis_data"))
```

Use the entry points in `../code/README.md` to regenerate figures from saved results or refit models from the analysis-ready inputs.

- `data/processed/`: cleaned records, traits, environmental covariates, pruned phylogeny, species summaries and future-climate point inputs.
- `results/models/`: fitted PGLS, LMM and multilevel SEM objects, candidate models and scaling parameters.
- `results/tables/`: coefficients, model comparisons, diagnostics, projections, supplementary tables and statistical summaries.
- `verification/`: numerical comparisons, input checks and software information from validation.
- `manifest_sha256.csv`: relative paths, sizes and SHA256 checksums of package files.

`msem_multilevel_v3_results.csv`, `SEM_path_coefficients.csv` and `SEM_fit_measures.csv` are included in `results/tables/`. Compatibility aliases are exported by the workflow.

`results/tables/manuscript_statistical_tests.csv` reports Pearson correlations for body mass and trophic level versus species-level projected home-range change, and Spearman correlations for warming summaries across latitude zones and biogeographic regions. Climate-class outputs are descriptive summaries. `verification/trait_correlation_validation.md` documents the current statistical-summary checks. Earlier full-workflow comparison reports retain their original statistical-summary snapshot; those historical snapshots used Spearman for the two trait rows and included a climate-class correlation row that is outside the current export scope.

The separate Source_Data_and_Environmental_Inputs.zip provides original database, trait, phylogeny and NPP tables together with current/future environmental point inputs. Its README describes optional downloads for spatial re-extraction from official rasters.

`verification/light_validation_summary.txt` describes the independent reconstruction using the supplied point inputs. `verification/RAW_VALIDATION.md` documents an earlier validation using the original environmental rasters. Those raster checks remain as provenance; the global rasters are obtained separately and are not included in these ZIP files.
