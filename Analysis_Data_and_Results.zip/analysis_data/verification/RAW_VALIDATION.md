# Original raster reconstruction validation

Historical full-workflow validation record. Its statistical-summary snapshot used Spearman for species traits and included a climate-class correlation row. The current export uses Pearson for species traits, retains grouped warming tests for latitude zones and biogeographic regions, and provides descriptive climate-class summaries. See trait_correlation_validation.md for the current export checks. Source inputs, fitted models and projection values are unchanged.

This report describes the earlier validation performed using the original full set of environmental rasters. Those global raster files are **not included in the current upload packages**. Their versions, official download locations and original checksums are provided in `raw_data/external_raster_sources.csv`. The current point-input workflow was independently validated and is described in `light_validation_summary.txt`.

The original raster validation ran in a fresh isolated code directory. Scripts 01-03 rebuilt the record and species tables, trait joins, phylogeny and environmental covariates. Future raster extraction used all 16 original BCC-CSM2-MR files. Scripts 04, 05 and 10 then refitted models, calculated projections and exported manuscript statistics. SEM was refitted with lavaan 0.6-20; the fitted archive object was not used for this run.

`ARTICLE3_ARCHIVE_ROOT` identified the reference archive for comparison. Software versions are in `raw_model_refit_session_info.txt`; execution settings are in `raw_SEM_execution_environment.csv`.

| Check | Result | Report |
|---|---|---|
| Source-row identity, covariates, missingness, SSP fields and tree covariance | 111 checks passed | `raw_preparation_validation.csv` |
| Prepared table rows and common columns | Numeric model fields reproduced; text decoding differences recorded | `raw_preparation_row_counts.csv`, `raw_preparation_column_comparison.csv` |
| Refit model, projection and statistical outputs versus a fresh processed-input run | 28 CSV tables, 710 fields; maximum numeric difference 0 | `raw_end_to_end_table_comparison.csv`, `raw_end_to_end_column_comparison.csv` |
| Output schema and alignment | Additional raw-source and trait columns recorded | `raw_end_to_end_schema_comparison.csv` |
| Scenario summaries at display precision | All 64 comparisons passed | `raw_scenario_manuscript_precision_comparison.csv` |

The record projection output contains 300 text-only locality differences after decoding the original input. These descriptive fields are not model covariates; row identity and shared numeric fields matched. The schema report lists additional columns retained during preparation and legacy join-suffix columns in the processed reference.

`raw_data_filter_log.csv`, `raw_tree_match_summary.csv`, `raw_phylogeny_preprocessing.csv` and `raw_npp_preprocessing.csv` document the preparation rules. `raw_raster_metadata.csv` documents dimensions, resolution, CRS and layer counts of the original rasters used in this earlier check. The retained reports document that check and do not imply that global TIFFs are bundled in the current packages.
