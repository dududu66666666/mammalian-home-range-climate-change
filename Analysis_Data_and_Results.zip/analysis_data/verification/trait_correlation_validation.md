# Statistical-summary validation

The released statistical-summary table is `results/tables/manuscript_statistical_tests.csv`.
It contains Pearson correlations for species-level body mass and trophic level under
SSP5-8.5 in 2081-2100, Kruskal-Wallis comparisons, and Spearman correlations for
warming summaries across latitude zones and biogeographic regions. Climate-class
outputs are descriptive summaries; no climate-class correlation is exported.

## Pearson results

| Trait | Complete pairs | r | P |
|---|---:|---:|---:|
| Trophic level (`trophic_mean`) | 158 | 0.0231053964046089 | 0.773222206828662 |
| Log10 body mass (`log_mass_mean`) | 165 | -0.166936903471999 | 0.0321048095623449 |

The summaries were regenerated with the released script 10 in two fresh code
directories: one used the archived analysis package and the other used inputs and
model/projection outputs from the previously completed independent source-table
and environmental-point reconstruction. The resulting summary tables were byte
identical. The updated verifier passed all 22 checks in each directory: 15 core
scientific checks and seven checks of the Pearson methods, sample sizes, r and P.

The four retained non-trait test rows were unchanged. The climate-class mean
table was unchanged. No source input, analysis-ready dataset, fitted model or
projection table was replaced. SHA256 checks confirmed 79 protected
files were byte identical to the previous release.

## Evidence files

- `trait_correlation_validation.csv`: full-precision Pearson results and reconstruction agreement.
- `trait_correlation_result_checks.csv`: all 22 checks for both input sets.
- `trait_correlation_input_integrity.csv`: hashes of unchanged inputs, models and other result tables.

The full source preparation, model refitting and projections were not rerun for
this summary update. Their earlier validation evidence remains in this directory.
Those historical comparison reports retain the statistical-summary snapshot
used at the time; current summary rows are covered by the checks above.
The verification scope is the analyses exported by the supplied scripts.
